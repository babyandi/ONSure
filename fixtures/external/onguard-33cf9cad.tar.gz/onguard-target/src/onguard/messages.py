from __future__ import annotations

from string import Formatter
from typing import Mapping


DEFAULT_LOCALE = "ko"
SUPPORTED_LOCALES = ("ko", "en")

CATALOGS: Mapping[str, Mapping[str, str]] = {
    "ko": {
        "ONG-REQ-001": "필수 입력 누락: {field}",
        "ONG-REQ-002": "필수 입력 누락으로 Fail-Closed 처리한다.",
        "ONG-POL-001": "활성 정책 Rule이 없어 Fail-Closed 처리한다.",
        "ONG-POL-002": "일치하는 정책 Rule이 없어 Fail-Closed 처리한다.",
        "ONG-POL-003": "동일 우선순위 정책 Rule의 판정이 충돌해 Fail-Closed 처리한다.",
        "ONG-RCP-001": "Receipt를 찾을 수 없다.",
        "ONG-RCP-002": "Receipt 계약이 손상되었거나 지원되지 않는 버전이다.",
        "ONG-AUD-503": "감사 증적 저장 실패로 Fail-Closed 처리한다.",
    },
    "en": {
        "ONG-REQ-001": "Required input is missing: {field}",
        "ONG-REQ-002": "Fail-Closed because required input is missing.",
        "ONG-POL-001": "Fail-Closed because there is no active policy rule.",
        "ONG-POL-002": "Fail-Closed because no policy rule matches.",
        "ONG-POL-003": "Fail-Closed because policy rules at the same priority conflict.",
        "ONG-RCP-001": "Receipt was not found.",
        "ONG-RCP-002": "The Receipt contract is malformed or unsupported.",
        "ONG-AUD-503": "Fail-Closed because audit evidence could not be persisted.",
    },
}


class MessageCatalogError(ValueError):
    """메시지 계약 위반을 호출자에게 명확히 알린다."""


def render_message(code: str, *, locale: str = DEFAULT_LOCALE, **values: object) -> str:
    """코드와 locale로 메시지를 렌더링하며 누락·불일치는 조용히 숨기지 않는다."""

    selected = locale if locale in CATALOGS else DEFAULT_LOCALE
    template = CATALOGS[selected].get(code)
    if template is None:
        raise MessageCatalogError(f"unknown message code: {code}")
    required = {name for _, name, _, _ in Formatter().parse(template) if name}
    if required != set(values):
        raise MessageCatalogError(
            f"message parameters mismatch for {code}: required={sorted(required)}, supplied={sorted(values)}"
        )
    return template.format(**values)


def validate_catalogs() -> tuple[str, ...]:
    """모든 locale의 키와 포맷 파라미터가 기준 locale과 일치하는지 검사한다."""

    baseline = CATALOGS[DEFAULT_LOCALE]
    errors: list[str] = []
    for locale in SUPPORTED_LOCALES:
        catalog = CATALOGS.get(locale, {})
        if set(catalog) != set(baseline):
            errors.append(f"{locale}: message keys differ")
            continue
        for code, template in baseline.items():
            base_fields = {name for _, name, _, _ in Formatter().parse(template) if name}
            locale_fields = {name for _, name, _, _ in Formatter().parse(catalog[code]) if name}
            if base_fields != locale_fields:
                errors.append(f"{locale}:{code}: parameters differ")
    return tuple(errors)

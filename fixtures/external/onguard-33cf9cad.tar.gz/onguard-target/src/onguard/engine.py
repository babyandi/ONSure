from __future__ import annotations

from .classification import classify_content, sanitize_content
from .messages import render_message
from .models import ClassificationResult, DecisionStatus, EgressRequest, PolicyDecision, PolicyRule
from .policy import DEFAULT_RULES, POLICY_VERSION
from .receipt import build_receipt, canonical_hash


REQUIRED_FIELDS = ("actor_id", "purpose", "target", "channel", "content")


def validate_request(request: EgressRequest) -> tuple[str, ...]:
    """정책판정 전에 반드시 필요한 입력값 누락을 검사한다."""

    missing = [field for field in REQUIRED_FIELDS if not getattr(request, field, None)]
    return tuple(render_message("ONG-REQ-001", field=field) for field in missing)


def _rule_matches(rule: PolicyRule, request: EgressRequest, classification: ClassificationResult) -> bool:
    """channel, 정보등급, actor_ids, purpose_keywords 조건이 모두 일치하는지 확인한다."""

    if not rule.active:
        return False
    if rule.channel != request.channel:
        return False
    if rule.targets and request.target not in rule.targets:
        return False
    if classification.level not in rule.levels:
        return False
    if rule.actor_ids and request.actor_id not in rule.actor_ids:
        return False
    if rule.purpose_keywords and not any(keyword in request.purpose for keyword in rule.purpose_keywords):
        return False
    return True


def _egress_content(
    request: EgressRequest,
    decision: DecisionStatus,
    classification: ClassificationResult,
) -> str:
    """판정에 따라 외부로 전달해도 되는 문자열만 반환한다."""

    if decision is DecisionStatus.ALLOW:
        return request.content
    if decision is DecisionStatus.MASK:
        return sanitize_content(request.content, classification)
    return ""


def _build_decision(
    request: EgressRequest,
    rules: tuple[PolicyRule, ...],
    policy_version: str,
    decision: DecisionStatus,
    classification: ClassificationResult,
    reasons: tuple[str, ...],
    *,
    audit_persisted: bool = True,
) -> PolicyDecision:
    egress_content = _egress_content(request, decision, classification)
    egress_content_hash = canonical_hash({"egress_content": egress_content})
    receipt = build_receipt(
        request,
        rules,
        policy_version,
        decision,
        classification.level,
        reasons,
        egress_content_hash,
    )
    return PolicyDecision(
        decision=decision,
        classification=classification,
        reasons=reasons,
        receipt=receipt,
        egress_content=egress_content,
        audit_persisted=audit_persisted,
    )


def build_audit_failure_decision(
    request: EgressRequest,
    rules: tuple[PolicyRule, ...],
    policy_version: str,
    classification: ClassificationResult,
) -> PolicyDecision:
    """감사 저장 실패를 허용으로 위장하지 않는 비저장 Fail-Closed Receipt를 만든다."""

    return _build_decision(
        request,
        rules,
        policy_version,
        DecisionStatus.UNKNOWN,
        classification,
        (render_message("ONG-AUD-503"),),
        audit_persisted=False,
    )


def evaluate_policy(
    request: EgressRequest,
    rules: tuple[PolicyRule, ...] = DEFAULT_RULES,
    policy_version: str = POLICY_VERSION,
) -> PolicyDecision:
    """단일 외부 반출 요청을 분류하고 활성 정책 Rule로 판정한다."""

    validation_errors = validate_request(request)
    if validation_errors:
        classification = ClassificationResult(level=classify_content(request.content).level, signals=("invalid-request",))
        decision = DecisionStatus.UNKNOWN
        reasons = validation_errors + (render_message("ONG-REQ-002"),)
        return _build_decision(request, rules, policy_version, decision, classification, reasons)

    classification = classify_content(request.content)
    if not rules:
        reasons = (render_message("ONG-POL-001"),)
        decision = DecisionStatus.UNKNOWN
        return _build_decision(request, rules, policy_version, decision, classification, reasons)

    matching_rules = sorted(
        (rule for rule in rules if _rule_matches(rule, request, classification)),
        key=lambda rule: (-rule.priority, rule.rule_id),
    )
    if matching_rules:
        top_priority = matching_rules[0].priority
        top_rules = tuple(rule for rule in matching_rules if rule.priority == top_priority)
        if len({rule.effect for rule in top_rules}) > 1:
            reasons = (render_message("ONG-POL-003"),)
            return _build_decision(
                request,
                rules,
                policy_version,
                DecisionStatus.UNKNOWN,
                classification,
                reasons,
            )
        rule = top_rules[0]
        reasons = (rule.reason,)
        return _build_decision(request, rules, rule.version, rule.effect, classification, reasons)

    reasons = (render_message("ONG-POL-002"),)
    decision = DecisionStatus.UNKNOWN
    return _build_decision(request, rules, policy_version, decision, classification, reasons)

from __future__ import annotations

from .engine import build_audit_failure_decision, evaluate_policy
from .exception_policy import ONGuardError, STORAGE_FAILURE, fail_closed
from .models import DecisionStatus, EgressRequest, InformationLevel, PolicyRule
from .storage import DEFAULT_LIST_LIMIT, AuditCenter, PolicyCenter, build_default_centers


POLICY_CENTER, AUDIT_CENTER = build_default_centers()


def reset_runtime() -> None:
    """테스트와 시연에서 기본 정책/감사 저장소를 초기 상태로 되돌린다."""

    global POLICY_CENTER, AUDIT_CENTER
    POLICY_CENTER, AUDIT_CENTER = build_default_centers()


def _request_from_payload(payload: dict[str, str]) -> EgressRequest:
    """외부 API payload를 내부 정책판정 요청 모델로 변환한다."""

    return EgressRequest(
        actor_id=payload.get("actor_id", ""),
        purpose=payload.get("purpose", ""),
        target=payload.get("target", ""),
        channel=payload.get("channel", "external_llm"),
        content=payload.get("content", ""),
        request_id=payload.get("request_id", ""),
    )


def _rule_from_payload(payload: dict[str, object]) -> PolicyRule:
    """정책센터 Rule 등록 payload를 내부 Rule 모델로 변환한다."""

    return PolicyRule(
        rule_id=str(payload["rule_id"]),
        version=str(payload["version"]),
        priority=int(payload["priority"]),
        channel=str(payload.get("channel", "external_llm")),
        levels=tuple(InformationLevel(str(level)) for level in payload["levels"]),
        effect=DecisionStatus(str(payload["effect"])),
        reason=str(payload["reason"]),
        active=bool(payload.get("active", True)),
        actor_ids=tuple(str(actor_id) for actor_id in payload.get("actor_ids", ())),
        purpose_keywords=tuple(str(keyword) for keyword in payload.get("purpose_keywords", ())),
        targets=tuple(str(target) for target in payload.get("targets", ())),
    )


def _load_active_policy() -> tuple[str, tuple[PolicyRule, ...]]:
    """활성 정책 버전과 그 Rule 집합을 함께 조회한다."""

    version = POLICY_CENTER.active_version()
    return version, POLICY_CENTER.list_rules(version)


def decide_egress(payload: dict[str, str]) -> dict[str, object]:
    """외부 반출 요청을 판정하고 감사센터에 Receipt를 저장한다."""

    request = _request_from_payload(payload)
    try:
        # 활성 정책 조회 자체가 실패하면 빈 정책으로 판정해 Fail-Closed 경로를 탄다.
        # fail_closed가 원인을 관측 가능하게 로그로 남긴 뒤 ONGuardError로 재던진다.
        active_version, rules = fail_closed(_load_active_policy)
    except ONGuardError:
        active_version = "NO_ACTIVE_POLICY"
        rules = ()
    decision = evaluate_policy(request, rules=rules, policy_version=active_version)
    try:
        fail_closed(
            lambda: AUDIT_CENTER.save_decision(request, decision),
            failure=STORAGE_FAILURE,
        )
    except ONGuardError:
        decision = build_audit_failure_decision(
            request,
            rules,
            active_version,
            decision.classification,
        )
    return decision.to_dict()


def audit_events(limit: int = DEFAULT_LIST_LIMIT, offset: int = 0) -> list[dict[str, object]]:
    """감사센터에 저장된 정책판정 이벤트 목록을 페이지 단위로 반환한다."""

    return AUDIT_CENTER.list_events(limit=limit, offset=offset)


def register_policy_version(version: str, status: str = "DRAFT", description: str = "") -> dict[str, object]:
    """정책 버전을 등록하고 필요하면 활성 버전으로 승격한다."""

    POLICY_CENTER.register_version(version, status=status, description=description)
    return {"version": version, "status": status, "description": description}


def policy_versions() -> list[dict[str, str]]:
    """등록된 정책 버전 목록을 조회한다."""

    return POLICY_CENTER.list_versions()


def register_policy_rule(payload: dict[str, object]) -> dict[str, object]:
    """정책 Rule을 등록하거나 같은 버전의 기존 Rule을 갱신한다."""

    rule = _rule_from_payload(payload)
    POLICY_CENTER.register_rule(rule)
    return {"rule_id": rule.rule_id, "version": rule.version, "active": rule.active}


def policy_rules(version: str | None = None) -> list[dict[str, object]]:
    """정책 버전별 활성 Rule 목록을 API 응답 형태로 반환한다."""

    return [
        {
            "rule_id": rule.rule_id,
            "version": rule.version,
            "priority": rule.priority,
            "channel": rule.channel,
            "levels": [level.value for level in rule.levels],
            "effect": rule.effect.value,
            "reason": rule.reason,
            "active": rule.active,
            "actor_ids": list(rule.actor_ids),
            "purpose_keywords": list(rule.purpose_keywords),
            "targets": list(rule.targets),
        }
        for rule in POLICY_CENTER.list_rules(version=version)
    ]


def get_receipt(receipt_id: str) -> dict[str, object] | None:
    """Receipt ID로 저장된 감사 증적을 조회한다."""

    return AUDIT_CENTER.get_receipt(receipt_id)


def verify_receipt(receipt_id: str) -> dict[str, object]:
    """저장된 Receipt가 현재 payload 기준으로 변조되지 않았는지 검증한다."""

    return AUDIT_CENTER.verify_receipt(receipt_id)

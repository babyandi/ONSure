from __future__ import annotations

import sqlite3
from pathlib import Path


SCHEMA_SQL = """
-- Python MVP 실행용 SQLite 스키마이다.
-- 운영 설계서는 PostgreSQL 기준이고, 이 스키마는 동일 계약을 테스트에서 검증한다.
CREATE TABLE IF NOT EXISTS ong_policy_version (
    policy_version TEXT PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED')),
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ong_policy_rule (
    rule_id TEXT NOT NULL,
    policy_version TEXT NOT NULL REFERENCES ong_policy_version(policy_version),
    priority INTEGER NOT NULL,
    channel TEXT NOT NULL,
    levels_json TEXT NOT NULL,
    effect TEXT NOT NULL,
    reason TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    -- 비어 있는 '[]'는 모든 사용자/목적에 적용되는 wildcard 조건이다.
    actor_ids_json TEXT NOT NULL DEFAULT '[]',
    purpose_keywords_json TEXT NOT NULL DEFAULT '[]',
    targets_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (rule_id, policy_version)
);

CREATE INDEX IF NOT EXISTS ix_policy_rule_version_priority
    ON ong_policy_rule(policy_version, active, channel, priority DESC, rule_id);

CREATE TABLE IF NOT EXISTS ong_egress_request (
    request_hash TEXT PRIMARY KEY,
    request_id TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    purpose TEXT NOT NULL,
    target TEXT NOT NULL,
    channel TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_egress_request_actor_created
    ON ong_egress_request(actor_id, created_at DESC);

CREATE TABLE IF NOT EXISTS ong_policy_decision (
    decision_hash TEXT PRIMARY KEY,
    request_hash TEXT NOT NULL REFERENCES ong_egress_request(request_hash),
    policy_version TEXT NOT NULL,
    policy_hash TEXT NOT NULL,
    decision TEXT NOT NULL,
    classification_level TEXT NOT NULL,
    signals_json TEXT NOT NULL,
    reasons_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_policy_decision_policy_created
    ON ong_policy_decision(policy_version, created_at DESC);

CREATE INDEX IF NOT EXISTS ix_policy_decision_decision_level
    ON ong_policy_decision(decision, classification_level);

CREATE TABLE IF NOT EXISTS ong_receipt (
    receipt_id TEXT PRIMARY KEY,
    decision_hash TEXT NOT NULL UNIQUE REFERENCES ong_policy_decision(decision_hash),
    request_hash TEXT NOT NULL,
    policy_hash TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    receipt_payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_receipt_hashes
    ON ong_receipt(request_hash, policy_hash, decision_hash);

CREATE TABLE IF NOT EXISTS ong_audit_event (
    event_id TEXT PRIMARY KEY,
    decision_hash TEXT NOT NULL REFERENCES ong_policy_decision(decision_hash),
    receipt_id TEXT NOT NULL REFERENCES ong_receipt(receipt_id),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_audit_event_created
    ON ong_audit_event(created_at, event_id);

-- 감사 계보는 애플리케이션 우회를 가정해 DB 자체가 UPDATE/DELETE를 거부한다.
CREATE TRIGGER IF NOT EXISTS trg_egress_request_no_update
BEFORE UPDATE ON ong_egress_request BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_UPDATE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_egress_request_no_delete
BEFORE DELETE ON ong_egress_request BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_DELETE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_policy_decision_no_update
BEFORE UPDATE ON ong_policy_decision BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_UPDATE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_policy_decision_no_delete
BEFORE DELETE ON ong_policy_decision BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_DELETE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_receipt_no_update
BEFORE UPDATE ON ong_receipt BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_UPDATE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_receipt_no_delete
BEFORE DELETE ON ong_receipt BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_DELETE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_audit_event_no_update
BEFORE UPDATE ON ong_audit_event BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_UPDATE_DENIED');
END;
CREATE TRIGGER IF NOT EXISTS trg_audit_event_no_delete
BEFORE DELETE ON ong_audit_event BEGIN
    SELECT RAISE(ABORT, 'ONGUARD_APPEND_ONLY_DELETE_DENIED');
END;
"""


def connect_database(path: str | Path = ":memory:") -> sqlite3.Connection:
    """SQLite 연결을 만들고 외래키 검사를 활성화한다."""

    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def apply_schema(connection: sqlite3.Connection) -> None:
    """ONGuard MVP 실행에 필요한 핵심 테이블과 인덱스를 생성한다."""

    connection.executescript(SCHEMA_SQL)
    # 기존 MVP DB를 재사용하는 경우 CREATE TABLE IF NOT EXISTS만으로는 새 컬럼이
    # 추가되지 않는다. 명시적 additive migration으로 target scope를 fail-closed
    # 기본값([])과 함께 보강한다.
    policy_rule_columns = {
        str(row["name"])
        for row in connection.execute("PRAGMA table_info(ong_policy_rule)").fetchall()
    }
    if "targets_json" not in policy_rule_columns:
        connection.execute(
            "ALTER TABLE ong_policy_rule "
            "ADD COLUMN targets_json TEXT NOT NULL DEFAULT '[]'"
        )
    connection.commit()

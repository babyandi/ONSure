from __future__ import annotations

import re
import unicodedata

from .models import ClassificationResult, InformationLevel


PATTERNS: tuple[tuple[str, re.Pattern[str], InformationLevel], ...] = (
    (
        "resident-registration-number",
        re.compile(r"(?<!\d)\d{6}(?:[-\s]*?)\d{7}(?!\d)"),
        InformationLevel.L4,
    ),
    ("passport-number", re.compile(r"\b[A-Z][0-9]{8}\b", re.IGNORECASE), InformationLevel.L4),
    (
        "credit-card-number",
        re.compile(r"(?<!\d)(?:\d{4}[-\s]*){3}\d{4}(?!\d)"),
        InformationLevel.L4,
    ),
    ("email-address", re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE), InformationLevel.L3),
    (
        "phone-number",
        re.compile(r"(?<!\d)01[016789][-\s]*\d{3,4}[-\s]*\d{4}(?!\d)"),
        InformationLevel.L3,
    ),
    ("api-key", re.compile(r"\b(?:sk|api|secret)[-_]?[A-Za-z0-9]{16,}\b", re.IGNORECASE), InformationLevel.L4),
    ("access-token", re.compile(r"\b(?:bearer|token)\s+[A-Za-z0-9._~+/=-]{20,}\b", re.IGNORECASE), InformationLevel.L4),
    (
        "account-number",
        re.compile(r"(?<!\d)\d{3,6}[-\s]+\d{2,6}[-\s]+\d{3,8}(?!\d)"),
        InformationLevel.L3,
    ),
    ("customer", re.compile(r"고객|계약|계좌|잔고|주문", re.IGNORECASE), InformationLevel.L3),
    ("internal", re.compile(r"내부|프로젝트|부서|업무", re.IGNORECASE), InformationLevel.L2),
    ("core-secret", re.compile(r"핵심기술|비공개 전략|중대 규제정보", re.IGNORECASE), InformationLevel.L5),
    (
        "prompt-injection",
        re.compile(
            r"정책\s*을?\s*무시|보안\s*규칙\s*무시|"
            r"(?:이전|기존)\s*(?:지시|명령|규칙)\s*(?:을|를)?\s*무시|"
            r"(?:ignore|disregard|forget)[\s._-]*(?:all[\s._-]*)?"
            r"(?:(?:prior|previous)[\s._-]*)?"
            r"(?:(?:system|developer|security)[\s._-]*)?instructions",
            re.IGNORECASE,
        ),
        InformationLevel.L5,
    ),
)


def normalize_content(content: str) -> str:
    """호환문자·전각문자 등 표현 차이를 정규화해 단순 우회를 줄인다."""

    normalized = unicodedata.normalize("NFKC", content)
    # 제로폭 문자·방향 제어문자 같은 Unicode format 문자는 의미를 바꾸지 않은 채
    # 탐지 정규식만 분리하는 우회에 악용될 수 있으므로 판정 전에 제거한다.
    without_format_controls = "".join(
        character for character in normalized if unicodedata.category(character) != "Cf"
    )
    # Unicode dash 계열(Pd)을 ASCII '-'로 통일해 en/em/fullwidth dash 치환 우회를 막는다.
    return "".join(
        "-" if unicodedata.category(character) == "Pd" else character
        for character in without_format_controls
    )


def sanitize_content(content: str, classification: ClassificationResult) -> str:
    """MASK 판정에 사용할 실제 반출 문자열을 생성한다.

    명시적 식별자 패턴은 신호별 토큰으로 치환한다. 고객·내부 등 문맥 신호만
    존재해 안전한 부분 마스킹 경계를 계산할 수 없으면 전체 본문을 차단형
    토큰으로 대체한다.
    """

    sanitized = normalize_content(str(content))
    explicit_signals = {
        "resident-registration-number",
        "passport-number",
        "credit-card-number",
        "email-address",
        "phone-number",
        "api-key",
        "access-token",
        "account-number",
    }
    replaced = False
    for name, pattern, _ in PATTERNS:
        if name not in classification.signals or name not in explicit_signals:
            continue
        sanitized, count = pattern.subn(f"[REDACTED:{name}]", sanitized)
        replaced = replaced or count > 0
    if classification.level in {InformationLevel.L2, InformationLevel.L3} and not replaced:
        return f"[REDACTED:{classification.level.value}]"
    return sanitized


def mask_content(content: str) -> str:
    """탐지된 구체적인 민감 값만 치환하는 호환 보조 함수다.

    실제 반출 판정은 sanitize_content()를 사용한다. 이 함수는 기존 내부 호출자의
    값 단위 마스킹 호환성을 유지하되, 정책 우회나 문맥 신호를 안전한 반출로
    승인하지 않는다.
    """

    masked = normalize_content(str(content)) if content else ""
    value_signals = {
        "resident-registration-number",
        "passport-number",
        "credit-card-number",
        "email-address",
        "phone-number",
        "api-key",
        "access-token",
        "account-number",
    }
    for name, pattern, _level in PATTERNS:
        if name in value_signals:
            masked = pattern.sub(f"[REDACTED:{name}]", masked)
    return masked


def classify_content(content: str) -> ClassificationResult:
    """입력 본문에서 탐지된 신호 중 가장 높은 정보등급을 반환한다."""

    if content is None or not str(content).strip():
        return ClassificationResult(level=InformationLevel.L5, signals=("empty-content",))

    normalized = normalize_content(str(content))
    signals: list[str] = []
    level = InformationLevel.L0
    for name, pattern, detected_level in PATTERNS:
        if pattern.search(normalized):
            signals.append(name)
            if int(detected_level.value[1]) > int(level.value[1]):
                level = detected_level

    return ClassificationResult(level=level, signals=tuple(signals))

from __future__ import annotations

import json
import sqlite3
import uuid

from .db import apply_schema, connect_database
from .messages import render_message
from .models import (
    ClassificationResult,
    DecisionStatus,
    EgressRequest,
    InformationLevel,
    PolicyDecision,
    PolicyRule,
    Receipt,
)
from .policy import DEFAULT_RULES, POLICY_VERSION
from .receipt import canonical_hash, verify_receipt_signature


# GC-RSC-009: 감사 이벤트 조회는 항상 상한을 갖는다. 호출자가 더 큰 값을 넘겨도 MAX로 clamp한다.
DEFAULT_LIST_LIMIT = 100
MAX_LIST_LIMIT = 500


def _rule_to_row(rule: PolicyRule) -> tuple[object, ...]:
    """PolicyRule 객체를 DB 저장용 row 값으로 변환한다."""

    return (
        rule.rule_id,
        rule.version,
        rule.priority,
        rule.channel,
        json.dumps([level.value for level in rule.levels], ensure_ascii=False),
        rule.effect.value,
        rule.reason,
        1 if rule.active else 0,
        json.dumps(list(rule.actor_ids), ensure_ascii=False),
        json.dumps(list(rule.purpose_keywords), ensure_ascii=False),
        json.dumps(list(rule.targets), ensure_ascii=False),
    )


def _row_to_rule(row: sqlite3.Row) -> PolicyRule:
    """DB row를 정책엔진에서 사용하는 PolicyRule 객체로 복원한다."""

    return PolicyRule(
        rule_id=row["rule_id"],
        version=row["policy_version"],
        priority=row["priority"],
        channel=row["channel"],
        levels=tuple(InformationLevel(level) for level in json.loads(row["levels_json"])),
        effect=DecisionStatus(row["effect"]),
        reason=row["reason"],
        active=bool(row["active"]),
        actor_ids=tuple(json.loads(row["actor_ids_json"])),
        purpose_keywords=tuple(json.loads(row["purpose_keywords_json"])),
        targets=tuple(json.loads(row["targets_json"])),
    )


def _receipt_from_payload(payload: dict[str, object]) -> Receipt:
    """저장된 JSON payload를 Receipt 객체로 복원한다."""

    return Receipt(
        receipt_id=str(payload["receipt_id"]),
        request_hash=str(payload["request_hash"]),
        policy_hash=str(payload["policy_hash"]),
        decision_hash=str(payload["decision_hash"]),
        policy_version=str(payload["policy_version"]),
        actor_id=str(payload["actor_id"]),
        target=str(payload["target"]),
        decision=DecisionStatus(str(payload["decision"])),
        classification_level=InformationLevel(str(payload["classification_level"])),
        reasons=tuple(str(reason) for reason in payload["reasons"]),
        egress_content_hash=str(payload["egress_content_hash"]),
        signature_algorithm=str(payload["signature_algorithm"]),
        signing_key_id=str(payload["signing_key_id"]),
        signature=str(payload["signature"]),
    )


class PolicyCenter:
    """정책 버전과 Rule의 등록, 조회, 활성 버전 관리를 담당한다."""

    def __init__(self, connection: sqlite3.Connection | None = None) -> None:
        self.connection = connection or connect_database()
        apply_schema(self.connection)

    def bootstrap_defaults(self) -> None:
        """MVP 기본 정책 버전과 기본 Rule을 초기 데이터로 적재한다."""

        self.register_version(POLICY_VERSION, status="ACTIVE", description="ONGuard MVP default policy")
        for rule in DEFAULT_RULES:
            self.register_rule(rule)

    def register_version(self, version: str, status: str = "DRAFT", description: str = "") -> None:
        """정책 버전을 등록한다. ACTIVE 등록 시 기존 ACTIVE는 RETIRED로 내린다."""

        if status not in {"DRAFT", "ACTIVE", "RETIRED"}:
            raise ValueError("invalid policy version status")
        if status == "ACTIVE":
            # 활성 정책은 하나만 유지해서 판정 기준선이 흔들리지 않게 한다.
            self.connection.execute("UPDATE ong_policy_version SET status = 'RETIRED' WHERE status = 'ACTIVE'")
        self.connection.execute(
            """
            INSERT INTO ong_policy_version(policy_version, status, description)
            VALUES (?, ?, ?)
            ON CONFLICT(policy_version) DO UPDATE SET
                status = excluded.status,
                description = excluded.description
            """,
            (version, status, description),
        )
        self.connection.commit()

    def register_rule(self, rule: PolicyRule) -> None:
        """Rule을 등록하거나 같은 정책 버전의 기존 Rule을 갱신한다."""

        if not rule.rule_id or not rule.version or not rule.channel or not rule.reason:
            raise ValueError("policy rule requires rule_id, version, channel, and reason")
        if not rule.levels:
            raise ValueError("policy rule requires at least one information level")
        if not rule.targets:
            raise ValueError("policy rule requires at least one explicit target")
        self.connection.execute(
            """
            -- Rule이 먼저 들어와도 버전 참조 무결성이 깨지지 않도록 초안을 만든다.
            INSERT OR IGNORE INTO ong_policy_version(policy_version, status, description)
            VALUES (?, 'DRAFT', '')
            """,
            (rule.version,),
        )
        self.connection.execute(
            """
            INSERT INTO ong_policy_rule(
                rule_id, policy_version, priority, channel, levels_json, effect, reason, active,
                actor_ids_json, purpose_keywords_json, targets_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(rule_id, policy_version) DO UPDATE SET
                priority = excluded.priority,
                channel = excluded.channel,
                levels_json = excluded.levels_json,
                effect = excluded.effect,
                reason = excluded.reason,
                active = excluded.active,
                actor_ids_json = excluded.actor_ids_json,
                purpose_keywords_json = excluded.purpose_keywords_json,
                targets_json = excluded.targets_json
            """,
            _rule_to_row(rule),
        )
        self.connection.commit()

    def list_versions(self) -> list[dict[str, str]]:
        """정책 버전 목록을 등록 순서 기준으로 반환한다."""

        rows = self.connection.execute(
            "SELECT policy_version, status, description, created_at FROM ong_policy_version ORDER BY created_at, policy_version"
        ).fetchall()
        return [dict(row) for row in rows]

    def active_version(self) -> str:
        """현재 ACTIVE 상태인 정책 버전을 반환한다."""

        row = self.connection.execute(
            "SELECT policy_version FROM ong_policy_version WHERE status = 'ACTIVE' ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        if row is None:
            raise RuntimeError("active policy version is not registered")
        return str(row["policy_version"])

    def list_rules(self, version: str | None = None, active_only: bool = True) -> tuple[PolicyRule, ...]:
        """지정 버전 또는 활성 버전의 Rule을 우선순위 순서로 조회한다."""

        selected_version = version or self.active_version()
        rows = self.connection.execute(
            """
            SELECT * FROM ong_policy_rule
            WHERE policy_version = ?
              AND (? = 0 OR active = 1)
            ORDER BY priority DESC, rule_id
            """,
            (selected_version, 1 if active_only else 0),
        ).fetchall()
        return tuple(_row_to_rule(row) for row in rows)


class AuditCenter:
    """정책판정 결과와 Receipt의 저장, 조회, 검증을 담당한다."""

    def __init__(self, connection: sqlite3.Connection | None = None) -> None:
        self.connection = connection or connect_database()
        apply_schema(self.connection)

    def save_decision(self, request: EgressRequest, decision: PolicyDecision) -> None:
        """요청, 판정, Receipt를 하나의 트랜잭션으로 저장한다."""

        payload = decision.receipt.to_dict()
        content_hash = canonical_hash({"content": request.content})
        with self.connection:
            # 원문은 저장하지 않고 content_hash만 저장해 감사성과 정보보호를 함께 맞춘다.
            self.connection.execute(
                """
                INSERT OR IGNORE INTO ong_egress_request(
                    request_hash, request_id, actor_id, purpose, target, channel, content_hash
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision.receipt.request_hash,
                    request.request_id,
                    request.actor_id,
                    request.purpose,
                    request.target,
                    request.channel,
                    content_hash,
                ),
            )
            self.connection.execute(
                """
                INSERT OR IGNORE INTO ong_policy_decision(
                    decision_hash, request_hash, policy_version, policy_hash, decision,
                    classification_level, signals_json, reasons_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    decision.receipt.decision_hash,
                    decision.receipt.request_hash,
                    decision.receipt.policy_version,
                    decision.receipt.policy_hash,
                    decision.decision.value,
                    decision.classification.level.value,
                    json.dumps(list(decision.classification.signals), ensure_ascii=False),
                    json.dumps(list(decision.reasons), ensure_ascii=False),
                ),
            )
            self.connection.execute(
                """
                INSERT OR IGNORE INTO ong_receipt(
                    receipt_id, decision_hash, request_hash, policy_hash, policy_version, receipt_payload_json
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    decision.receipt.receipt_id,
                    decision.receipt.decision_hash,
                    decision.receipt.request_hash,
                    decision.receipt.policy_hash,
                    decision.receipt.policy_version,
                    json.dumps(payload, ensure_ascii=False, sort_keys=True),
                ),
            )
            self.connection.execute(
                """
                INSERT INTO ong_audit_event(event_id, decision_hash, receipt_id)
                VALUES (?, ?, ?)
                """,
                (
                    f"evt-{uuid.uuid4().hex}",
                    decision.receipt.decision_hash,
                    decision.receipt.receipt_id,
                ),
            )

    def list_events(self, limit: int = DEFAULT_LIST_LIMIT, offset: int = 0) -> list[dict[str, object]]:
        """감사 이벤트를 API 응답에 가까운 dict 형태로 반환한다.

        GC-RSC-009(Collection·메모리 상한): 전체 이력을 무제한 반환하지 않고
        limit을 MAX_LIST_LIMIT으로 강제 clamp한다.
        """

        bounded_limit = max(1, min(limit, MAX_LIST_LIMIT))
        bounded_offset = max(0, offset)
        rows = self.connection.execute(
            """
            SELECT e.event_id, d.decision_hash, d.request_hash, d.policy_version, d.policy_hash, d.decision,
                   d.classification_level, d.signals_json, d.reasons_json, r.receipt_payload_json
            FROM ong_audit_event e
            JOIN ong_policy_decision d ON d.decision_hash = e.decision_hash
            JOIN ong_receipt r ON r.receipt_id = e.receipt_id
            ORDER BY e.created_at, e.event_id
            LIMIT ? OFFSET ?
            """,
            (bounded_limit, bounded_offset),
        ).fetchall()
        events: list[dict[str, object]] = []
        for row in rows:
            events.append(
                {
                    "event_id": row["event_id"],
                    "decision_hash": row["decision_hash"],
                    "request_hash": row["request_hash"],
                    "policy_version": row["policy_version"],
                    "policy_hash": row["policy_hash"],
                    "decision": row["decision"],
                    "classification_level": row["classification_level"],
                    "signals": json.loads(row["signals_json"]),
                    "reasons": json.loads(row["reasons_json"]),
                    "receipt": json.loads(row["receipt_payload_json"]),
                }
            )
        return events

    def get_receipt(self, receipt_id: str) -> dict[str, object] | None:
        """Receipt ID로 저장된 원본 payload를 조회한다."""

        row = self.connection.execute(
            "SELECT receipt_payload_json FROM ong_receipt WHERE receipt_id = ?",
            (receipt_id,),
        ).fetchone()
        if row is None:
            return None
        return dict(json.loads(row["receipt_payload_json"]))

    def verify_receipt(self, receipt_id: str) -> dict[str, object]:
        """저장된 Receipt의 decision_hash와 receipt_id를 재계산해 무결성을 검증한다."""

        payload = self.get_receipt(receipt_id)
        if payload is None:
            return {"valid": False, "receipt_id": receipt_id, "reason": render_message("ONG-RCP-001")}
        try:
            receipt = _receipt_from_payload(payload)
        except (KeyError, TypeError, ValueError):
            return {
                "valid": False,
                "receipt_id": receipt_id,
                "reason": render_message("ONG-RCP-002"),
            }
        expected_decision_hash = canonical_hash(
            {
                "request_hash": receipt.request_hash,
                "policy_hash": receipt.policy_hash,
                "policy_version": receipt.policy_version,
                "actor_id": receipt.actor_id,
                "target": receipt.target,
                "decision": receipt.decision.value,
                "classification_level": receipt.classification_level.value,
                "reasons": list(receipt.reasons),
                "egress_content_hash": receipt.egress_content_hash,
            }
        )
        expected_receipt_id = f"rcpt-{expected_decision_hash[:16]}"
        hash_valid = (
            receipt.decision_hash == expected_decision_hash
            and receipt.receipt_id == expected_receipt_id
        )
        signature_valid = verify_receipt_signature(receipt)
        return {
            "valid": hash_valid and signature_valid,
            "hash_valid": hash_valid,
            "signature_valid": signature_valid,
            "receipt_id": receipt.receipt_id,
            "expected_receipt_id": expected_receipt_id,
            "expected_decision_hash": expected_decision_hash,
            "decision_hash": receipt.decision_hash,
        }


def build_default_centers() -> tuple[PolicyCenter, AuditCenter]:
    """기본 정책이 적재된 PolicyCenter와 같은 DB를 쓰는 AuditCenter를 만든다."""

    connection = connect_database()
    apply_schema(connection)
    policy_center = PolicyCenter(connection)
    policy_center.bootstrap_defaults()
    audit_center = AuditCenter(connection)
    return policy_center, audit_center

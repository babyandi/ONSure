from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Callable, TypeVar


LOGGER = logging.getLogger("onguard")
T = TypeVar("T")


class FailureClass(str, Enum):
    VALIDATION = "VALIDATION"
    POLICY_UNAVAILABLE = "POLICY_UNAVAILABLE"
    STORAGE_FAILURE = "STORAGE_FAILURE"
    INTERNAL_FAILURE = "INTERNAL_FAILURE"


@dataclass(frozen=True)
class Failure:
    code: str
    category: FailureClass
    retryable: bool
    public_message_code: str


class ONGuardError(RuntimeError):
    """내부 예외를 안정적인 오류 계약으로 전달한다."""

    def __init__(self, failure: Failure, *, cause: Exception | None = None) -> None:
        super().__init__(failure.code)
        self.failure = failure
        self.__cause__ = cause


POLICY_UNAVAILABLE = Failure(
    code="ONG-POL-503",
    category=FailureClass.POLICY_UNAVAILABLE,
    retryable=True,
    public_message_code="ONG-POL-001",
)

STORAGE_FAILURE = Failure(
    code="ONG-AUD-503",
    category=FailureClass.STORAGE_FAILURE,
    retryable=True,
    public_message_code="ONG-AUD-503",
)


def fail_closed(call: Callable[[], T], *, failure: Failure = POLICY_UNAVAILABLE) -> T:
    """예외를 성공/빈 값으로 위장하지 않고 분류된 ONGuardError로 변환한다."""

    try:
        return call()
    except ONGuardError:
        raise
    except Exception as exc:
        LOGGER.warning(
            "dependency failure",
            extra={"error_code": failure.code, "failure_class": failure.category.value},
        )
        raise ONGuardError(failure, cause=exc) from exc

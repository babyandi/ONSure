from __future__ import annotations

from .models import DecisionStatus, InformationLevel, PolicyRule


POLICY_VERSION = "2026.07.mvp"


# MVP 기본 정책은 안전한 우선순위를 검증하기 위한 기준선이다.
# 높은 위험 등급이 먼저 평가되도록 priority를 내림차순으로 둔다.
DEFAULT_RULES: tuple[PolicyRule, ...] = (
    PolicyRule(
        rule_id="rule-l5-deny",
        version=POLICY_VERSION,
        priority=100,
        channel="external_llm",
        levels=(InformationLevel.L5,),
        effect=DecisionStatus.DENY,
        reason="L5 최고위험 정보는 외부 LLM 반출을 차단한다.",
        targets=("external-llm",),
    ),
    PolicyRule(
        rule_id="rule-l4-deny",
        version=POLICY_VERSION,
        priority=90,
        channel="external_llm",
        levels=(InformationLevel.L4,),
        effect=DecisionStatus.DENY,
        reason="L4 고위험 정보는 외부 LLM 반출을 차단한다.",
        targets=("external-llm",),
    ),
    PolicyRule(
        rule_id="rule-l3-mask",
        version=POLICY_VERSION,
        priority=80,
        channel="external_llm",
        levels=(InformationLevel.L3,),
        effect=DecisionStatus.MASK,
        reason="L3 중요정보는 마스킹 후 제한적으로 처리한다.",
        targets=("external-llm",),
    ),
    PolicyRule(
        rule_id="rule-l2-review",
        version=POLICY_VERSION,
        priority=70,
        channel="external_llm",
        levels=(InformationLevel.L2,),
        effect=DecisionStatus.REVIEW_REQUIRED,
        reason="L2 제한 정보는 목적과 범위 검토가 필요하다.",
        targets=("external-llm",),
    ),
    PolicyRule(
        rule_id="rule-l0-l1-allow",
        version=POLICY_VERSION,
        priority=10,
        channel="external_llm",
        levels=(InformationLevel.L0, InformationLevel.L1),
        effect=DecisionStatus.ALLOW,
        reason="L0/L1 정보는 MVP 기본 정책상 외부 LLM 사용을 허용한다.",
        targets=("external-llm",),
    ),
)

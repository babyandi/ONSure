from __future__ import annotations

import hashlib
import json
import base64
import os

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature

from .models import DecisionStatus, EgressRequest, InformationLevel, PolicyRule, Receipt


SIGNATURE_ALGORITHM = "Ed25519"
PRIVATE_KEY_ENV = "ONGUARD_RECEIPT_PRIVATE_KEY_B64"


def _load_private_key() -> tuple[Ed25519PrivateKey, str]:
    """운영 키가 없으면 프로세스 한정 임시키를 만들고 비운영 key id로 명시한다."""

    encoded = os.environ.get(PRIVATE_KEY_ENV, "")
    if encoded:
        try:
            raw = base64.b64decode(encoded, validate=True)
            if len(raw) != 32:
                raise ValueError("Ed25519 private key must be 32 raw bytes")
            key = Ed25519PrivateKey.from_private_bytes(raw)
            provenance = "configured"
        except (ValueError, TypeError) as exc:
            raise RuntimeError("invalid ONGUARD_RECEIPT_PRIVATE_KEY_B64") from exc
    else:
        key = Ed25519PrivateKey.generate()
        provenance = "ephemeral"
    public = key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    fingerprint = hashlib.sha256(public).hexdigest()[:24]
    return key, f"{provenance}-ed25519-{fingerprint}"


_SIGNING_KEY, SIGNING_KEY_ID = _load_private_key()
_VERIFYING_KEY = _SIGNING_KEY.public_key()


def canonical_hash(value: object) -> str:
    """동일 입력이 항상 동일 SHA-256을 갖도록 정렬 JSON으로 해시한다."""

    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _signature_payload(
    *,
    receipt_id: str,
    request_hash: str,
    policy_hash_value: str,
    decision_hash: str,
    policy_version: str,
    actor_id: str,
    target: str,
    decision: str,
    classification_level: str,
    reasons: tuple[str, ...],
    egress_content_hash: str,
    signature_algorithm: str,
    signing_key_id: str,
) -> bytes:
    payload = {
        "receipt_id": receipt_id,
        "request_hash": request_hash,
        "policy_hash": policy_hash_value,
        "decision_hash": decision_hash,
        "policy_version": policy_version,
        "actor_id": actor_id,
        "target": target,
        "decision": decision,
        "classification_level": classification_level,
        "reasons": list(reasons),
        "egress_content_hash": egress_content_hash,
        "signature_algorithm": signature_algorithm,
        "signing_key_id": signing_key_id,
    }
    return json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def verify_receipt_signature(receipt: Receipt) -> bool:
    """현재 등록된 Ed25519 공개키로 Receipt 전체 결속을 검증한다."""

    if (
        receipt.signature_algorithm != SIGNATURE_ALGORITHM
        or receipt.signing_key_id != SIGNING_KEY_ID
    ):
        return False
    try:
        signature = base64.b64decode(receipt.signature, validate=True)
        _VERIFYING_KEY.verify(
            signature,
            _signature_payload(
                receipt_id=receipt.receipt_id,
                request_hash=receipt.request_hash,
                policy_hash_value=receipt.policy_hash,
                decision_hash=receipt.decision_hash,
                policy_version=receipt.policy_version,
                actor_id=receipt.actor_id,
                target=receipt.target,
                decision=receipt.decision.value,
                classification_level=receipt.classification_level.value,
                reasons=receipt.reasons,
                egress_content_hash=receipt.egress_content_hash,
                signature_algorithm=receipt.signature_algorithm,
                signing_key_id=receipt.signing_key_id,
            ),
        )
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def policy_hash(rules: tuple[PolicyRule, ...]) -> str:
    """정책 Rule 집합의 기준 해시를 만든다."""

    # Rule 등록 순서와 무관하게 같은 정책이면 같은 해시가 나오도록 정렬한다.
    return canonical_hash(
        [
            {
                "rule_id": rule.rule_id,
                "version": rule.version,
                "priority": rule.priority,
                "channel": rule.channel,
                "levels": [level.value for level in rule.levels],
                "effect": rule.effect.value,
                "reason": rule.reason,
                "actor_ids": sorted(rule.actor_ids),
                "purpose_keywords": sorted(rule.purpose_keywords),
                "targets": sorted(rule.targets),
            }
            for rule in sorted(rules, key=lambda item: (-item.priority, item.rule_id))
        ]
    )


def build_receipt(
    request: EgressRequest,
    rules: tuple[PolicyRule, ...],
    policy_version: str,
    decision: DecisionStatus,
    classification_level: InformationLevel,
    reasons: tuple[str, ...],
    egress_content_hash: str,
) -> Receipt:
    """요청, 정책, 판정 결과를 묶어 사후 검증 가능한 Receipt를 생성한다."""

    request_digest = canonical_hash(request.__dict__)
    rules_digest = policy_hash(rules)
    # decision_hash는 Receipt 검증의 중심값이다. 요청/정책/판정/사유가 바뀌면 즉시 달라진다.
    decision_digest = canonical_hash(
        {
            "request_hash": request_digest,
            "policy_hash": rules_digest,
            "policy_version": policy_version,
            "actor_id": request.actor_id,
            "target": request.target,
            "decision": decision.value,
            "classification_level": classification_level.value,
            "reasons": list(reasons),
            "egress_content_hash": egress_content_hash,
        }
    )
    receipt_id = f"rcpt-{decision_digest[:16]}"
    signature = base64.b64encode(
        _SIGNING_KEY.sign(
            _signature_payload(
                receipt_id=receipt_id,
                request_hash=request_digest,
                policy_hash_value=rules_digest,
                decision_hash=decision_digest,
                policy_version=policy_version,
                actor_id=request.actor_id,
                target=request.target,
                decision=decision.value,
                classification_level=classification_level.value,
                reasons=reasons,
                egress_content_hash=egress_content_hash,
                signature_algorithm=SIGNATURE_ALGORITHM,
                signing_key_id=SIGNING_KEY_ID,
            )
        )
    ).decode("ascii")
    return Receipt(
        receipt_id=receipt_id,
        request_hash=request_digest,
        policy_hash=rules_digest,
        decision_hash=decision_digest,
        policy_version=policy_version,
        actor_id=request.actor_id,
        target=request.target,
        decision=decision,
        classification_level=classification_level,
        reasons=reasons,
        egress_content_hash=egress_content_hash,
        signature_algorithm=SIGNATURE_ALGORITHM,
        signing_key_id=SIGNING_KEY_ID,
        signature=signature,
    )

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class DecisionStatus(str, Enum):
    """외부 반출 요청에 대한 최종 정책판정 상태."""

    ALLOW = "ALLOW"
    DENY = "DENY"
    MASK = "MASK"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    UNKNOWN = "UNKNOWN"


class InformationLevel(str, Enum):
    """ONGuard 정보등급. L5로 갈수록 외부 반출 위험이 높다."""

    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"
    L4 = "L4"
    L5 = "L5"


@dataclass(frozen=True)
class EgressRequest:
    """외부 LLM 등 외부 채널로 나가려는 단일 요청."""

    actor_id: str
    purpose: str
    target: str
    channel: str
    content: str
    request_id: str = ""


@dataclass(frozen=True)
class ClassificationResult:
    """탐지 규칙이 산출한 최고 정보등급과 탐지 신호 목록."""

    level: InformationLevel
    signals: tuple[str, ...] = ()


@dataclass(frozen=True)
class PolicyRule:
    """정책 버전에 종속되는 단일 Rule 계약."""

    rule_id: str
    version: str
    priority: int
    channel: str
    levels: tuple[InformationLevel, ...]
    effect: DecisionStatus
    reason: str
    active: bool = True
    actor_ids: tuple[str, ...] = ()
    purpose_keywords: tuple[str, ...] = ()
    targets: tuple[str, ...] = ()


@dataclass(frozen=True)
class Receipt:
    """정책판정 결과를 재검증할 수 있게 고정한 감사 증적."""

    receipt_id: str
    request_hash: str
    policy_hash: str
    decision_hash: str
    policy_version: str
    actor_id: str
    target: str
    decision: DecisionStatus
    classification_level: InformationLevel
    reasons: tuple[str, ...]
    egress_content_hash: str
    signature_algorithm: str
    signing_key_id: str
    signature: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "receipt_id": self.receipt_id,
            "request_hash": self.request_hash,
            "policy_hash": self.policy_hash,
            "decision_hash": self.decision_hash,
            "policy_version": self.policy_version,
            "actor_id": self.actor_id,
            "target": self.target,
            "decision": self.decision.value,
            "classification_level": self.classification_level.value,
            "reasons": list(self.reasons),
            "egress_content_hash": self.egress_content_hash,
            "signature_algorithm": self.signature_algorithm,
            "signing_key_id": self.signing_key_id,
            "signature": self.signature,
        }


@dataclass(frozen=True)
class PolicyDecision:
    """탐지 결과, 정책판정, 사유, Receipt를 묶은 판정 결과."""

    decision: DecisionStatus
    classification: ClassificationResult
    reasons: tuple[str, ...]
    receipt: Receipt
    egress_content: str = ""
    audit_persisted: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision.value,
            "classification_level": self.classification.level.value,
            "signals": list(self.classification.signals),
            "reasons": list(self.reasons),
            "receipt": self.receipt.to_dict(),
            "egress_content": self.egress_content,
            "egress_content_hash": self.receipt.egress_content_hash,
            "audit_persisted": self.audit_persisted,
        }

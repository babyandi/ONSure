# ONGuard Receipt 구조

## Receipt 필드

| 필드 | 설명 |
|---|---|
| `receipt_id` | Receipt 고유 ID |
| `request_hash` | 요청 입력 정규화 해시 |
| `policy_hash` | 적용 정책 집합 해시 |
| `decision_hash` | 판정 결과 해시 |
| `policy_version` | 정책 버전 |
| `actor_id` | 요청 주체 |
| `target` | 대상 외부 LLM 또는 SaaS AI |
| `decision` | 정책 판정 |
| `classification_level` | 정보등급 |
| `reasons` | 판정 사유 |
| `egress_content_hash` | 실제 반출 문자열의 정규화 해시 |
| `signature_algorithm` | 서명 알고리즘. 현재 `Ed25519` |
| `signing_key_id` | 검증키 지문과 키 출처를 포함한 식별자 |
| `signature` | 위 필드 전체를 정렬 JSON으로 결속한 Base64 Ed25519 서명 |

## 재현성 기준

동일한 요청, 동일한 정책 버전, 동일한 정책 Rule 집합은 동일한 `decision_hash`를 생성해야 한다.

## 서명·키 운영 기준

- 운영 환경은 `ONGUARD_RECEIPT_PRIVATE_KEY_B64`에 raw 32-byte Ed25519 개인키를 Base64로 제공한다.
- 키가 없으면 개발·시험용 프로세스 한정 임시키를 생성하고 `signing_key_id`를 `ephemeral-`로 시작해 운영 증적과 구분한다.
- 검증은 해시 재계산과 Ed25519 서명이 모두 통과해야 `valid=true`가 된다.
- 서명 대상에는 사용자, 외부 대상, 정책 버전, 판정, 정보등급, 사유, 실제 반출 Hash가 모두 포함된다.
- 운영 키회전·폐기·HSM/KMS 보관·과거 공개키 Registry는 다음 운영 Gate이며, 임시키 Receipt는 FinalLock 근거가 될 수 없다.

## Append-only 기준

- SQLite MVP는 요청·판정·Receipt·감사 이벤트 테이블의 `UPDATE`와 `DELETE`를 Trigger로 거부한다.
- PostgreSQL 운영 스키마도 동일 테이블에 DB Trigger와 `PUBLIC` 권한 회수를 적용한다.
- 스키마 소유자·DBA의 `TRUNCATE`·DDL 권한은 별도 운영계정과 변경승인으로 분리해야 하며, 현재 자체검증만으로 외부 감사 완료를 주장하지 않는다.

# ONGuard AI 위험 시나리오·통제 매트릭스

## 목적

이 문서는 AI 개발 방법론과 NIST AI RMF의 Map, Measure, Manage 관점에 맞춰 ONGuard의 주요 AI 위험 시나리오와 통제 수단을 연결한다.

## 위험 시나리오 목록

| 위험 ID | 위험 시나리오 | 영향 | 기본 통제 | 잔여 위험 |
|---|---|---|---|---|
| `AI-RSK-001` | 개인정보가 외부 LLM 프롬프트로 반출 | 규제 위반, 고객 피해 | L4 탐지, `DENY`, Receipt | 오탐·미탐 가능성 |
| `AI-RSK-002` | 고객·계약·계좌 정보가 업무 목적 없이 반출 | 내부통제 위반 | L3 탐지, `MASK` 또는 `REVIEW_REQUIRED` | 목적 판단 한계 |
| `AI-RSK-003` | 핵심기술·전략 정보가 외부 AI에 입력 | 영업비밀 유출 | L5 탐지, `DENY` | 우회 표현 가능성 |
| `AI-RSK-004` | 정책 Rule 누락으로 허용 오판 | 통제 실패 | Rule 없음 `UNKNOWN` | 정책 품질 의존 |
| `AI-RSK-005` | 감사 Receipt 저장 실패 | 사후 추적 불가 | 저장 실패 시 허용 금지 | 운영 장애 대응 필요 |
| `AI-RSK-006` | 과도한 차단으로 업무 생산성 저하 | 사용자 우회 증가 | 예외 승인 워크플로 | 승인 지연 |
| `AI-RSK-007` | 외부 LLM 대상 식별 실패 | 통제 사각지대 | target 필수화, 대상별 감사 | SaaS 대상 변화 |
| `AI-RSK-008` | 프롬프트 변형으로 탐지 우회 | 미탐 | 적대 Fixture, 패턴 개선 | 지속 개선 필요 |

## 통제 매트릭스

| 통제 ID | 통제명 | 적용 위험 | 구현 위치 | 검증 방법 |
|---|---|---|---|---|
| `CTL-CLS-001` | L0~L5 정보등급 분류 | `AI-RSK-001`~`AI-RSK-003` | Classification Engine | 샘플·적대 Fixture |
| `CTL-POL-001` | 정책 Rule 기반 판정 | `AI-RSK-001`~`AI-RSK-004` | Policy Center | 정책 경로 테스트 |
| `CTL-FC-001` | Fail-Closed | `AI-RSK-004`, `AI-RSK-005` | Egress Guard | 오류 주입 테스트 |
| `CTL-RCP-001` | Receipt 생성 | `AI-RSK-005` | Audit Center | 재현성 테스트 |
| `CTL-REV-001` | 예외 승인 | `AI-RSK-006` | Workflow | 승인/반려 시나리오 |
| `CTL-MON-001` | 이상 사용 모니터링 | `AI-RSK-007`, `AI-RSK-008` | Operation Guard | 운영 이벤트 탐지 |

## 측정 지표

| 지표 | 설명 | 목표 |
|---|---|---|
| 오탐률 | 허용 가능한 요청을 차단·검토로 판정한 비율 | MVP 기준 측정부터 시작 |
| 미탐률 | 차단해야 할 요청을 허용한 비율 | 0건 목표 |
| Receipt 생성률 | 전체 판정 중 Receipt가 생성된 비율 | 100% |
| Fail-Closed 작동률 | 오류 주입 시 허용으로 승격되지 않은 비율 | 100% |
| 정책 미일치율 | Rule 없음으로 `UNKNOWN` 처리된 비율 | 정책 개선 대상으로 관리 |

## OBuilder 검토 기준

OBuilder는 본 매트릭스를 기준으로 위험별 테스트 Fixture와 통제별 검증 케이스를 생성해야 한다. 위험 ID와 통제 ID는 테스트명, Receipt, 감사 이벤트에 추적 가능하게 남아야 한다.

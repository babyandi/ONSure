# ONGuard 본 개발 1차 범위

## 목적

1차 본 개발은 ONGuard의 완성형 Goal State 전체가 아니라, 외부 LLM 반출통제의 핵심 폐쇄 루프를 실제 동작 가능한 MVP로 구현하는 것이다.

## 범위

| 영역 | 1차 구현 내용 | 완료 기준 |
|---|---|---|
| Policy Center | 정책 버전 등록, Rule 등록, 활성 버전 조회, Rule 조회 | 활성 정책으로 판정이 수행되고 커스텀 Rule이 판정에 반영된다. |
| Classification Engine | 민감정보 및 우회 패턴 탐지 규칙 확장 | 주민번호, 계좌, 이메일, 카드, 토큰, 프롬프트 우회 문구를 등급화한다. |
| Egress Guard | 외부 LLM 요청 판정 API 구현 | `ALLOW`, `DENY`, `MASK`, `REVIEW_REQUIRED`, `UNKNOWN` 응답과 Receipt를 반환한다. |
| Audit Center | Receipt 저장, 조회, 검증 | 저장된 Receipt를 다시 읽고 무결성 검증을 수행한다. |
| DB Schema | 정책, 요청, 판정, Receipt 테이블과 인덱스 적용 | 코드에서 스키마를 적용하고 테스트에서 핵심 테이블 존재를 확인한다. |
| API 테스트 | 정책판정, 정책 등록, 응답 계약 테스트 | unittest 기준 전체 통과한다. |
| 실패/우회 테스트 | 필수 입력 누락, 미등록 채널, 프롬프트 우회 차단 | 허용으로 승격되지 않는다. |
| TEVV 리포트 | 1차 검증 결과 작성 | 테스트 결과와 잔여 위험을 문서화한다. |

## 제외 범위

| 제외 항목 | 사유 |
|---|---|
| Java/Spring Boot 본제품 서버 | 1차는 정책·DB·Receipt 계약을 검증하는 Python 기준 구현체로 진행한다. |
| 관리자 Web UI | Policy Center API 계약이 안정화된 뒤 착수한다. |
| 실제 외부 LLM Proxy 연계 | 반출 전 판정 API가 먼저 확정되어야 한다. |
| 인증/권한 연동 | 운영 배포 단계에서 IAM/SSO 기준과 함께 설계한다. |
| 운영 DB 마이그레이션 도구 | 현재는 스키마 파일과 코드 적용 함수로 기준선을 고정한다. |

## 개발 언어 기준

Python 구현은 MVP 기준 구현체이자 TEVV 하네스다. 본제품 운영 백엔드는 Java/Spring Boot로 확장하는 것이 권장되며, 1차 결과는 Java 이식 전 계약 검증 기준선으로 사용한다.

### Java 이식 기준선 (`babyandi/ORUDA` `products/obuilder` 참조)

Java/Spring Boot 이식 시점에는 별도로 새 기준을 정하지 않고, `babyandi/ORUDA` 저장소의 `products/obuilder`가 이미 정의해 둔 eGovFrame 기준선을 따른다. ORUDA는 OBuilder(코드 생성기) 관점에서 이 조합의 정합성을 이미 검증해 두었다.

| 항목 | 값 | 출처 |
|---|---|---|
| Java | `>= 17` | `products/obuilder/compatibility/SPRING_EGOV_COMPATIBILITY_MATRIX...json` (`EGOV5_REFERENCE_BASELINE` 프로필) |
| Spring Framework | `6.2.11` | 위와 동일 |
| Spring Security | `6.x` | 위와 동일 |
| eGovFrame | `5.0.0` | 위와 동일, 공식 pin은 `products/obuilder/references/egov/EGOVFRAME_OFFICIAL_REFERENCE_REGISTRY...json` |
| Servlet 네임스페이스 | Jakarta만 허용(javax 혼용 금지) | 위와 동일 |
| 빌드 도구 | Maven `>= 3.6` | 위와 동일 |

명시적으로 금지된 조합(같은 매트릭스의 `UNSUPPORTED` 프로필): eGovFrame 5.x + Java 17 미만, eGovFrame 5.x + javax 네임스페이스, Spring 7.x(아직 공식/실행 증거 없음).

참고용 Java 참조 구현: `products/obuilder/runtime-canary/src/main/java/com/oruda/obuilder/runtimecanary/`(`EgovCanaryService.java`, `EgovRuntimeConfiguration.java`, `SecurityConfiguration.java` 등).

이 기준선은 ORUDA 쪽에서도 아직 `CONDITIONAL`(정적 정합성만 검증, 빌드·기동·통합 실행 증거는 미확보) 상태이며 `generator_allowed: false`다. ONGuard의 Java 이식 착수 시점에 ORUDA 쪽 상태가 `SUPPORTED`로 승격됐는지 다시 확인해야 한다.

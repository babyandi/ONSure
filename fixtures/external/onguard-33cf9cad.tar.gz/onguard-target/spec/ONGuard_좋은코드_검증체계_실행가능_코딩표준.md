# ONGuard 좋은 코드 검증체계 및 실행 가능한 코딩 표준

좋은 코드의 정의에서 Rule·Detector·Fixture·Harness·독립 검증까지

**v1.0 · 2026-07-24 · Goal State 상세 설계**


## 1. 문서 목적과 권위


이 문서는 ONGuard가 AI 생성 코드를 포함한 소프트웨어를 ‘좋은 코드’인지 판정하기 위한 Goal State 규범이다. 특정 언어의 스타일 가이드가 아니라 품질 속성에서 실행 가능한 규칙과 검증 증적까지 이어지는 최상위 계약이다.


핵심 판정은 ‘문서에 적혀 있는가’가 아니라 ‘위반 코드가 빌드·병합·배포·완료 판정을 통과하지 못하는가’이다. 자연어 자기보고는 증거가 아니다.


MVP는 이 문서의 축소 구현일 뿐이며, 구현되지 않은 항목은 PASS가 아니라 NOT_RUN 또는 NOT_IMPLEMENTED로 남긴다.


## 2. 좋은 코드의 최상위 정의


좋은 코드는 정상 경로에서 실행되는 코드를 뜻하지 않는다. 요구사항을 정확히 수행하고, 잘못된 입력·상태·권한·의존성·자원 포화·부분 실패·중복·재시작 상황에서 데이터와 사용자를 안전하게 보호하며, 변경·운영·복구·감사를 가능하게 하고, 그 사실을 독립적으로 재현할 수 있는 코드다.


좋은 코드 판정은 코드 본문뿐 아니라 요구사항, API·데이터·이벤트 계약, 설정과 기본값, DB 스키마·마이그레이션, 빌드·의존성·컨테이너·배포, 운영 절차, 테스트와 검증기 자체를 포함한다.


| ID | 품질 속성 | 규범적 의미 |
|---|---|---|
| GC-QA-01 | 요구사항 정확성 | 명시·암묵 업무규칙, 경계값, 상태전이를 정확히 구현한다. |
| GC-QA-02 | 결과 완전성 | 부분 성공·누락·중복·순서 역전을 탐지하고 결과를 독립 검증한다. |
| GC-QA-03 | 입력·상태 무결성 | 입력·스키마·전제조건·상태전이를 검증 전에는 반영하지 않는다. |
| GC-QA-04 | 보안·개인정보 | 최소권한, 비밀 보호, 주입 방지, 목적·보존·삭제 통제를 적용한다. |
| GC-QA-05 | 자원 안전성 | 모든 자원의 소유권, 상한, 해제, 포화·종료 동작을 명시한다. |
| GC-QA-06 | 동시성·트랜잭션 | 경쟁, 교착, 가시성, 원자성, 격리, 멱등성을 보장한다. |
| GC-QA-07 | 장애 격리·복구 | timeout, deadline, bulkhead, circuit breaker, 재시작 복구를 보장한다. |
| GC-QA-08 | 성능·확장성 | 복잡도·처리량·지연·메모리·I/O 예산과 퇴행 기준을 둔다. |
| GC-QA-09 | 변경·유지보수성 | 응집도, 결합도, 계약, 가독성, 제거 가능성, 호환성을 관리한다. |
| GC-QA-10 | 관측·감사성 | 로그·메트릭·추적·감사증적이 원인과 결과를 재구성하게 한다. |
| GC-QA-11 | 배포·공급망 안전 | 빌드 재현성, SBOM, 서명, 의존성·라이선스·출처를 검증한다. |
| GC-QA-12 | 시험·자동입증 가능성 | 규칙을 자동 탐지·실행 시험·독립 재현하고 Receipt로 결속한다. |


## 3. 정방향·역방향 이중 루프


정방향: 좋은 코드 정의 → 품질 속성 → 실패 유형 → 실질 코딩 규칙 → 언어·프레임워크 규칙 → 탐지기 → Fixture → Harness → Evidence → 독립 판정.


역방향: Harness 결과 → Fixture·Oracle → Detector → Rule ID → 실패 유형 → 품질 속성 → 좋은 코드 정의.


정방향은 누락을 찾고, 역방향은 무관한 시험·허위 증명·추적 단절을 찾는다. 두 방향 중 하나라도 단절되면 해당 주장은 미입증이다.


## 4. AI 생성 코드에 대한 강제 원칙


AI에게 전체 규칙을 기억하라고 요구하지 않는다. 작업 전 적용 규칙을 좁혀 계약으로 제공하고, 생성 중에는 승인된 Factory·Template·Client를 사용하게 하며, 생성 후에는 독립 Gate가 차단한다.


AI의 ‘규칙을 지켰다’는 설명, 자체 작성 테스트만의 통과, 같은 모델·같은 Oracle의 재검토는 독립 증거가 아니다.


가짜 API, 존재하지 않는 라이브러리 옵션, 불필요한 중복 코드, 테스트 약화, 오류를 정상값으로 바꾸는 편의 구현을 AI 특유 위험으로 별도 탐지한다.


## 5. 규칙을 실행 가능하게 만드는 계약


모든 규칙은 고정 Rule ID, 적용 범위, 심각도, 허용·금지 패턴, 탐지기, 정상·위반·경계·우회 Fixture, 런타임 시험, Oracle, 예외 승인, Evidence 필드를 가진다.


정적 분석으로 증명할 수 없는 동시성·장애·복구·부분 실패·성능·장기 누수는 실행 Harness로 넘긴다. 탐지 불가능하다는 이유로 규칙을 제거하지 않는다.


| 필드 | 필수 의미 |
|---|---|
| rule_id | 영구 식별자. 의미 변경 시 새 ID 발급 |
| title / intent | 규칙명과 방지하려는 실패 |
| scope | 언어·프레임워크·파일·API·상황 |
| severity | CRITICAL / MAJOR / MINOR |
| normative_statement | MUST/MUST NOT/SHOULD와 fail-closed 의미 |
| allowed_patterns | 허용 코드·Factory·설정 예시 |
| forbidden_patterns | 금지 코드·우회·변형 예시 |
| detectors | AST/Semgrep/Checkstyle/SpotBugs/SCA/구성 검사 |
| fixtures | positive/negative/boundary/evasion/mutation |
| runtime_tests | 장애·부하·동시성·재시작·복구 시험 |
| oracle | 기대 결과와 독립 판정식 |
| exceptions | 승인자·사유·범위·만료·취소·재사용 금지 |
| evidence | HEAD·Rule·Detector·Fixture·환경·결과 Hash |


## 6. 검증 계층과 Gate


L0 권위·입력 무결성 → L1 계약·스키마 → L2 정적 규칙 → L3 단위·속성 시험 → L4 통합·상태전이 → L5 장애·적대·부하·동시성 → L6 재시작·복구 → L7 공급망·배포 → L8 OTester 독립 재현 → L9 OAudit 계보·충분성 감사 순으로 실행한다.


앞 단계의 CRITICAL/MAJOR 실패, 필수 NOT_RUN, Hash 불일치가 있으면 뒤 단계의 성공으로 상쇄하지 않는다. 결과는 fail-closed로 HOLD한다.


## 7. Detector와 Fixture 설계


Detector는 정규식 하나에 의존하지 않고 가능하면 AST·타입·데이터 흐름·구성 해석을 결합한다. 탐지기 자체도 mutation과 우회 Fixture로 검증한다.


규칙별 최소 Fixture는 positive, obvious negative, boundary, evasion, framework-default, version-variant이다. 실행 규칙은 장애 주입, 포화, 취소, 강제 종료, 재시작, 중복 전달, 순서 역전, 부분 저장을 포함한다.


오탐은 억제 파일로 숨기지 않고 승인자·사유·정확한 범위·만료일을 가진 예외 Receipt로 관리한다. 만료·범위 불명·재사용은 FAIL이다.


## 8. Evidence와 Receipt


Receipt는 repository, branch, commit HEAD, source tree hash, policy/rule set digest, detector version, fixture digest, harness digest, 실행 환경, 의존성 lock/SBOM, 시작·종료 시각, 원시 결과 hash, 판정, 예외와 승인자를 결속한다.


Evidence는 결정 전에 생성돼야 하며, 결과 이후 수정된 규칙·테스트·Golden·환경은 같은 실행의 증거로 사용할 수 없다. 재실행은 새 Receipt를 만든다.


## 9. 독립 검증


OTester는 생성 주체와 분리된 실행·Oracle로 결과를 재현한다. OAudit는 OTester의 PASS를 재실행 없이 신뢰하지 않고, 증거의 출처·완전성·시간 순서·Hash·예외 유효성을 감사한다.


OTester와 OAudit가 동일 구현·동일 Oracle·동일 생성 모델의 판단을 재사용하면 공통 오판 위험 때문에 독립성이 성립하지 않는다.


## 10. 완료·중지 조건


분류·설계 검토는 신규 항목이 기존 품질 속성·실패 유형·Rule·Oracle·Fixture에 전부 귀속되고 새로운 상위 분류가 반복적으로 나오지 않을 때 수렴으로 본다.


전체 완료는 동일 HEAD·동일 Rule Set·동일 환경에서 필수 Harness CLEAN 2회, 독립 OTester·OAudit CLEAN 2회, CRITICAL=0, MAJOR=0, 필수 NOT_RUN=0, BLOCKED=0, 미결 예외·추적 단절=0일 때만 허용한다.


자동 PASS·FinalLock·Production GO는 위 조건 전에는 금지한다. 설계 수렴과 구현·실행 증명 완료를 혼동하지 않는다.


## 11. 실질적 자원·오동작 방지 코딩 규칙


| Rule ID | 대상 | 필수 구현 계약 |
|---|---|---|
| GC-RSC-001 | Queue | 유한 용량, 명시적 거부 정책, enqueue timeout, DLQ, 재처리·멱등성, 길이·대기·거부 관측 |
| GC-RSC-002 | DB 자원 | Connection/Statement/ResultSet try-with-resources, Pool 상한·획득 timeout, leak 탐지 |
| GC-RSC-003 | 트랜잭션 | 쓰기 경계·rollback·timeout·격리 수준, 외부 장기 호출 배제, 교착 재시도 상한 |
| GC-RSC-004 | 파일·스트림 | Stream 닫기, 크기·압축폭탄·경로 검증, 임시 파일 정리, 검증 후 원자 이동 |
| GC-RSC-005 | HTTP·소켓 | 연결/읽기/쓰기/전체 deadline, Body 닫기, Pool 상한, 응답 크기·재시도 제한 |
| GC-RSC-006 | Thread·Executor | 임의 Thread 금지, 유한 Pool·Queue, timeout·취소·종료·ThreadLocal 정리 |
| GC-RSC-007 | Lock | 획득 timeout, 순서 고정, finally 해제, 최소 범위, lease·fencing token |
| GC-RSC-008 | Cache | 항목/메모리 상한, TTL·eviction, stampede 방지, 버전·민감정보 삭제 |
| GC-RSC-009 | Collection·메모리 | 페이지/커서/스트림, 크기 상한, listener 해제, Heap 독점 방지 |
| GC-RSC-010 | 반복·배치 | 최대 반복·시간·backoff, cursor 반복 탐지, checkpoint, poison record 격리 |
| GC-RSC-011 | Scheduler | 중첩·misfire·재실행 정책, 클러스터 중복 방지, heartbeat·이력 |
| GC-RSC-012 | 외부 호출 | 상위 deadline 예산, circuit breaker·bulkhead, 스키마/크기/Content-Type 검증 |
| GC-RSC-013 | 비동기 작업 | 예외 소비, fire-and-forget 금지, 작업상태 영속화, 취소 전파, 정확한 ACCEPTED |
| GC-RSC-014 | 로그 | 크기·보관·rate limit, 비밀·원문 차단, 감사로그 분리와 실패 정책 |
| GC-RSC-015 | 날짜·시간 | 저장 표준시간, 표시 변환, 단조시간 timeout, Clock 주입, 월말·윤년 시험 |
| GC-RSC-016 | 숫자·금액 | 정확 십진, 단위·통화·반올림 계약, overflow·경계값·독립 합계 검증 |
| GC-RSC-017 | Null·기본값 | 없음의 의미 구분, 임의 정상값 금지, 중요 미확정값 fail-closed |
| GC-RSC-018 | API 제한 | Body/Header/Page/Batch/Rate/Concurrency/시간 예산, 멱등성 키 |
| GC-RSC-019 | 종료·재기동 | 신규 수신 중단, 유예시간, 상태 저장, 자원 역순 종료, 강제종료 복구 |
| GC-RSC-020 | 소유권 공통 | 누가 생성하는가→최대 얼마인가→누가 언제 닫는가→포화·실패·종료 시 무엇을 하는가 |


공통 질문은 항상 다음 순서로 적용한다.

> 누가 생성하는가 → 최대 얼마까지 허용하는가 → 누가 언제 닫는가 → 실패·포화·취소·종료 시 어떻게 안전하게 처리하는가


## 12. 자동 차단 금지 패턴


| Rule ID | 차단 대상 |
|---|---|
| GC-BAN-001 | 무제한 LinkedBlockingQueue·무제한 Thread·상한 없는 Cache/Map/세션 |
| GC-BAN-002 | timeout/deadline 없는 외부 호출·DB Connection 획득·Lock 대기 |
| GC-BAN-003 | 닫히지 않는 DB·Stream·HTTP Body·Executor·Subscription |
| GC-BAN-004 | 종료조건 없는 while(true), 무한 polling·재시도·전체 데이터 조회 |
| GC-BAN-005 | catch(Exception) 뒤 성공·null·0·빈 목록 반환 또는 예외 기록 후 계속 반영 |
| GC-BAN-006 | 검증 전 DB 저장, 트랜잭션 안 장기 외부 호출, 성공 ACK 뒤 비영속 처리 |
| GC-BAN-007 | 비동기 예외 유실, 취소 미전파, 결과 순서·중복 무시 |
| GC-BAN-008 | 자동 Golden/Snapshot 갱신, 테스트 skip·삭제·assertion 완화 |
| GC-BAN-009 | 가짜 API·존재하지 않는 옵션·미사용 코드·중복 구현·근거 없는 기본값 |
| GC-BAN-010 | 비밀·개인정보·대형 요청/응답·SQL 파라미터 원문 로그 |


## 13. 시큐어코딩·웹 보안·모의해킹 규칙


| Rule ID | 영역 | 필수 보안 계약 |
|---|---|---|
| GC-SEC-001 | 시큐어코딩 기준선 | CWE·OWASP Top 10·OWASP ASVS·언어별 보안약점을 Rule ID와 Detector로 매핑한다. |
| GC-SEC-002 | 입력·출력 | 서버 측 allowlist 검증, canonicalization, context별 output encoding, parameterized query를 강제한다. |
| GC-SEC-003 | 인증·세션 | 강한 인증, 세션 고정 방지, 로그인 후 ID 재발급, 유휴·절대 만료, 로그아웃·비밀번호 변경 시 폐기 |
| GC-SEC-004 | 권한·객체 접근 | 모든 요청에서 서버 측 권한·tenant·소유권 검증, IDOR/BOLA·기능권한 우회 차단 |
| GC-SEC-005 | Cookie | 인증 Cookie에 Secure·HttpOnly·적정 SameSite, 최소 Domain/Path, 만료·회전·크기 제한 |
| GC-SEC-006 | Cross-domain/CORS | 정확한 Origin allowlist, credential 사용 시 wildcard 금지, preflight·method·header 최소 허용 |
| GC-SEC-007 | CSP·inline | unsafe-inline/unsafe-eval 기본 금지, nonce/hash 기반 허용, 동적 코드 실행·DOM XSS sink 탐지 |
| GC-SEC-008 | CSRF | 상태 변경 요청에 CSRF token 또는 동등 보호, Origin/Referer 검증, SameSite만 단독 방어로 신뢰 금지 |
| GC-SEC-009 | 보안 Header | HSTS, CSP, frame-ancestors, nosniff, Referrer-Policy, Permissions-Policy 기준선 |
| GC-SEC-010 | 파일·직렬화 | 형식·magic byte·크기·저장경로 검증, 실행 차단, 안전하지 않은 역직렬화 금지 |
| GC-SEC-011 | SSRF·외부 연결 | scheme/host/port allowlist, DNS rebinding·redirect 재검증, metadata/private network 차단 |
| GC-SEC-012 | 비밀·암호 | 하드코딩 금지, 관리 저장소·회전, 검증된 알고리즘·CSPRNG, 평문·약한 해시 금지 |
| GC-SEC-013 | 오류·로그 | 내부 구조·stack·비밀 노출 금지, 감사 이벤트 무결성·rate limit·민감정보 마스킹 |
| GC-SEC-014 | 의존성·공급망 | SCA·SBOM·provenance·signature·license, typosquatting·dependency confusion 차단 |
| GC-SEC-015 | 모의해킹 | 인증/인가, 세션, 입력, API, 파일, 업무로직, race, cloud 경계를 black/gray-box로 검증 |
| GC-SEC-016 | Kali 도구 운용 | Kali Linux 기반 도구는 승인된 격리 대상·시간·트래픽 상한에서만 실행하고 원시 증적을 보존한다. |
| GC-SEC-017 | DAST·퍼징 | 인증 상태별 crawl, API schema fuzz, boundary/malformed/large payload, 재현 가능한 seed 보존 |
| GC-SEC-018 | 보안 회귀 | 발견 취약점은 재현 Fixture와 Rule로 승격하고 수정 후 전체 회귀·재공격을 수행한다. |


### 13.1 Cookie 판정 세부기준

- 인증·세션 Cookie는 `Secure`, `HttpOnly`, 업무에 맞는 `SameSite`를 필수로 한다.
- `Domain`은 가능한 생략해 host-only로 만들고, 필요 시 허용된 최소 상위 도메인만 사용한다.
- `Path`는 최소 범위, 만료는 유휴·절대 만료를 함께 적용하며 로그인·권한변경 시 회전한다.
- `SameSite=None`은 cross-site 요구가 입증되고 `Secure`가 함께 설정된 경우만 허용한다.
- Cookie에 비밀 원문·개인정보를 저장하지 않고 서명·암호화·재사용·탈취 시나리오를 시험한다.

### 13.2 Cross-domain·CORS 판정 세부기준

- `Access-Control-Allow-Origin: *`와 credentials 동시 사용은 차단한다.
- 요청 Origin을 부분 문자열·suffix만으로 비교하지 않고 scheme/host/port가 정규화된 정확한 allowlist와 비교한다.
- 허용 method/header/exposed header를 최소화하고 preflight 결과와 cache 시간을 검증한다.
- cross-origin 인증은 Cookie·CORS·CSRF·redirect·postMessage를 하나의 공격경로로 통합 시험한다.

### 13.3 Inline script/style 판정 세부기준

- 기본 정책은 inline script, inline event handler, `eval`·동적 코드 실행 금지다.
- 불가피한 inline은 요청별 nonce 또는 고정 자산 hash로만 허용하고 nonce 재사용·노출을 시험한다.
- CSP 보고서만으로 PASS하지 않고 실제 브라우저에서 DOM XSS, script gadget, third-party script 변조를 시험한다.

### 13.4 모의해킹과 Kali 운용

- Kali Linux는 규칙 그 자체가 아니라 승인된 모의해킹 실행환경이다.
- SAST/SCA/IAST/DAST/API fuzz와 수동 업무로직 공격을 결합하며, 자동 스캐너의 `0건`은 안전 판정이 아니다.
- 대상·범위·승인·시간창·요청률·중단조건·데이터 처리·증거 보관을 Engagement Receipt로 고정한다.
- 발견 항목은 CWE/OWASP/Rule ID, 재현 절차, 영향, 원시 증거, 수정, 재시험 결과와 결속한다.
- 운영계 직접 공격은 별도 명시 승인 없이는 금지하며 격리된 staging/ephemeral 환경을 기본으로 한다.

## 14. 에러코드·메시지·다국어·테마 규칙

이 절은 GC-QA-09(변경·유지보수성)와 GC-QA-10(관측·감사성)에서 파생되는 규칙이다. 사용자·운영자에게 노출되는 모든 문자열(오류, 판정 사유, UI 라벨)은 판정 로직과 분리되어야 독립적으로 검증·번역·감사할 수 있다.

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-MSG-001 | 에러/사유 코드 체계 | 모든 오류·판정 사유는 자연어를 직접 하드코딩하지 않고 고유 코드(ID)로 식별한다. 코드는 영구적이며 의미가 바뀌면 새 코드를 발급한다(rule_id와 동일한 원칙). |
| GC-MSG-002 | 코드 네임스페이스 | 에러/사유 코드는 `{도메인}-{범주}-{일련번호}` 형태로 계층화하고, 코드만으로 원인 모듈을 역추적할 수 있어야 한다. |
| GC-MSG-003 | 메시지 외부화 | 사용자 노출 문자열은 소스 코드에서 분리된 메시지 카탈로그(리소스 파일)에 키로 관리한다. 로직과 문구를 같은 줄에서 결합하지 않는다. |
| GC-MSG-004 | 메시지 키 명명 | 메시지 키는 의미를 나타내고 언어·문구 자체를 키에 포함하지 않는다. |
| GC-MSG-005 | 폴백 정책 | 요청 로케일에 대응 메시지가 없으면 정의된 기본 로케일로 폴백하고, 폴백 발생을 관측 가능하게 로그로 남긴다. 조용히 빈 문자열을 반환하지 않는다. |
| GC-I18N-001 | 다국어 지원 범위 | 최소 ko/en 카탈로그를 유지하고, 신규 메시지 키 추가 시 모든 지원 로케일에 대응 항목이 있는지 빌드 시점에 검증한다(누락 시 FAIL). |
| GC-I18N-002 | 포맷 안전성 | 날짜·숫자·통화는 로케일별 포맷터를 사용하고, 문자열 결합(concat)으로 문장을 조립하지 않는다. |
| GC-I18N-003 | 판정 대상 언어와 표시 언어 분리 | 정보분류·정책판정처럼 판정 로직의 입력으로 쓰이는 원문(예: 탐지 패턴 대상)과, 사용자에게 보여주는 다국어 메시지를 같은 문자열 상수로 재사용하지 않는다. |
| GC-THM-001 | 테마 토큰화 | UI(관리자 Web UI 등)의 색상·간격·타이포는 하드코딩하지 않고 테마 토큰(디자인 토큰)으로 정의하며, 테마 전환 시 토큰 값만 교체한다. |
| GC-THM-002 | 접근성 대비 | 테마별 전경/배경 색상 조합은 WCAG 대비 기준(AA 이상)을 검증기로 확인한다. |
| GC-THM-003 | 테마-로케일 독립성 | 테마 설정과 언어 설정은 서로 독립적으로 저장·전환 가능해야 하며, 하나가 다른 하나의 기본값을 암묵적으로 결정하지 않는다. |

GC-THM 규칙은 관리자 Web UI가 없는 현재 MVP에는 적용 대상이 없다(N/A). Web UI 착수 시점부터 GC-THM 준수가 필요하다.

## 15. 로그 관리 규칙

11절의 GC-RSC-014(로그: 크기·보관·rate limit, 비밀·원문 차단, 감사로그 분리)를 구체화한 절이다. GC-RSC-014는 `parent_rule_id`로 아래 규칙과 연결된다.

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-LOG-001 | 로그 레벨 | ERROR/WARN/INFO/DEBUG 기준을 명확히 정의한다. 정상 흐름을 ERROR로 남기거나 실패를 DEBUG로 숨기지 않는다. |
| GC-LOG-002 | 구조화 로그 | 로그는 자유 텍스트가 아니라 구조화된(JSON 등) 필드로 남겨 기계 파싱·질의가 가능해야 한다. |
| GC-LOG-003 | 상관관계 ID | 요청 단위 request_id/trace_id를 발급해 모든 로그 라인에 전파하고, 하나의 요청에 걸친 로그를 재구성할 수 있어야 한다. |
| GC-LOG-004 | 로그 채널 분리 | 운영 로그(디버깅용)와 감사 로그(Receipt·판정 근거)는 별도 저장소·보존정책을 가지며 섞이지 않는다. |
| GC-LOG-005 | 민감정보 마스킹 | 원문·비밀·토큰·PII는 로그에 남기지 않고 해시·마스킹된 값만 남긴다(GC-SEC-013, GC-BAN-010과 동일 원칙). |
| GC-LOG-006 | 실패 정책 | 로그 저장소 실패 시 애플리케이션 가용성을 해치거나 조용히 로그를 유실하지 않고, 정의된 fallback과 알림 경로를 가진다. |
| GC-LOG-007 | 보관·회전 | 로그는 크기·기간 기준 회전(rotation)과 보관기한을 가지며, 규제·감사 요구의 최소 보관기간을 만족한다. |
| GC-LOG-008 | Rate limit | 반복 실패·루프가 로그 폭주(logstorm)를 일으키지 않도록 동일 이벤트에 속도 제한·샘플링을 적용한다. |


## 15.1 예외처리 실행 규칙

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-EXC-001 | 예외 분류 | 검증·정책부재·저장실패·내부실패를 안정적인 오류 코드와 재시도 가능 여부로 분류한다. |
| GC-EXC-002 | 변환 경계 | 외부 의존성 예외는 원문·stack을 노출하지 않고 분류된 도메인 예외로 변환한다. |
| GC-EXC-003 | Fail-Closed | 광범위 예외를 성공·null·0·빈 목록으로 바꾸지 않으며 정책 조회 실패는 허용으로 승격하지 않는다. |
| GC-EXC-004 | 재시도·Rollback | 재시도 가능성이 명시된 예외만 상한·deadline 안에서 재시도하고 상태 변경 실패는 rollback한다. |
| GC-EXC-005 | 관측 계보 | error_code, failure_class, request/trace ID를 구조화 로그에 남기되 비밀·원문은 기록하지 않는다. |
| GC-EXC-006 | 독립 검증 | 예외 원인별 positive/negative/boundary/evasion Fixture로 반환값·로그·rollback·Receipt를 함께 검증한다. |

현재 Python MVP에는 `exception_policy.py`의 안정적인 Failure/ONGuardError 계약과 `fail_closed` 변환 경계를 우선 구현한다. DB rollback·재시도·상관관계 ID는 후속 Harness에서 검증한다.

## 16. AI 시스템·AI 생성 코드 규칙

AI 관련 규칙은 AI 생성 코드만을 뜻하지 않는다. 제품에 내장된 AI 기능, 프롬프트·RAG·에이전트, 모델·데이터 운영, 외부 AI 공급자, AI 기반 검증기 자체를 모두 검증 대상으로 한다. AI 출력은 확률적이므로 설명이나 단일 예시 통과가 아니라 고정 평가셋·적대 Fixture·반복 실행·독립 Oracle로 입증한다.

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-AI-001 | AI 사용 선언 | 모델·공급자·용도·데이터 등급·자동화 수준·영향받는 사용자를 등록하고 미등록 AI 호출을 차단한다. |
| GC-AI-002 | AI 생성 코드 출처 | 생성 모델·프롬프트 계약·생성시각·대상 HEAD·사용 자산·검토자를 Receipt로 남기며 AI 자기보고를 증거로 인정하지 않는다. |
| GC-AI-003 | 생성 코드 정확성 | 가짜 API·존재하지 않는 옵션·미사용·중복 구현·근거 없는 기본값을 Detector와 실제 빌드·계약시험으로 차단한다. |
| GC-AI-004 | 테스트 독립성 | AI가 생성한 코드와 같은 모델이 만든 테스트만으로 PASS하지 않으며 독립 Oracle·변이시험·적대 Fixture를 요구한다. |
| GC-AI-005 | 테스트 약화 방지 | assertion 완화, skip·삭제, Golden 자동갱신, 범위 축소를 차단하고 테스트 전후 의미 차이를 감사한다. |
| GC-AI-006 | 입력 데이터 보호 | 프롬프트 전 데이터 분류·최소화·마스킹·반출정책을 적용하고 비밀·개인정보·고객 원문·내부 코드를 무단 외부 전송하지 않는다. |
| GC-AI-007 | 프롬프트 주입 | 시스템 지시·사용자 입력·검색 문서·도구 결과를 신뢰 경계별로 분리하고 직접·간접 prompt injection 및 지시 우회를 적대 시험한다. |
| GC-AI-008 | 출력 검증 | AI 출력을 명령이나 사실로 신뢰하지 않고 schema·type·범위·근거·정책·권한을 결정론적 코드로 검증한 뒤 사용한다. |
| GC-AI-009 | 환각·근거성 | 사실 주장은 인용 가능한 승인 출처와 결속하고 출처 부재·모순·낮은 신뢰도는 UNKNOWN/HOLD로 처리한다. |
| GC-AI-010 | 고위험 행위 승인 | 결제·삭제·배포·권한변경·외부전송·법률/의료/금융 영향 행위는 AI가 단독 확정하지 않으며 명시적 사람 승인과 재검증을 거친다. |
| GC-AI-011 | Agent 도구 권한 | 도구는 최소권한·allowlist·범위·횟수·비용·시간 상한을 가지며 자격증명 위임, 재귀 호출, 권한상승을 차단한다. |
| GC-AI-012 | RAG 무결성 | 수집 출처·권한·문서 Hash·청크·인덱스 버전을 결속하고 오염 문서·숨은 지시·권한 없는 검색 결과를 차단한다. |
| GC-AI-013 | 메모리·Tenant 격리 | 대화·장기 메모리·벡터 저장소·cache를 사용자·tenant·목적별로 격리하며 삭제·만료·정정·재사용 정책을 둔다. |
| GC-AI-014 | 모델·프롬프트 버전 | 모델 ID·버전·프롬프트·파라미터·tool schema·안전정책을 고정하고 변경 시 전체 회귀와 승인 없이 승격하지 않는다. |
| GC-AI-015 | 비결정성·재현성 | seed 가능 여부, 반복 횟수, 허용 분산과 안정성 기준을 명시하고 단일 성공 실행을 품질 증거로 사용하지 않는다. |
| GC-AI-016 | 평가·드리프트 | 정상·경계·적대·편향 평가셋을 버전 관리하고 정확도·근거성·유해성·거부·오탐/미탐·비용·지연의 퇴행과 운영 드리프트를 감시한다. |
| GC-AI-017 | 편향·공정성 | 보호특성·대리변수·집단별 오류율을 평가하고 차별적 결과와 피드백 루프를 탐지·차단·시정한다. |
| GC-AI-018 | 안전한 실패 | timeout·rate limit·circuit breaker·fallback·kill switch를 두며 모델·정책·근거 미확정 시 자동 허용이나 임의 정상값으로 전환하지 않는다. |
| GC-AI-019 | 비용·자원 상한 | 요청별 token·context·도구호출·재시도·동시성·금액·지연 상한을 강제하고 runaway agent와 denial-of-wallet을 차단한다. |
| GC-AI-020 | 공급자·공급망 | 모델·API·SDK·가중치·데이터셋의 출처·버전·약관·지역·보존·학습사용·취약점·중단 대책을 검증한다. |
| GC-AI-021 | 개인정보·저작권·법규 | 동의·목적·보존·삭제·국외이전·학습사용·저작권·라이선스·고지·이의제기·인간개입 요건을 관할과 용도별로 적용한다. |
| GC-AI-022 | 사용자 고지 | AI 사용 사실, 한계, 근거, 자동화 수준, 사람 문의·정정·이의제기 경로를 영향도에 맞게 제공한다. |
| GC-AI-023 | AI 보안시험 | prompt injection, jailbreak, data exfiltration, model extraction/inversion, membership inference, poisoning, evasion, unsafe tool use를 승인된 적대 Harness로 시험한다. |
| GC-AI-024 | AI 검증기 독립성 | AI 판정만으로 Final PASS하지 않고 결정론적 Gate·독립 모델/Oracle·사람 감사와 교차검증하며 동일 모델의 자기검증을 독립 증거로 금지한다. |
| GC-AI-025 | AI Receipt | 입력 등급·정책·모델·프롬프트·RAG 문서 Hash·도구 호출·출력·검증·승인·비용·판정을 하나의 변조탐지 계보로 결속한다. |
| GC-AI-026 | 학습·피드백 통제 | 운영 입력·출력·사람 피드백을 자동 학습에 재사용하지 않고 승인·비식별·품질·삭제·오염 방지 Gate를 거친다. |

### 16.1 AI Fixture와 Harness 최소 세트

- 정상·위반·경계·우회·다국어 prompt injection과 문서 내부 간접 주입
- 허위 인용, 근거 없음, 상충 근거, 오래된 근거, 권한 없는 RAG 문서
- 도구 파라미터 변조, 권한상승, 반복·재귀 호출, 승인 전 실행, 부분 성공
- 모델·프롬프트·tool schema 변경 전후 차등 평가와 반복 실행 분산
- PII·비밀·소스코드 반출, 로그·메모리·cache 잔존, tenant 교차검색
- timeout·429·provider 장애·응답 파손·비용 폭증·kill switch·fallback
- 모델별·집단별 정확도, 거부율, 오탐·미탐, 유해성, 비용, 지연 회귀
- AI 검증기가 만든 Rule·Fixture·판정에 대한 mutation과 독립 OTester/OAudit 재현

AI 기능은 필수 평가가 NOT_RUN이면 출시·자동승격·Final PASS를 금지한다. 고위험 행위의 사람 승인은 책임 전가용 확인창이 아니라 대상·근거·영향·변경사항을 확인한 명시적 승인 Receipt여야 한다.

## 17. 값 비교·권한·업무 상태 규칙

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-CMP-001 | 문자열 비교 | Unicode 정규화, 공백·대소문자·Locale·DB collation 기준을 명시하고 화면·서버·DB 결과를 일치시킨다. |
| GC-CMP-002 | 숫자·금액 비교 | 정확 십진, 단위·통화·반올림·overflow·허용오차·경계 포함 여부를 계약화한다. |
| GC-CMP-003 | 시간·버전 비교 | 시간대·정밀도·DST·월말·윤년과 semantic version 기준을 사용하며 문자열 순서 비교를 금지한다. |
| GC-CMP-004 | Null·집합 비교 | null·빈값·0·미입력을 분리하고 순서·중복·부분일치·누락 의미를 명시한다. |
| GC-CMP-005 | 비밀 비교 | 토큰·서명·MAC 등 비밀값은 검증된 상수시간 비교를 사용한다. |
| GC-CMP-006 | TOCTOU | 비교한 값과 변경 대상의 버전·Hash를 결속하고 반영 직전 재검증 또는 원자적 조건부 갱신을 수행한다. |
| GC-AUT-001 | 기본거부 | 인증 성공과 권한 허용을 분리하고 서버 측에서 모든 요청을 default-deny로 판정한다. |
| GC-AUT-002 | 세분 권한 | 기능·API·객체·행·필드·tenant·소유권·조직·목적·시간 조건을 실제 데이터 접근에 강제한다. |
| GC-AUT-003 | 간접 경로 | 목록·검색·집계·다운로드·export·배치·비동기·메시지 소비에서도 동일 권한을 유지한다. |
| GC-AUT-004 | IDOR/BOLA/BFLA | URL·ID·GraphQL·대량 조회·추측 가능한 식별자 변조와 UI 숨김 우회를 적대 시험한다. |
| GC-AUT-005 | 권한 생명주기 | 부여·변경·겸직·위임·회수·퇴사·만료 즉시 세션·토큰·cache·진행 작업에 반영한다. |
| GC-AUT-006 | 관리자·서비스 계정 | 최소권한, 자격증명 회전, 사람 계정과 분리, 사용 범위·시간·행위 감사를 강제한다. |
| GC-AUT-007 | 승인 분리 | 요청·승인·실행·감사를 분리하고 자기승인·승인 재사용·만료 후 실행을 금지한다. |
| GC-AUT-008 | 긴급권한 | break-glass는 사유·범위·만료·알림·사후검토를 강제하고 상시 관리자권한으로 전환하지 않는다. |
| GC-AUT-009 | 정보 추론 | 건수·오류·응답시간·캐시·검색 제안을 통한 비인가 정보 존재 추론을 방지한다. |
| GC-AUT-010 | 판정-접근 결속 | 권한 판정 Receipt의 주체·대상·행위·조건·정책버전과 실제 데이터 접근·변경 결과를 결속한다. |
| GC-BIZ-001 | 상태전이 | 허용 상태·전이·전제조건·순서·승인·취소·재개를 서버에서 검증하고 단계 건너뛰기를 차단한다. |
| GC-BIZ-002 | 업무값 조작 | 금액·수량·한도·할인·수수료·등급을 권위 데이터로 재계산하고 클라이언트 값을 신뢰하지 않는다. |
| GC-BIZ-003 | 중복·재전송 | 멱등성 키·중복 판정·부분 성공·보상·취소 후 재실행 계약을 둔다. |
| GC-BIZ-004 | 정책 변경 중 요청 | 판정에 사용한 정책버전과 실행 시점을 결속하고 장기 요청은 반영 직전 재검증한다. |


## 18. 구조화 로그·실제 DB/HTTP·AST SQL·웹 인증·개인정보 심화 규칙

이 절은 이중 루프 재검토에서 발견된 누락을 보완한다. 기존 GC-RSC·GC-SEC·GC-LOG 상위 원칙만으로 실제 계층의 동작을 입증했다고 보지 않는다. 아래 규칙은 실제 adapter/client/server/driver/parser/KMS 경로와 장애 Harness까지 통과해야 한다.

### 18.1 구조화 로깅·관측

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-LOG-009 | 로그 Schema | timestamp, level, event_code, service, environment, request/trace/span ID, actor/tenant, policy/rule version, outcome을 버전된 JSON schema로 검증한다. |
| GC-LOG-010 | Context 신뢰경계 | 외부 trace/request ID를 무조건 신뢰하지 않고 형식·길이를 검증하거나 재발급하며 내부 correlation과 분리한다. |
| GC-LOG-011 | 무결성·시간 | 감사로그의 append-only·서명/Hash chain·접근통제와 시간 동기·clock skew를 검증하고 redaction 전후 원문 잔존을 탐지한다. |

### 18.2 실제 DB 계층

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-DB-001 | 실제 경로 | mock만이 아니라 제품이 사용하는 driver/ORM/pool/schema와 동일한 통합 환경에서 검증한다. |
| GC-DB-002 | Transaction | commit·rollback·savepoint·격리·deadlock·serialization failure와 외부 호출 혼합을 시험한다. |
| GC-DB-003 | Pool·생명주기 | pool 상한·획득 timeout·반납·leak·고갈·재연결·shutdown을 실제 연결로 검증한다. |
| GC-DB-004 | Migration | forward/backward compatibility, online migration, partial failure, rollback/roll-forward, 오래된 app 동시 구동을 검증한다. |
| GC-DB-005 | 권한·Tenant | DB 계정 최소권한, schema/table/row/column 정책과 tenant/RLS 우회를 검증한다. |
| GC-DB-006 | 암호화 | TLS, 저장·필드 암호화, key version, rotation, 재암호화와 평문 임시본을 검증한다. |
| GC-DB-007 | Backup·복원 | 암호화 backup, 접근통제, PITR/restore, 복원 후 보존·삭제·권한 재적용을 검증한다. |
| GC-DB-008 | 장애 Harness | 단절·지연·pool 고갈·deadlock·disk full·read-only·failover·부분 commit을 주입해 데이터 불변식을 확인한다. |

### 18.3 실제 HTTP 계층

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-HTTP-001 | Deadline | server·client·proxy·DNS·connect·TLS·read·write·전체 deadline을 결속하고 하위 호출에 남은 예산만 전달한다. |
| GC-HTTP-002 | TLS | 인증서 hostname/chain/expiry/revocation, TLS 기준선, mTLS와 key rotation을 검증하며 검증 우회를 차단한다. |
| GC-HTTP-003 | Redirect·Proxy | redirect마다 scheme/host/IP/권한을 재검증하고 trusted proxy·Forwarded header 경계를 고정한다. |
| GC-HTTP-004 | 크기·Stream | body/header/query/multipart/응답/압축 해제 상한, streaming backpressure·cancel·close를 검증한다. |
| GC-HTTP-005 | Retry·Idempotency | 안전한 method/오류만 jitter·상한·deadline 안에서 재시도하고 상태변경은 idempotency와 결과 조회를 사용한다. |
| GC-HTTP-006 | Content 계약 | method, status, Content-Type, charset, schema, cache, CORS와 오류 body를 실제 wire 수준에서 검증한다. |
| GC-HTTP-007 | 인증 Context | 사용자·service·tenant·delegation context의 전파·축소·만료를 검증하고 header spoofing을 차단한다. |
| GC-HTTP-008 | 장애 Harness | slowloris, 429/5xx, reset, half-close, truncated/malformed/chunked body, DNS 변경, proxy timeout을 주입한다. |

### 18.4 AST 기반 SQL 탐지기

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-SQL-001 | Dialect Parser | 지원 DB dialect/version별 AST parser를 고정하고 parse 실패·unsupported syntax를 허용이 아니라 HOLD로 처리한다. |
| GC-SQL-002 | 값 Binding | literal/concat/interpolation/template로 외부값이 SQL AST에 들어가는 경로를 data-flow로 탐지하고 bind parameter만 허용한다. |
| GC-SQL-003 | 식별자 | table/column/order/direction 등 bind 불가능 식별자는 canonical allowlist와 안전 builder만 사용한다. |
| GC-SQL-004 | 동적 Fragment | WHERE/IN/LIKE/LIMIT/JSON/path fragment, 빈 목록, wildcard escaping과 조건 제거 우회를 탐지한다. |
| GC-SQL-005 | 우회 경로 | ORM native query, query builder escape hatch, stored procedure, migration, batch, report/export SQL을 동일 규칙으로 검사한다. |
| GC-SQL-006 | 2차 주입 | DB에 저장된 값이 이후 SQL·DDL·procedure에 재사용되는 second-order injection 경로를 taint로 추적한다. |
| GC-SQL-007 | Parser 우회 | comment, encoding, Unicode, multi-statement, delimiter, nested query, dialect operator 변형 Fixture를 실행한다. |
| GC-SQL-008 | 자원·권한 | SELECT *, 무제한 결과, 위험 DDL/DML, cross-tenant join, 권한 없는 schema 접근과 query-plan 퇴행을 검사한다. |
| GC-SQL-009 | Detector 검증 | positive/negative/boundary/evasion/mutation corpus와 실제 parser crash·오탐·미탐을 dialect별로 측정한다. |

### 18.5 웹 인증

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-WAUTH-001 | OAuth/OIDC | authorization code+PKCE, exact redirect URI, state, nonce, issuer, client와 mix-up 방지를 검증한다. |
| GC-WAUTH-002 | Token/JWT | alg allowlist, 서명, iss/aud/azp/exp/nbf/iat/jti, clock skew, JWKS cache·rotation·kid 혼동을 검증한다. |
| GC-WAUTH-003 | Password·MFA | 검증된 password hash, rate limit, MFA binding·step-up·recovery와 downgrade를 검증한다. |
| GC-WAUTH-004 | Session | 로그인·권한상승 시 ID 회전, idle/absolute expiry, device/context, 동시 세션, cookie와 server state 폐기를 검증한다. |
| GC-WAUTH-005 | 남용·추론 | brute force, credential stuffing, account enumeration, CAPTCHA 우회와 lockout DoS를 검증한다. |
| GC-WAUTH-006 | CSRF·Login | login/logout/consent/link/unlink를 포함한 상태변경 CSRF와 SameSite·Origin·token 결속을 검증한다. |
| GC-WAUTH-007 | WebSocket/SSE | handshake와 메시지별 인증·권한·origin·token expiry·revocation·재연결을 검증한다. |
| GC-WAUTH-008 | Logout·Revocation | access/refresh/session/token cache의 만료·회전·재사용 탐지·전역 로그아웃을 검증한다. |
| GC-WAUTH-009 | Recovery | 비밀번호·MFA·계정 복구의 신원확인, 단일사용, 만료, 알림, 기존 세션 폐기를 검증한다. |
| GC-WAUTH-010 | 적대 Harness | session fixation, token theft/replay, JWT confusion, OAuth mix-up, privilege change와 동시 요청을 재공격한다. |

### 18.6 개인정보·암호화

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-PRV-001 | 분류·최소화 | 개인정보·민감정보·고유식별정보를 필드·흐름별 분류하고 목적·동의·최소수집·사용 제한을 강제한다. |
| GC-PRV-002 | 전송 암호화 | 외부·내부·service-to-service·관리·backup 전송에 TLS/mTLS와 인증서 수명주기를 적용한다. |
| GC-PRV-003 | 저장·필드 암호화 | DB·파일·object store·queue·temp·swap·snapshot의 저장 암호화와 고위험 필드의 application-level 암호화를 구분한다. |
| GC-PRV-004 | 키 관리 | KMS/HSM, envelope encryption, key version, rotation, revoke, separation of duties, key/data backup 분리를 검증한다. |
| GC-PRV-005 | 파생 사본 | cache, search index, vector store, analytics, export, log, trace, crash dump에 생긴 사본에도 동일 통제를 적용한다. |
| GC-PRV-006 | Tokenization | masking·tokenization·pseudonymization·anonymization의 가역성·재식별 위험과 권한을 구분한다. |
| GC-PRV-007 | Backup·복원 | 암호화 backup과 복원 환경의 접근·키·보존·삭제를 검증하고 삭제 대상이 복원으로 부활하지 않게 한다. |
| GC-PRV-008 | 보존·삭제 | 법적 보존과 목적 만료를 결속하고 active/replica/cache/index/backup 삭제 및 crypto-erasure를 증명한다. |
| GC-PRV-009 | 표시·Export | 화면·API·다운로드·인쇄·clipboard의 마스킹·watermark·대량 export 권한과 사유·승인을 검증한다. |
| GC-PRV-010 | 접근·감사 | 열람·검색·변경·반출을 최소권한과 Receipt로 결속하고 내부자 대량조회·비정상 패턴을 탐지한다. |
| GC-PRV-011 | 침해 대응 | 유출 탐지, 키 폐기, 영향 범위, 통지, 증거 보존과 재발방지 Rule 승격을 검증한다. |
| GC-PRV-012 | 암호 Harness | 평문 grep/scan, wire capture, snapshot/backup/restore, key rotation·폐기, cache/index/log 잔존과 재식별 공격을 실행한다. |

## 18.7 잔여 검토 대상의 정식 Rule 승격

기존 ‘추가 검토 대상’ 목록은 아래의 독립 Rule ID로 승격한다. 모든 규칙은 `good_code_rule_traceability.json`의 적용성·심각도·Detector·Fixture·Harness·Oracle·Evidence와 결속한다. 구현되지 않은 규칙은 문서 완료와 무관하게 `NOT_IMPLEMENTED`로 유지한다.


### GC-EVT 메시지·이벤트·Webhook

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-EVT-001 | 메시지 계약 | schema registry와 호환성 규칙을 고정하고 미지원 schema는 HOLD한다. |
| GC-EVT-002 | 전달 의미 | at-most/at-least/exactly-once 의미와 중복·손실 Oracle을 명시한다. |
| GC-EVT-003 | 멱등성 | consumer·producer·outbox·inbox의 idempotency key와 보존기간을 검증한다. |
| GC-EVT-004 | 순서 | partition key·sequence·재정렬 window와 순서 역전 처리를 검증한다. |
| GC-EVT-005 | 재시도·DLQ | 상한·backoff·poison 격리·재처리 승인·감사 계보를 강제한다. |
| GC-EVT-006 | Webhook 서명 | 서명·timestamp·nonce·body canonicalization과 key rotation을 검증한다. |
| GC-EVT-007 | Replay | 재전송 window·nonce 재사용·중복 side effect를 차단한다. |
| GC-EVT-008 | 부분 실패 | publish 성공/DB 실패와 DB 성공/publish 실패를 원자적 계보로 복구한다. |
| GC-EVT-009 | Backpressure | queue·consumer lag·in-flight 상한과 과부하 거부 정책을 검증한다. |
| GC-EVT-010 | 권한·Tenant | topic·subscription·message별 주체·tenant·목적 권한을 강제한다. |
| GC-EVT-011 | 민감정보 | payload·header·DLQ·trace의 분류·암호화·마스킹·삭제를 검증한다. |
| GC-EVT-012 | 장애 Harness | 중복·손실·역전·broker 단절·재시작·DLQ 복귀를 실제 broker 경로에서 주입한다. |



### GC-FILE 파일·Object Storage

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-FILE-001 | 업로드 검증 | 확장자보다 magic byte·parser·allowlist·크기·개수 상한을 검증한다. |
| GC-FILE-002 | 경로·이름 | path traversal·Unicode·예약명·중복명·symlink 우회를 차단한다. |
| GC-FILE-003 | 압축·Parser | 압축폭탄·중첩·비율·항목수·parser crash·polyglot을 제한한다. |
| GC-FILE-004 | 악성코드 | 격리→scan→검증→원자 이동 순서를 강제하고 scan 실패는 fail-closed한다. |
| GC-FILE-005 | Object 권한 | bucket/object/prefix/tenant 권한과 public ACL·정책 우회를 차단한다. |
| GC-FILE-006 | 서명 URL | 최소 권한·짧은 만료·method/content 제약·재사용·로그 노출을 검증한다. |
| GC-FILE-007 | 암호화·키 | 전송·저장·필드 암호화와 key version·rotation·폐기를 검증한다. |
| GC-FILE-008 | 보존·삭제 | 원본·파생본·thumbnail·cache·replica·backup의 보존·삭제를 결속한다. |
| GC-FILE-009 | 복원 | 복원 후 권한·보존·malware 판정·삭제 tombstone이 유지되는지 검증한다. |
| GC-FILE-010 | 장애 Harness | 중단 업로드·부분 파일·disk full·권한 변경·복원·삭제 경합을 주입한다. |



### GC-API API Protocol

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-API-001 | REST 계약 | method·status·schema·pagination·idempotency·오류 계약을 wire 수준에서 검증한다. |
| GC-API-002 | GraphQL | field/row 권한, depth·complexity·alias·batch·introspection 제한을 검증한다. |
| GC-API-003 | WebSocket | handshake·origin·메시지별 권한·token 만료·backpressure를 검증한다. |
| GC-API-004 | SSE | 인증·재연결·Last-Event-ID·buffer 상한·권한 변경을 검증한다. |
| GC-API-005 | gRPC | deadline·status·metadata·stream limit·reflection·mTLS를 검증한다. |
| GC-API-006 | 버전 호환 | backward/forward 호환과 sunset·client skew·schema drift를 검증한다. |
| GC-API-007 | Rate·Quota | 주체·tenant·IP·기능별 제한과 분산 우회·비용 증폭을 차단한다. |
| GC-API-008 | 대량 요청 | batch·multipart·export·query fan-out의 크기·시간·메모리 상한을 둔다. |
| GC-API-009 | 오류·추론 | 존재·권한·계정 상태를 오류·건수·시간 차이로 추론하지 못하게 한다. |
| GC-API-010 | Protocol Harness | malformed frame·slow client·cancel·half-close·schema mismatch를 주입한다. |



### GC-CLI 브라우저·모바일·Desktop

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-CLI-001 | 브라우저 저장소 | token·PII를 local/session storage·IndexedDB·cache에 평문 저장하지 않는다. |
| GC-CLI-002 | Service Worker | scope·cache·update·offline 권한과 오래된 응답·credential 잔존을 검증한다. |
| GC-CLI-003 | Third-party | script·SDK·tag의 출처·SRI·CSP·권한·데이터 반출을 통제한다. |
| GC-CLI-004 | DOM·Navigation | DOM XSS·open redirect·postMessage origin·tabnabbing을 차단한다. |
| GC-CLI-005 | Clickjacking | frame-ancestors와 민감 행위 재인증으로 UI redress를 차단한다. |
| GC-CLI-006 | Mobile 저장소 | Keychain/Keystore·backup·screenshot·clipboard·log의 민감정보를 통제한다. |
| GC-CLI-007 | 인증서·Network | 검증 우회 금지, pinning 적용성·rotation·proxy 환경을 검증한다. |
| GC-CLI-008 | Deep Link | scheme/app link 검증, 파라미터 권한, 다른 앱 가로채기를 차단한다. |
| GC-CLI-009 | Desktop Update | 서명된 update·rollback 방지·권한 최소화·로컬 비밀 보호를 검증한다. |
| GC-CLI-010 | Client Harness | 실제 브라우저·모바일·desktop에서 storage·cache·update·권한 회귀를 실행한다. |



### GC-SUP 공급망·Artifact·Container

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-SUP-001 | Source | 보호 branch·review·서명 commit·권위 source hash를 검증한다. |
| GC-SUP-002 | 의존성 | lockfile·허용 registry·pinning·typosquatting·confusion을 검증한다. |
| GC-SUP-003 | Build | 격리·최소권한·고정 입력·재현성·secret 비노출을 검증한다. |
| GC-SUP-004 | SBOM | 직접·전이·OS package·artifact 관계와 버전·license를 완전하게 기록한다. |
| GC-SUP-005 | Provenance | SLSA provenance와 builder identity·source·parameter를 artifact에 결속한다. |
| GC-SUP-006 | 서명 | artifact·container·SBOM·provenance 서명과 key rotation·revocation을 검증한다. |
| GC-SUP-007 | Container | minimal base·non-root·read-only·capability·seccomp·digest pin을 강제한다. |
| GC-SUP-008 | Artifact 저장소 | immutability·retention·promotion·quarantine·접근감사를 검증한다. |
| GC-SUP-009 | 취약점 예외 | 영향·범위·보상통제·만료·재평가를 가진 예외만 허용한다. |
| GC-SUP-010 | 공급망 Harness | 변조 package·builder·signature·SBOM 누락·rollback을 적대 검증한다. |



### GC-CLD Cloud·IaC·Kubernetes

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-CLD-001 | Cloud IAM | human/workload identity·최소권한·조건·임시자격·회수를 검증한다. |
| GC-CLD-002 | Network | ingress/egress·private endpoint·DNS·metadata 접근을 default-deny한다. |
| GC-CLD-003 | Secret | secret manager·workload identity·rotation·memory/log 노출을 검증한다. |
| GC-CLD-004 | Kubernetes RBAC | service account·namespace·verb/resource·impersonation을 최소화한다. |
| GC-CLD-005 | Pod Security | non-root·read-only·capability·host namespace·volume·seccomp를 통제한다. |
| GC-CLD-006 | Admission | 서명·image allowlist·policy·exception·fail-closed 동작을 검증한다. |
| GC-CLD-007 | Service Mesh | mTLS·identity·authorization·retry/timeout 정책과 bypass를 검증한다. |
| GC-CLD-008 | IaC | plan/apply 승인·state 보호·module pin·policy-as-code·drift를 검증한다. |
| GC-CLD-009 | Multi-account | 환경·계정·project·subscription 경계와 cross-account trust를 검증한다. |
| GC-CLD-010 | Logging | control/data plane 감사·변조 방지·보존·경보를 검증한다. |
| GC-CLD-011 | Quota·비용 | 자원 quota·autoscaling 상한·비용 폭증·crypto mining을 탐지한다. |
| GC-CLD-012 | Cloud Harness | 권한·network·node·region 장애와 policy drift를 격리 환경에서 주입한다. |



### GC-CFG 설정·Feature Flag·비밀

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-CFG-001 | Schema | 설정 key·type·범위·기본값·필수성·민감도를 schema로 검증한다. |
| GC-CFG-002 | 환경 분리 | dev/test/prod 값·권한·endpoint·credential 혼용을 차단한다. |
| GC-CFG-003 | Feature Flag | owner·대상·만료·default·fail mode·rollback을 명시한다. |
| GC-CFG-004 | 동적 변경 | 검증→승인→원자 반영→관측→rollback 순서를 강제한다. |
| GC-CFG-005 | 비밀 변경 | rotation·dual-key window·revoke·cache 무효화를 검증한다. |
| GC-CFG-006 | 긴급 설정 | break-glass 사유·범위·만료·알림·사후검토를 강제한다. |
| GC-CFG-007 | Drift | 권위 설정과 runtime effective config 차이를 탐지하고 HOLD한다. |
| GC-CFG-008 | 설정 Harness | 누락·오타·구버전·부분배포·rollback·동시 변경을 주입한다. |



### GC-DR 배포·Rollback·DR

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-DR-001 | 배포 전략 | rolling/blue-green/canary의 용량·호환·중지·rollback 조건을 고정한다. |
| GC-DR-002 | 부분 배포 | 구·신 버전 동시 구동과 schema/API/event 호환성을 검증한다. |
| GC-DR-003 | Rollback | code·config·schema·data rollback/roll-forward와 복구 불가능 변경을 구분한다. |
| GC-DR-004 | Release 승인 | source→artifact→환경→승인→배포 Receipt를 결속한다. |
| GC-DR-005 | RTO/RPO | 서비스·데이터별 목표와 측정 Oracle을 명시한다. |
| GC-DR-006 | Backup | 범위·주기·암호화·격리·immutability·복구 가능성을 검증한다. |
| GC-DR-007 | Region 장애 | DNS·traffic·data replication·split-brain·failback을 검증한다. |
| GC-DR-008 | Runbook | 자동·수동 단계, 권한, 중단조건, 연락, 증거 보존을 검증한다. |
| GC-DR-009 | 복원 훈련 | 실제 backup으로 격리 복원하고 무결성·권한·삭제·성능을 검증한다. |
| GC-DR-010 | DR Harness | zone/region/control-plane 장애와 데이터 손상·복원·failback을 실행한다. |



### GC-OBS Metric·Trace·Alert

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-OBS-001 | Metric Schema | name·unit·label·owner·SLO 관계와 schema version을 관리한다. |
| GC-OBS-002 | Cardinality | label allowlist·상한·PII 금지·폭주 보호를 검증한다. |
| GC-OBS-003 | Trace | context 신뢰경계·sampling·span 누락·tenant·민감정보를 검증한다. |
| GC-OBS-004 | Alert | 임계·window·dedup·routing·silence 만료·owner·runbook을 검증한다. |
| GC-OBS-005 | SLO | SLI source·오류예산·burn rate·배포 Gate와 사용자 영향의 일치를 검증한다. |
| GC-OBS-006 | Telemetry 장애 | 수집기 지연·단절·queue 포화 시 제품 안전과 데이터 유실 표시를 검증한다. |
| GC-OBS-007 | 조작 방지 | metric/log/trace 삭제·변조·clock skew와 감사 접근을 탐지한다. |
| GC-OBS-008 | Observability Harness | 고 cardinality·sampling·collector 장애·alert storm·침묵을 주입한다. |



### GC-UX 접근성·다국어·표시

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-UX-001 | 키보드 | 모든 기능의 키보드 접근·focus 순서·trap·skip link를 검증한다. |
| GC-UX-002 | 의미 구조 | heading·landmark·label·name/role/value와 상태 알림을 검증한다. |
| GC-UX-003 | 대비·색상 | WCAG AA 대비와 색상 단독 의미 전달 금지를 테마별 검증한다. |
| GC-UX-004 | 확대·Reflow | 200% 확대·좁은 viewport·문자 간격에서 잘림·겹침을 차단한다. |
| GC-UX-005 | 보조기술 | screen reader·고대비·reduced motion·caption을 실제 조합에서 검증한다. |
| GC-UX-006 | 오류 접근성 | 오류 위치·요약·수정 안내와 시간 제한 연장을 검증한다. |
| GC-UX-007 | 다국어 Layout | 번역 확장·RTL·CJK·조합문자·줄바꿈·font fallback을 검증한다. |
| GC-UX-008 | 표시 정확성 | locale·timezone·통화·복수형·DST·달력의 입력/표시/저장 일치를 검증한다. |
| GC-UX-009 | 보안 상호작용 | 마스킹·자동완성·clipboard·timeout이 접근성과 보안을 함께 만족하는지 검증한다. |
| GC-UX-010 | UX Harness | 테마×locale×viewport×보조기술 조합의 화면·기능 회귀를 실행한다. |



### GC-DQ 데이터 품질·계보

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-DQ-001 | Schema 품질 | type·필수·범위·코드값·단위·정밀도 계약을 검증한다. |
| GC-DQ-002 | 완전성 | 누락·기본값 대체·부분 ingest를 원본과 독립 합계로 검증한다. |
| GC-DQ-003 | 유일성 | 업무 key·중복·재처리·merge 기준을 검증한다. |
| GC-DQ-004 | 일관성 | 시스템·table·cache·index·report 간 불변식과 reconciliation을 검증한다. |
| GC-DQ-005 | 적시성 | event time·processing time·지연·watermark·late data 정책을 검증한다. |
| GC-DQ-006 | 계보 | source·transform·owner·version·quality result를 결과에 결속한다. |
| GC-DQ-007 | Drift | 분포·schema·code set·null rate·단위 변화와 기준 변경을 구분한다. |
| GC-DQ-008 | Data Harness | 누락·중복·역전·오염·late data·reprocess를 주입하고 대사한다. |



### GC-VLD 검증기·Oracle·Evidence

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-VLD-001 | Rule 권위 | 승인된 Rule Set digest와 적용성·심각도·버전을 실행 전 고정한다. |
| GC-VLD-002 | Parser | crash·timeout·unsupported syntax·recovery mode를 PASS가 아닌 HOLD로 처리한다. |
| GC-VLD-003 | Detector 독립성 | 생성 코드·Detector·Oracle의 동일 모델/구현 공통오판을 차단한다. |
| GC-VLD-004 | Fixture 무결성 | positive/negative/boundary/evasion/mutation corpus hash를 고정한다. |
| GC-VLD-005 | Oracle | 자기보고·동일 구현 비교를 금지하고 독립 불변식·차등 Oracle을 사용한다. |
| GC-VLD-006 | Evidence | 원시 증거·시간·환경·도구·결과 hash와 append-only 저장을 검증한다. |
| GC-VLD-007 | Receipt | source→rule→detector→fixture→harness→oracle→decision 계보를 결속한다. |
| GC-VLD-008 | 예외 | 범위·사유·승인·만료·취소·재사용 금지와 우회 탐지를 검증한다. |
| GC-VLD-009 | Golden | 자동 승인·자동 갱신·결과 후 변경을 차단하고 독립 review를 요구한다. |
| GC-VLD-010 | 오탐·미탐 | 대표 corpus와 mutation score·confidence interval·regression budget을 관리한다. |
| GC-VLD-011 | 검증기 권한 | rule/evidence/decision 저장소의 최소권한·승인 분리·감사를 강제한다. |
| GC-VLD-012 | Self Harness | tampered rule·fixture·evidence·clock·hash·parser·Oracle을 적대 시험한다. |



### GC-LNG 언어·Framework 파생

| Rule ID | 영역 | 필수 계약 |
|---|---|---|
| GC-LNG-001 | 파생 관계 | 언어·framework 규칙은 parent_rule_id와 지원 version을 필수로 가진다. |
| GC-LNG-002 | 적용성 | repository stack·file·dependency·runtime으로 적용 규칙을 결정하고 누락은 HOLD한다. |
| GC-LNG-003 | Version Matrix | 지원·비지원·EOL version과 detector parser 호환성을 검증한다. |
| GC-LNG-004 | Framework Default | 안전/불안전 기본값과 override·auto-configuration을 실제 runtime에서 검증한다. |
| GC-LNG-005 | Cross-language | FFI·serialization·RPC·SQL 경계에서 type·encoding·권한·오류 의미를 보존한다. |
| GC-LNG-006 | 파생 Harness | Java/Spring/Python/JavaScript와 DB·Cloud별 fixture matrix를 독립 실행한다. |



## 19. 규칙별 추적표와 설계 완료 판정

전체 Rule별 추적 필드는 기계 판독 가능한 `docs/spec/good_code_rule_traceability.json`을 권위본으로 한다. 아래 표는 신규 규칙군의 요약이며 JSON의 각 Rule 행은 적용성·심각도·Detector·6종 Fixture·Harness·Oracle·Evidence·구현상태를 모두 가진다.

| Rule 범위 | 영역 | 적용성 | 심각도 | Detector | Fixture/Harness | Oracle | Evidence | 상태 |
|---|---|---|---|---|---|---|---|---|
| GC-EVT-001~012 | 메시지·이벤트·Webhook | CONDITIONAL_BY_STACK | MAJOR | AST/config/schema | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-FILE-001~010 | 파일·Object Storage | CONDITIONAL_BY_STACK | CRITICAL | AST/config/content scanner | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-API-001~010 | API Protocol | CONDITIONAL_BY_STACK | MAJOR | schema/config/wire probe | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-CLI-001~010 | 브라우저·모바일·Desktop | CONDITIONAL_BY_STACK | MAJOR | AST/config/browser probe | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-SUP-001~010 | 공급망·Artifact·Container | CONDITIONAL_BY_STACK | CRITICAL | SCA/SBOM/signature/config | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-CLD-001~012 | Cloud·IaC·Kubernetes | CONDITIONAL_BY_STACK | CRITICAL | IaC AST/config/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-CFG-001~008 | 설정·Feature Flag·비밀 | CONDITIONAL_BY_STACK | MAJOR | schema/config/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-DR-001~010 | 배포·Rollback·DR | CONDITIONAL_BY_STACK | CRITICAL | deployment config/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-OBS-001~008 | Metric·Trace·Alert | CONDITIONAL_BY_STACK | MAJOR | schema/config/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-UX-001~010 | 접근성·다국어·표시 | CONDITIONAL_BY_STACK | MAJOR | DOM/a11y/visual/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-DQ-001~008 | 데이터 품질·계보 | CONDITIONAL_BY_STACK | MAJOR | schema/profile/reconciliation | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-VLD-001~012 | 검증기·Oracle·Evidence | CONDITIONAL_BY_STACK | CRITICAL | self-check/mutation/tamper | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |
| GC-LNG-001~006 | 언어·Framework 파생 | CONDITIONAL_BY_STACK | MAJOR | stack/version/AST/runtime | 6종 Fixture + 통합·적대 Harness | 불변식 유지·우회/단절 0 | Trace JSON + Raw Evidence + Receipt | NOT_IMPLEMENTED |

### 19.1 적용성 판정

- `APPLICABLE`: 현재 repository stack·의존성·배포 경로에 적용되며 필수 Gate다.
- `CONDITIONAL_BY_STACK`: stack inventory로 적용 여부를 결정하기 전 상태이며 조용히 N/A로 내릴 수 없다.
- `N/A`: 근거·판정자·Rule Set version·만료/재검토 조건을 Receipt로 남긴 경우만 허용한다.
- `NOT_IMPLEMENTED/NOT_RUN/BLOCKED`: PASS로 집계하지 않고 전체 완료를 HOLD한다.


### 19.2 설계 완료와 구현 완료의 분리

문서 설계는 모든 검토 대상의 Rule ID 승격, MD·DOCX 의미 동기화, Rule별 추적 필드 완성, 정방향·역방향 연속 2회 신규 상위 분류 0건을 충족하므로 `DESIGN_COMPLETE`로 판정한다. Detector·Fixture·Harness와 독립 검증은 대부분 미구현이므로 전체 제품 판정은 계속 `IMPLEMENTATION_CONTINUE / FINAL_HOLD`다.


### 19.3 Campaign 중지·재개

시험 Campaign은 동일 HEAD·Rule Set·환경에서 필수 matrix 100%, CRITICAL/MAJOR/NOT_RUN/BLOCKED/추적단절 0, 오탐·미탐·mutation 기준 충족, 독립 OTester·OAudit CLEAN 2회일 때만 봉인한다. HEAD·Rule·의존성·환경·위협정보 변경 시 자동 재개한다.


## 20. 이중 루프 수렴과 Harness 중지 기준

정방향은 각 품질 속성이 Rule·Detector·Fixture·Harness·Receipt까지 내려가는지 확인한다. 역방향은 각 Harness 결과가 어떤 Rule·실패 유형·품질 속성을 실제로 입증하는지 거슬러 확인한다. 연결이 하나라도 끊기면 NOT_PROVEN이다.

설계 검토는 연속 2회 루프에서 새 상위 분류·실패 유형·필수 Rule이 나오지 않고 모든 항목에 적용성, 심각도, Oracle, Detector 또는 Harness, 증거 경로가 배정됐을 때 조건부 중지한다.

시험 Campaign은 동일 HEAD·Rule Set·환경에서 필수 matrix 100%, CRITICAL=0, MAJOR=0, 필수 NOT_RUN=0, BLOCKED=0, 추적 단절=0, 합의된 오탐·미탐·mutation 기준 충족, OTester·OAudit 독립 CLEAN 2회일 때만 중지한다.

Harness를 중지하는 이유는 동일 입력을 무한 재실행해도 새로운 증거가 생기지 않으므로 실행 Campaign을 봉인하고 자원을 해제하기 위해서다. 이는 Harness를 폐기하거나 운영 감시를 끝낸다는 뜻이 아니다. HEAD·Rule·의존성·환경 변경, 새 취약점·사고·drift 발생 시 자동 재개한다.


## 21. 언어·프레임워크 구체화 우선순위

1. Java 17: JDBC, Executor, Lock, Stream, BigDecimal, Clock, CompletableFuture.
2. Spring: Transactional rollback/timeout, WebClient·RestClient timeout, TaskExecutor 유한 Queue, Scheduler 중첩, Bean lifecycle.
3. DB: PostgreSQL 기준 Pool, isolation, deadlock, migration forward/backward compatibility.
4. Python MVP: context manager, asyncio cancellation, HTTP timeout, bounded queue, transaction and file lifecycle.
5. 공통 공급망: lockfile, SBOM, CycloneDX, SLSA provenance, license and signature verification.

각 구체화 문서는 이 상위 Rule ID를 대체하지 않고 파생 Rule ID와 `parent_rule_id`로 연결한다.

## 22. ONGuard 구현 산출물

이 절은 위 Rule ID를 현재 Python MVP 코드(`src/onguard`)에 실제로 매핑한 결과다. MVP는 Goal State의 축소 구현이므로, 아직 적용되지 않은 규칙은 실패가 아니라 `NOT_IMPLEMENTED` 또는 `N/A`로 남긴다. 자동 Detector/Harness는 아직 구축되지 않았으므로 상태는 코드 리뷰 기준 자기보고이며, 8~9절의 독립 검증 기준으로는 증거로 인정되지 않는다.

| Rule ID | 상태 | 근거 |
|---|---|---|
| GC-RSC-009 (Collection·메모리) | COMPLIANT | 사용되지 않던 무제한 `AuditStore.events` 메모리 저장소를 제거했다. |
| GC-RSC-009 / GC-BAN-001 | COMPLIANT | `AuditCenter.list_events()`/`api.audit_events()`에 `limit`/`offset`과 `MAX_LIST_LIMIT=500` clamp를 추가했다(`test_audit_events_are_paginated_and_bounded`). |
| GC-QA-01 (요구사항 정확성 · MASK 실질 구현) | COMPLIANT | 과거 `DecisionStatus.MASK`는 라벨만 반환하고 실제 마스킹을 하지 않았다. `classification.mask_content()`가 탐지된 값(이메일·전화·계좌·주민번호 등)만 `[REDACTED:<signal>]`로 치환하고, 주제 키워드(고객·내부 등)는 값이 아니므로 그대로 남긴다. `engine.evaluate_policy`가 `effect==MASK`일 때 이를 계산해 `PolicyDecision.masked_content`/API 응답에 반영한다(`test_mask_decision_redacts_detected_values_not_topic_words` 등). |
| GC-RSC-002 / GC-RSC-020 (DB 자원 소유권) | NOT_IMPLEMENTED (SQLite MVP 트랙) / 검증 환경 구축 완료 (Postgres 트랙) | `src/onguard`가 실제로 참조하는 SQLite 경로는 여전히 단일 커넥션 공유 구조이며 미해결이다. 다만 `.devcontainer/docker-compose.yml`로 ONGuard 전용 Postgres 컨테이너와, `tests_postgres/test_postgres_schema.py`로 `ThreadedConnectionPool` 기반 동시 커넥션·공유 상태·명시적 `closeall()` 반납을 검증하는 별도 트랙을 만들었다(3개 테스트 통과). `db.py`/`storage.py`는 아직 이 풀을 실제로 쓰도록 이식되지 않았으므로 Java/Spring 이식 시점의 "미리 검증된 참조 구현"으로만 존재한다. MVP 성공 기준("외부 라이브러리 없이 테스트 하네스 실행 가능")을 지키기 위해 `tests/`는 손대지 않았고, `pyproject.toml`의 `postgres` extra와 `tests_postgres/`로 완전히 분리했다. |
| GC-SEC-002 (parameterized query) | COMPLIANT | `storage.py`의 모든 SQL이 `?` 파라미터 바인딩만 사용한다. |
| GC-SEC-002 (canonicalization) | PARTIAL | `classification.py`에 NFKC 정규화를 적용하고 전각·호환문자 Fixture를 추가했다. 공백 삽입 등 의미 보존형 우회는 추가 Detector가 필요하다. |
| GC-SEC-013 (오류·로그 노출 금지) | COMPLIANT | `api.py`가 외부 응답에 `reasons`만 노출하고 예외 스택트레이스를 전달하지 않는다. |
| GC-BAN-005 (catch 후 성공/빈 값으로 위장) | COMPLIANT | `api.py`의 `decide_egress`가 `except Exception`을 `except ONGuardError`로 교체했다. `exception_policy.fail_closed`가 원인 예외를 `LOGGER.warning(..., extra={error_code, failure_class})`로 관측 가능하게 남긴 뒤 `ONGuardError`로 재분류하고, `decide_egress`는 그걸 받아 명시적으로 Fail-Closed 값을 채운다(`test_no_active_policy_version_is_fail_closed_and_logged`). |
| GC-RSC-017 (Null·기본값 fail-closed) | COMPLIANT | `engine.py`의 모든 미확정 상태가 `UNKNOWN`으로 귀결된다. |
| GC-QA-12 / Evidence-Receipt 원칙 | COMPLIANT (도메인 적용 사례) | ONGuard 자체 `Receipt`(request_hash/policy_hash/decision_hash)가 이 문서의 Evidence 개념을 정책판정 도메인에 적용한 사례다. |
| GC-MSG-001~005 (에러/사유 코드, 메시지 외부화) | PARTIAL | `engine.py`의 Fail-Closed 사유(`ONG-REQ-*`, `ONG-POL-*`)와 `storage.py`의 `verify_receipt`(`ONG-RCP-001`)는 `messages.render_message`로 이식했다. `policy.py`의 `DEFAULT_RULES` 5개 Rule의 `reason`은 여전히 한글 자연어 리터럴이다 — Rule 등록 API가 커스텀 Rule에 자유 텍스트 `reason`을 허용하는 계약과 맞물려 있어, 코드화하려면 "카탈로그 코드/자유 텍스트 겸용" 여부를 먼저 결정해야 한다(별도 스코프로 보류). |
| GC-I18N-001~003 (다국어) | PARTIAL | `messages.py`에 ko/en 카탈로그, 안전한 기본 locale 폴백, 키·포맷변수 완전성 검사를 구현했다. 기본 정책 Rule의 기존 사유 외부화는 남아 있다. |
| GC-THM-001~003 (테마) | N/A | 관리자 Web UI가 MVP 범위에서 제외되어 있다(`ONGuard_본개발_1차범위.md` 제외 범위). UI 착수 시점부터 적용한다. |
| GC-LOG-001~008 (로그 관리) | PARTIAL | `exception_policy.py`가 안정적인 error_code/failure_class 필드로 의존성 실패를 기록한다. 상관관계 ID·JSON formatter·회전·rate limit은 미구현이다. |

| GC-EXC-001~006 (예외처리) | PARTIAL | 분류된 `Failure`, 내부 원인 비노출 `ONGuardError`, 성공값 위장을 막는 `fail_closed`와 mutation Fixture를 구현했다. 저장 rollback·재시도 Harness는 미구현이다. |
| GC-QA-12 / Detector | PARTIAL | `tools/check_good_code_rules.py`에 timeout 누락과 광범위 예외 성공값 반환 AST Detector, 허용·위반 Fixture를 구현했다. 전체 Rule Set Detector는 미구현이다. |

| GC-AI-001~026 | NOT_IMPLEMENTED | AI 규칙은 Goal State 계약으로 추가됐으며 Detector·Fixture·Harness·Receipt 구현은 후속 작업이다. |
| GC-CMP-001~006 | NOT_IMPLEMENTED | 값 비교 규칙은 Goal State 계약이며 언어·DB별 Detector와 경계 Harness가 필요하다. |
| GC-AUT-001~010 | PARTIAL | 기존 GC-SEC-004가 요청별 서버 권한을 요구하지만 세분 권한·생명주기·Receipt Harness는 미구현이다. |
| GC-BIZ-001~004 | NOT_IMPLEMENTED | 상태전이·업무값·중복·정책변경 Harness는 후속 구현 대상이다. |
| GC-LOG-009~011 | NOT_IMPLEMENTED | 로그 schema·신뢰경계·감사무결성 Detector/Harness가 없다. |
| GC-DB-001~008 | PARTIAL | Postgres 참조 시험만 있으며 실제 제품 DB adapter 이식과 장애 Harness는 없다. |
| GC-HTTP-001~008 | NOT_IMPLEMENTED | 실제 client/server/proxy wire-level Harness가 없다. |
| GC-SQL-001~009 | NOT_IMPLEMENTED | parameter binding 코드 리뷰 외 dialect-aware AST/taint Detector가 없다. |
| GC-WAUTH-001~010 | NOT_IMPLEMENTED | Web 인증 계층이 MVP 제외 범위이며 향후 적용 시 필수 Gate다. |
| GC-PRV-001~012 | NOT_IMPLEMENTED | 일반 비밀 보호 원칙 외 개인정보 암호화·키·사본·삭제 Harness가 없다. |

이 표는 `CLAUDE.md`에서 코드 생성 시 우선 참조하는 실행 요약의 근거 데이터다.


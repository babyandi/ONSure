# ONGuard 정책 DSL Rule 구조

## Rule 기본 구조

```json
{
  "rule_id": "rule-l4-deny",
  "version": "2026.07.mvp",
  "priority": 10,
  "when": {
    "channel": "external_llm",
    "classification_level": ["L4", "L5"],
    "actor_ids": [],
    "purpose_keywords": []
  },
  "effect": "DENY",
  "reason": "고위험 정보등급은 외부 LLM 반출을 차단한다."
}
```

## when 조건 필드

| 필드 | 필수 | 매칭 규칙 |
|---|---|---|
| `channel` | Y | 요청 채널과 정확히 일치해야 한다. |
| `classification_level` | Y | 분류 등급이 목록에 포함되어야 한다. |
| `actor_ids` | N | 비어 있으면 모든 사용자에 적용한다(wildcard). 값이 있으면 요청 `actor_id`가 목록에 포함되어야 한다. |
| `purpose_keywords` | N | 비어 있으면 모든 목적에 적용한다(wildcard). 값이 있으면 요청 `purpose`에 목록 중 하나 이상의 키워드가 포함되어야 한다. |

## Rule 평가 원칙

1. 우선순위가 높은 Rule을 먼저 평가한다.
2. `when`의 모든 필드가 동시에 일치하는 첫 Rule의 effect를 적용한다.
3. 일치 Rule이 없으면 `UNKNOWN`으로 처리한다.
4. `UNKNOWN`은 Fail-Closed 원칙에 따라 허용이 아니다.


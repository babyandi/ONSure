# ONGuard API 계약서

## Decision API

`POST /v1/egress/decision`

### 요청

| 필드 | 타입 | 필수 | 설명 |
|---|---|---|---|
| `actor_id` | string | Y | 요청 사용자 또는 시스템 ID |
| `purpose` | string | Y | 사용 목적 |
| `target` | string | Y | 외부 LLM 또는 SaaS AI 대상 |
| `channel` | string | Y | 반출 채널. MVP 기본값은 `external_llm` |
| `content` | string | Y | 반출 전 검사 대상 텍스트 |

### 응답

| 필드 | 타입 | 설명 |
|---|---|---|
| `decision` | string | `ALLOW`, `DENY`, `MASK`, `REVIEW_REQUIRED`, `UNKNOWN` |
| `classification_level` | string | `L0`~`L5` |
| `signals` | array | 탐지 신호 이름 목록 |
| `reasons` | array | 정책 판정 사유 |
| `egress_content` | string | 외부로 전달 가능한 유일한 본문. `ALLOW`는 원문, `MASK`는 마스킹 결과, 그 외 판정은 빈 문자열이다. |
| `egress_content_hash` | string | `egress_content`의 canonical SHA-256이며 Receipt에 결속된다. |
| `audit_persisted` | boolean | 감사 저장 성공 여부. 실패 시 판정은 `UNKNOWN`으로 닫힌다. |
| `receipt` | object | actor·target·정책 버전·판정·반출 본문 Hash에 결속된 감사 Receipt |

## Fail-Closed 계약

필수 입력 누락, 정책 없음·충돌, 미등록 target, 분류 실패, Receipt 생성 실패,
감사 저장 실패는 `ALLOW`로 승격할 수 없다. 응답의 원본 `content`는 별도 필드로
반환하지 않으며 실제 외부 반출 소비자는 반드시 `egress_content`만 사용한다.

# ONGuard TEVV 검증계획서

## 목적

이 문서는 AI 개발 방법론의 시험, 평가, 검증, 확인(TEVV) 기준에 따라 ONGuard MVP의 기능, 보안, 감사, 재현성, 운영 안정성을 검증하는 계획을 정의한다.

## TEVV 범위

| 구분 | 목적 | 대상 |
|---|---|---|
| Test | 구현 기능이 명세대로 동작하는지 확인 | API, 정책판정, 분류기, Receipt |
| Evaluation | 판정 품질과 운영 적합성 평가 | 오탐, 미탐, 응답시간, 감사 가능성 |
| Verification | 설계·계약·코드·테스트 일치 검증 | API 계약, 프로그램 명세, 테이블 설계 |
| Validation | 실제 업무 목적에 부합하는지 확인 | 외부 LLM 반출통제 업무 시나리오 |

## 테스트 유형

| 테스트 ID | 유형 | 검증 내용 | 통과 기준 |
|---|---|---|---|
| `TEVV-POS-001` | Positive | L0/L1 공개·일반 정보 허용 | `ALLOW` |
| `TEVV-NEG-001` | Negative | 개인정보·API Key 차단 | `DENY` |
| `TEVV-MSK-001` | Mask | L3 고객·계약 정보 마스킹 또는 검토 | `MASK` 또는 `REVIEW_REQUIRED` |
| `TEVV-FC-001` | Fail-Closed | 필수값 누락 | `UNKNOWN`, 허용 금지 |
| `TEVV-FC-002` | Fail-Closed | 정책 없음 | `UNKNOWN`, 허용 금지 |
| `TEVV-RCP-001` | Receipt | 동일 입력 재현성 | 동일 `decision_hash` |
| `TEVV-AUD-001` | Audit | 모든 판정 감사 이벤트 저장 | 누락 0건 |
| `TEVV-ADV-001` | Adversarial | 우회 표현, 분할 입력, 혼합 언어 | 차단 또는 검토 |
| `TEVV-PERF-001` | Performance | 단건 판정 응답시간 | MVP 기준선 측정 |
| `TEVV-IDX-001` | DB Index | 감사 조회 인덱스 사용 | 지정 인덱스 사용 확인 |

## Fixture 구성

| Fixture 그룹 | 예시 |
|---|---|
| 공개 정보 | 제품 소개, 일반 기술 설명 |
| 내부 정보 | 부서명, 프로젝트명, 내부 업무 지시 |
| 고객 정보 | 고객명, 계좌, 계약, 잔고, 주문 |
| 개인정보 | 주민번호형 패턴, 전화번호, 이메일 |
| 핵심정보 | 핵심기술, 비공개 전략, 중대 규제정보 |
| 오류 입력 | 빈 content, target 누락, channel 누락 |
| 적대 입력 | 띄어쓰기 분리, 마스킹 우회, 혼합 언어, 인코딩 변형 |

## 승인 기준

| 기준 | MVP 승인 조건 |
|---|---|
| 기능 테스트 | 핵심 Positive/Negative/Fail-Closed 테스트 통과 |
| 감사 테스트 | 모든 판정에 Receipt 생성 |
| 재현성 테스트 | 동일 입력·정책 기준 동일 digest |
| 안전성 테스트 | 오류와 미일치 Rule이 허용으로 승격되지 않음 |
| 성능 테스트 | 기준선 측정값 확보. 운영 목표치는 별도 확정 |

## OBuilder 연계

OBuilder는 이 계획서를 기준으로 다음 산출물을 생성해야 한다.

1. 테스트 Fixture Catalog
2. 단위 테스트 Skeleton
3. 통합 테스트 Harness
4. 적대 테스트 입력 세트
5. 테스트 Receipt와 검증 결과 요약

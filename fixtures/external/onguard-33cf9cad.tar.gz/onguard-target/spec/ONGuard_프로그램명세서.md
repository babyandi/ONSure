# ONGuard 프로그램 명세서

## 문서 목적

이 문서는 ONGuard MVP 개발 착수를 위한 프로그램 단위 명세를 정의한다. 각 프로그램은 모듈 책임, 입력, 출력, 참조 테이블, 예외 처리, 테스트 기준을 가진다.

## 프로그램 구성 원칙

| 원칙 | 내용 |
|---|---|
| 단일 책임 | 하나의 프로그램은 하나의 주요 판정·저장·조회 책임을 가진다. |
| 계약 우선 | API 계약, 데이터 모델, 테이블 설계와 필드명이 어긋나지 않아야 한다. |
| Fail-Closed | 오류 발생 시 허용 판정으로 자동 승격하지 않는다. |
| 감사 결속 | 정책판정 결과는 Receipt와 감사 이벤트로 연결되어야 한다. |
| 재현성 | 동일 요청·정책 기준선은 동일한 판정 해시를 생성해야 한다. |

## 프로그램 목록

| 프로그램 ID | 프로그램명 | 모듈 | 주요 책임 |
|---|---|---|---|
| `ONG-EG-API-001` | 반출판정 API | Egress Guard | 외부 LLM 반출 요청 수신과 응답 반환 |
| `ONG-CE-CLS-001` | 정보등급 분류기 | Classification Engine | L0~L5 등급과 탐지 신호 산출 |
| `ONG-PC-RUL-001` | 정책 Rule 조회기 | Policy Center | 활성 정책과 Rule 집합 조회 |
| `ONG-PC-DEC-001` | 정책판정 엔진 | Policy Center | 분류 결과와 Rule 기준 최종 판정 |
| `ONG-AC-RCP-001` | Receipt 생성기 | Audit Center | 요청·정책·판정 해시 기반 Receipt 생성 |
| `ONG-AC-LOG-001` | 감사 이벤트 기록기 | Audit Center | 반출 요청과 판정 이벤트 저장 |
| `ONG-AC-QRY-001` | 감사 이력 조회기 | Audit Center | 사용자·판정·정책 버전별 이력 조회 |
| `ONG-OP-HLT-001` | 상태 점검기 | Operation | 정책·DB·분류기 상태 점검 |
| `ONG-TH-TST-001` | 테스트 하네스 | Test Harness | Positive/Negative/Fail-Closed 검증 |

## 프로그램-테이블 매핑

| 프로그램 ID | 주요 입력 테이블 | 주요 출력 테이블 |
|---|---|---|
| `ONG-EG-API-001` | 없음 | `ong_egress_request` |
| `ONG-CE-CLS-001` | `ong_classification_pattern` | `ong_classification_result` |
| `ONG-PC-RUL-001` | `ong_policy_set`, `ong_policy_rule` | 없음 |
| `ONG-PC-DEC-001` | `ong_policy_rule`, `ong_classification_result` | `ong_policy_decision` |
| `ONG-AC-RCP-001` | `ong_policy_decision` | `ong_receipt` |
| `ONG-AC-LOG-001` | 처리 이벤트 | `ong_audit_event` |
| `ONG-AC-QRY-001` | 감사 테이블 전체 | 없음 |
| `ONG-OP-HLT-001` | `ong_policy_set`, `ong_audit_event` | 없음 |
| `ONG-TH-TST-001` | 테스트 fixture | 테스트 결과 |

## 핵심 프로그램 상세

| 프로그램 ID | 입력 | 출력 | 예외 처리 | 테스트 기준 |
|---|---|---|---|---|
| `ONG-EG-API-001` | `actor_id`, `purpose`, `target`, `channel`, `content` | `decision`, `classification_level`, `reasons`, `receipt` | 필수 입력 누락, 정책판정 실패, Receipt 생성 실패 시 `UNKNOWN` 또는 `DENY` | API 응답 필드가 계약서와 일치하고 모든 응답에 Receipt 포함 |
| `ONG-CE-CLS-001` | `content`, `channel`, 선택적으로 `purpose` | `classification_level`, `signals`, `classifier_version` | 본문 없음 또는 분류 실패 시 L5 상당 안전 등급 | 개인정보, 계좌번호, API Key, 내부업무, 핵심정보 샘플 식별 |
| `ONG-PC-RUL-001` | `channel`, `policy_set_id`, 기준 시각 | 정렬된 `PolicyRule`, `policy_hash`, `policy_version` | 활성 정책 없음, 정책 해시 불일치, Rule 없음은 Fail-Closed | 정책 버전별 Rule 조회와 우선순위 정렬 검증 |
| `ONG-PC-DEC-001` | `EgressRequest`, `ClassificationResult`, `PolicyRule` 목록 | `PolicyDecision`, `decision_hash`, `reasons` | 일치 Rule 없음, 필수 입력 누락, 정책 조회 실패 시 `UNKNOWN` | L0/L1 허용, L3 마스킹·검토, L4/L5 차단, Rule 없음 Unknown 검증 |
| `ONG-AC-RCP-001` | 요청 해시, 정책 해시, 판정 해시, 사유, 정책 버전 | `receipt_id`, `receipt_payload_json` | Receipt 생성 또는 저장 실패는 허용 판정으로 승격 불가 | 동일 입력·정책·판정은 동일 `decision_hash` 생성 |
| `ONG-AC-LOG-001` | 이벤트 유형, 요청 ID, 판정 ID, 사용자, 상세 payload | `event_id` | 감사 저장 실패 시 운영 이벤트를 남기고 안전 판정 종료 | 차단·검토·오류 이벤트 조회 가능 |
| `ONG-AC-QRY-001` | 기간, 사용자, 대상 LLM, 판정, 정책 버전 | 요청 이력, 판정 이력, Receipt 요약 | 권한 없음, 조건 오류, 조회 범위 초과 시 거부 | 사용자별, 판정별, 정책 버전별 조회가 인덱스 기준과 일치 |
| `ONG-OP-HLT-001` | 없음 또는 점검 범위 | 정책 상태, DB 상태, 분류기 상태, 최근 오류 | 실패 구성요소가 있으면 `DEGRADED` 또는 `BLOCKED` | 정책 없음과 DB 저장 실패를 정상 상태로 보고하지 않음 |
| `ONG-TH-TST-001` | Positive/Negative/Adversarial fixture | 테스트 결과, 실패 사유, 재현 입력 | fixture 오류는 제품 통과로 간주하지 않음 | 단위 테스트와 최소 적대 테스트 모두 통과 |

## 개발 완료 기준

| 기준 | 완료 조건 |
|---|---|
| 명세 일치 | 프로그램 입력·출력 필드가 API 계약서와 데이터 모델에 존재한다. |
| 저장 일치 | 프로그램별 출력 데이터가 테이블 설계서의 대상 테이블에 매핑된다. |
| 예외 일치 | 예외 경로가 Fail-Closed 계약과 충돌하지 않는다. |
| 테스트 일치 | 각 프로그램의 최소 테스트 기준이 테스트 하네스에 반영된다. |

"""ONGuard 스키마의 PostgreSQL 이식성과 커넥션 풀 동작을 검증하는 선택적 스위트.

tests/ (SQLite, 무의존성)와 분리된 트랙이다. MVP 성공 기준에는 포함되지 않으며,
GC-RSC-002/020(DB 자원 소유권, Pool 상한) 검증을 위해서만 존재한다.
.devcontainer/docker-compose.yml의 onguard-postgres-1 컨테이너가 떠 있지 않거나
psycopg2가 없으면 skip 처리하며, 이는 실패(FAIL)가 아니라 이 트랙이 실행되지
않았다는 뜻이다 (docs/spec의 GC 문서가 구분하는 NOT_RUN에 해당).

실행 방법:
    docker compose -f .devcontainer/docker-compose.yml up -d
    pip install -e ".[postgres]"
    PYTHONPATH=src python -m unittest discover -s tests_postgres -v
"""

from __future__ import annotations

import os
import unittest

try:
    import psycopg2
    import psycopg2.pool
except ImportError:  # pragma: no cover - 선택적 의존성
    psycopg2 = None

DSN = {
    "host": os.environ.get("ONGUARD_PG_HOST", "localhost"),
    "port": int(os.environ.get("ONGUARD_PG_PORT", "5433")),
    "dbname": os.environ.get("ONGUARD_PG_DB", "onguard"),
    "user": os.environ.get("ONGUARD_PG_USER", "onguard"),
    "password": os.environ.get("ONGUARD_PG_PASSWORD", "onguard"),
}


def _pool_available() -> psycopg2.pool.ThreadedConnectionPool | None:
    if psycopg2 is None:
        return None
    try:
        pool = psycopg2.pool.ThreadedConnectionPool(minconn=1, maxconn=4, **DSN)
        conn = pool.getconn()
        pool.putconn(conn)
        return pool
    except psycopg2.OperationalError:
        return None


_POOL = _pool_available()


@unittest.skipUnless(psycopg2 is not None, "psycopg2가 설치되어 있지 않다 (pip install -e '.[postgres]')")
@unittest.skipUnless(_POOL is not None, "onguard-postgres-1 컨테이너에 연결할 수 없다 (docker compose up -d)")
class PostgresSchemaTests(unittest.TestCase):
    """GC-RSC-002(Pool 상한·획득 timeout)와 GC-RSC-020(자원 소유권) 검증."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.pool = _POOL

    @classmethod
    def tearDownClass(cls) -> None:
        # 풀이 소유한 모든 커넥션을 명시적으로 닫는다 — GC-RSC-020 "누가 언제 닫는가".
        cls.pool.closeall()

    def setUp(self) -> None:
        # 운영 앱에는 TRUNCATE 권한을 주지 않는다. 스키마 소유자인 시험 전용
        # 연결만 FK 순서·Append-only 행 Trigger를 우회해 Fixture를 초기화한다.
        conn = self.pool.getconn()
        try:
            with conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "TRUNCATE ong_audit_event, ong_receipt, ong_policy_decision, "
                        "ong_egress_request, ong_policy_rule, ong_policy_version CASCADE"
                    )
        finally:
            self.pool.putconn(conn)

    def test_schema_tables_exist(self) -> None:
        # db/onguard_schema.sql이 initdb 스크립트로 정상 적용됐는지 확인한다.
        conn = self.pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT table_name FROM information_schema.tables
                    WHERE table_schema = 'public' AND table_name LIKE 'ong_%'
                    """
                )
                tables = {row[0] for row in cur.fetchall()}
        finally:
            self.pool.putconn(conn)

        for expected in (
            "ong_policy_version",
            "ong_policy_rule",
            "ong_egress_request",
            "ong_policy_decision",
            "ong_receipt",
        ):
            self.assertIn(expected, tables)

    def test_separate_pooled_connections_see_shared_state(self) -> None:
        # SQLite ':memory:'와 달리, 풀에서 "동시에" 뽑은 서로 다른 커넥션이 같은 데이터를 봐야 한다.
        # writer를 반납하기 전에 reader를 먼저 뽑아서, 풀이 재사용이 아니라 실제로
        # 별개의 커넥션 객체 2개를 동시에 내주는 상황을 강제로 만든다.
        writer = self.pool.getconn()
        try:
            reader = self.pool.getconn()
            try:
                self.assertIsNot(reader, writer, "풀이 동시 요청에 서로 다른 커넥션을 배정하지 않았다")

                with writer:
                    with writer.cursor() as cur:
                        cur.execute(
                            "INSERT INTO ong_policy_version(policy_version, status, description) "
                            "VALUES (%s, %s, %s)",
                            ("2026.07.pg-test", "ACTIVE", "postgres pool test"),
                        )

                with reader.cursor() as cur:
                    cur.execute(
                        "SELECT status FROM ong_policy_version WHERE policy_version = %s",
                        ("2026.07.pg-test",),
                    )
                    row = cur.fetchone()
            finally:
                self.pool.putconn(reader)
        finally:
            self.pool.putconn(writer)

        self.assertIsNotNone(row, "다른 커넥션에서 커밋한 데이터가 보이지 않는다")
        self.assertEqual(row[0], "ACTIVE")

    def test_policy_rule_round_trip(self) -> None:
        conn = self.pool.getconn()
        try:
            with conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "INSERT INTO ong_policy_version(policy_version, status, description) "
                        "VALUES (%s, %s, %s)",
                        ("2026.07.pg-rule-test", "ACTIVE", "rule round trip"),
                    )
                    cur.execute(
                        """
                        INSERT INTO ong_policy_rule(
                            rule_id, policy_version, priority, channel, levels_json,
                            effect, reason, active, actor_ids_json, purpose_keywords_json
                        )
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            "pg-rule-l4-deny",
                            "2026.07.pg-rule-test",
                            100,
                            "external_llm",
                            '["L4", "L5"]',
                            "DENY",
                            "postgres round trip test",
                            True,
                            "[]",
                            "[]",
                        ),
                    )
                    cur.execute(
                        "SELECT effect FROM ong_policy_rule WHERE rule_id = %s",
                        ("pg-rule-l4-deny",),
                    )
                    row = cur.fetchone()
        finally:
            self.pool.putconn(conn)

        self.assertEqual(row[0], "DENY")

    def test_audit_lineage_rejects_update_and_delete(self) -> None:
        conn = self.pool.getconn()
        try:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO ong_egress_request("
                    "request_hash, request_id, actor_id, purpose, target, channel, content_hash"
                    ") VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    ("1" * 64, "pg-append-only", "actor", "test", "external-llm",
                     "external_llm", "2" * 64),
                )
                cur.execute(
                    "INSERT INTO ong_policy_decision("
                    "decision_hash, request_hash, policy_version, policy_hash, decision, "
                    "classification_level, signals_json, reasons_json"
                    ") VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                    ("3" * 64, "1" * 64, "2026.07", "4" * 64, "ALLOW", "L0", "[]", "[]"),
                )
                cur.execute(
                    "INSERT INTO ong_receipt("
                    "receipt_id, decision_hash, request_hash, policy_hash, policy_version, "
                    "receipt_payload_json"
                    ") VALUES (%s, %s, %s, %s, %s, %s)",
                    ("rcpt-pg-append-only", "3" * 64, "1" * 64, "4" * 64,
                     "2026.07", "{}"),
                )
                cur.execute(
                    "INSERT INTO ong_audit_event(event_id, decision_hash, receipt_id) "
                    "VALUES (%s, %s, %s)",
                    ("evt-pg-append-only", "3" * 64, "rcpt-pg-append-only"),
                )
                with self.assertRaises(psycopg2.Error):
                    cur.execute(
                        "UPDATE ong_receipt SET policy_version = 'tampered' "
                        "WHERE receipt_id = 'rcpt-pg-append-only'"
                    )
                with self.assertRaises(psycopg2.Error):
                    cur.execute(
                        "DELETE FROM ong_audit_event "
                        "WHERE event_id = 'evt-pg-append-only'"
                    )
        finally:
            self.pool.putconn(conn)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    receipt = json.loads((root / "artifacts/good-code-campaign-receipt.json").read_text(encoding="utf-8"))
    command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_extended_good_code_gate.py", "-v"]
    result = subprocess.run(command, cwd=root, text=True, capture_output=True, check=False)
    raw = result.stdout + result.stderr
    normalized = re.sub(r"Ran (\d+) tests? in [0-9.]+s", r"Ran \1 tests in <elapsed>", raw)
    raw_hash = hashlib.sha256(normalized.encode()).hexdigest()
    expected_hashes = {run["raw_result_hash"] for run in receipt["runs"]}
    errors = []
    if result.returncode:
        errors.append("independent test reproduction failed")
    if raw_hash not in expected_hashes:
        errors.append("reproduced raw result differs from campaign")
    if receipt.get("tested_head") in {None, "", "LOCAL_UNCOMMITTED"}:
        errors.append("tested HEAD is not bound")
    print(json.dumps({"decision": "CLEAN" if not errors else "FAIL", "errors": errors}, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())

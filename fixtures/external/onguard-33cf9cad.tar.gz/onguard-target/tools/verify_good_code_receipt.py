from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    receipt_path = Path(sys.argv[1] if len(sys.argv) > 1 else root / "artifacts/good-code-campaign-receipt.json")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    expected = {
        "catalog_digest": sha(root / "docs/spec/good_code_rule_traceability.json"),
        "detector_digest": sha(root / "tools/check_extended_good_code_rules.py"),
        "trace_validator_digest": sha(root / "tools/validate_rule_traceability.py"),
        "fixture_digest": hashlib.sha256(
            b"".join(path.read_bytes() for path in sorted((root / "tests/fixtures/good_code_extended").glob("*.py")))
        ).hexdigest(),
    }
    errors = [f"{key} mismatch" for key, value in expected.items() if receipt.get(key) != value]
    if receipt.get("slice_decision") != "CLEAN_2":
        errors.append("slice is not CLEAN_2")
    if len(receipt.get("runs", [])) != 2 or any(run.get("decision") != "CLEAN" for run in receipt.get("runs", [])):
        errors.append("two CLEAN runs are not present")
    if receipt.get("overall_decision") != "FINAL_HOLD":
        errors.append("overall fail-closed decision missing")
    print(json.dumps({"decision": "CLEAN" if not errors else "FAIL", "errors": errors}, indent=2))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())

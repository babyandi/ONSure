from __future__ import annotations

import ast
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Finding:
    rule_id: str
    path: str
    line: int
    message: str


def dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = dotted_name(node.value)
        return f"{base}.{node.attr}" if base else node.attr
    return ""


def has_dynamic_sql(node: ast.AST) -> bool:
    if isinstance(node, ast.JoinedStr):
        return True
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod)):
        return True
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format":
        return True
    return False


class Detector(ast.NodeVisitor):
    HTTP_METHODS = {"get", "post", "put", "patch", "delete", "request"}
    SQL_METHODS = {"execute", "executemany", "executescript"}
    SECRET_NAMES = {"password", "passwd", "secret", "api_key", "apikey", "access_token", "private_key"}

    def __init__(self, path: Path) -> None:
        self.path = path
        self.findings: list[Finding] = []

    def add(self, rule_id: str, node: ast.AST, message: str) -> None:
        self.findings.append(Finding(rule_id, str(self.path), getattr(node, "lineno", 0), message))

    def visit_Call(self, node: ast.Call) -> None:
        name = dotted_name(node.func)
        leaf = name.rsplit(".", 1)[-1]
        if leaf in self.HTTP_METHODS and (
            name.startswith(("requests.", "httpx.", "session.", "client."))
            or ".client." in name
            or ".session." in name
        ):
            if not any(item.arg in {"timeout", "deadline"} for item in node.keywords):
                self.add("GC-HTTP-001", node, "HTTP call has no explicit timeout/deadline")
        if leaf in self.SQL_METHODS and node.args and has_dynamic_sql(node.args[0]):
            self.add("GC-SQL-002", node, "dynamic SQL construction reaches an execution sink")
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str) and node.value.value:
            for target in node.targets:
                name = dotted_name(target).lower()
                if name.rsplit(".", 1)[-1] in self.SECRET_NAMES and len(node.value.value) >= 6:
                    self.add("GC-SEC-012", node, "hard-coded secret-like value")
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        broad = node.type is None or (
            isinstance(node.type, ast.Name) and node.type.id in {"Exception", "BaseException"}
        )
        terminal = node.body[-1] if node.body else None
        success_like = isinstance(terminal, ast.Return) and (
            terminal.value is None
            or isinstance(terminal.value, ast.Constant) and terminal.value.value in {None, 0, True}
            or isinstance(terminal.value, (ast.List, ast.Tuple)) and not terminal.value.elts
            or isinstance(terminal.value, ast.Dict) and not terminal.value.keys
        )
        if broad and success_like:
            self.add("GC-BAN-005", node, "broad exception returns a success-like default")
        self.generic_visit(node)


def scan(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    paths = [root] if root.is_file() else sorted(root.rglob("*.py"))
    for path in paths:
        if any(part in {".git", ".venv", "__pycache__"} for part in path.parts):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (OSError, SyntaxError) as exc:
            findings.append(Finding("GC-VLD-002", str(path), getattr(exc, "lineno", 0) or 0, "source cannot be parsed"))
            continue
        detector = Detector(path)
        detector.visit(tree)
        findings.extend(detector.findings)
    return findings


def main() -> int:
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "src")
    findings = scan(target)
    print(json.dumps([asdict(item) for item in findings], ensure_ascii=False, indent=2, sort_keys=True))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())

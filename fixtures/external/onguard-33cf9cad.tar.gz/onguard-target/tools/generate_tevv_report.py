from __future__ import annotations

import subprocess
import sys
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "docs" / "tevv" / "ONGuard_TEVV_1차검증리포트.md"
# 검증일은 프로젝트 기준 시간대인 서울 시간으로 고정한다.
KST = timezone(timedelta(hours=9))


def run_tests() -> str:
    """TEVV 리포트에 첨부할 unittest 실행 결과를 수집한다."""

    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        env={**os.environ, "PYTHONPATH": "src"},
        text=True,
        capture_output=True,
        check=False,
    )
    return completed.stdout + completed.stderr


def main() -> int:
    """테스트 결과를 PASS/FAIL로 판정하고 Markdown 리포트를 생성한다."""

    output = run_tests()
    result = "PASS" if "\nOK\n" in output or output.rstrip().endswith("OK") else "FAIL"
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(
        f"""# ONGuard TEVV 1차 검증 리포트

## 검증 개요

| 항목 | 내용 |
|---|---|
| 검증일 | {datetime.now(KST).date().isoformat()} |
| 대상 | ONGuard Python MVP 본 개발 1차 범위 |
| 실행 명령 | `PYTHONPATH=src python -m unittest discover -s tests -v` |
| 결과 | {result} |

## 테스트 출력

```text
{output.strip()}
```
""",
        encoding="utf-8",
    )
    return 0 if result == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "doc" / "report"
BLUE = "1F4E78"
MID_BLUE = "D9EAF7"
PALE_BLUE = "EEF5FA"
GRAY = "5B6573"
LIGHT_GRAY = "F4F6F9"
RED = "9C2F2F"
GREEN = "1B6B50"
BODY_FONT = "Noto Sans CJK KR"


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top: int = 80, start: int = 120, bottom: int = 80, end: int = 120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def keep_row_together(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def add_page_field(paragraph) -> None:
    run = paragraph.add_run()
    fld_char = OxmlElement("w:fldChar")
    fld_char.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char, instr, fld_end])


def set_run_font(run, size: float | None = None, bold: bool | None = None, color: str | None = None) -> None:
    run.font.name = BODY_FONT
    run._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def configure_document(doc: Document, short_title: str) -> None:
    section = doc.sections[0]
    section.top_margin = Cm(1.7)
    section.bottom_margin = Cm(1.55)
    section.left_margin = Cm(1.9)
    section.right_margin = Cm(1.9)

    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    for style_name, size, color, before, after in (
        ("Title", 24, "000000", 0, 4),
        ("Subtitle", 14, GRAY, 0, 8),
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 11.5, "244A67", 8, 4),
    ):
        style = doc.styles[style_name]
        style.font.name = BODY_FONT
        style._element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    header_run = header.add_run(short_title)
    set_run_font(header_run, 8.5, True, GRAY)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_run = footer.add_run("KNLSOFT | 사전작성본 | ")
    set_run_font(footer_run, 8, False, GRAY)
    add_page_field(footer)


def add_para(
    doc: Document,
    text: str,
    *,
    bold: bool = False,
    color: str | None = None,
    align=None,
    size: float | None = None,
    after: float | None = None,
) -> None:
    paragraph = doc.add_paragraph()
    if align is not None:
        paragraph.alignment = align
    if after is not None:
        paragraph.paragraph_format.space_after = Pt(after)
    run = paragraph.add_run(text)
    set_run_font(run, size, bold, color)


def add_title_page(
    doc: Document,
    company: str,
    title: str,
    subtitle: str,
    program: str,
    left_items: list[tuple[str, str]],
    right_items: list[tuple[str, str]],
) -> None:
    add_para(doc, company, bold=True, color=GRAY, align=WD_ALIGN_PARAGRAPH.CENTER, size=12, after=8)
    add_para(doc, title, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER, size=24, after=4)
    add_para(doc, subtitle, color=GRAY, align=WD_ALIGN_PARAGRAPH.CENTER, size=14, after=8)
    add_para(doc, program, bold=True, color=GRAY, align=WD_ALIGN_PARAGRAPH.CENTER, size=10.5, after=20)
    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_repeat_table_header(table.rows[0])
    table.columns[0].width = Cm(8.0)
    table.columns[1].width = Cm(8.0)
    for index, items in enumerate((left_items, right_items)):
        cell = table.cell(0, index)
        set_cell_shading(cell, PALE_BLUE)
        set_cell_margins(cell, 180, 220, 180, 220)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
        cell.text = ""
        for label, value in items:
            p = cell.add_paragraph() if cell.paragraphs[0].text else cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(5)
            label_run = p.add_run(f"{label}  ")
            set_run_font(label_run, 9, True, BLUE)
            value_run = p.add_run(value)
            set_run_font(value_run, 9, False, "202830")
    add_para(
        doc,
        "제출 Gate: 법인·재무·신용·부채·IP·컨소시엄 증빙 확인 전에는 ‘제출 가능’으로 전환하지 않는다.",
        bold=True,
        color=RED,
        align=WD_ALIGN_PARAGRAPH.CENTER,
        size=9.2,
        after=0,
    )
    doc.add_page_break()


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    doc.add_heading(text, level=level)


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.line_spacing = 1.2
        run = p.add_run(item)
        set_run_font(run, 10.2)


def add_numbered(doc: Document, items: list[str]) -> None:
    for item in items:
        p = doc.add_paragraph(style="List Number")
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.line_spacing = 1.2
        run = p.add_run(item)
        set_run_font(run, 10.2)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths_cm: list[float] | None = None) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = widths_cm is None
    header_row = table.rows[0]
    set_repeat_table_header(header_row)
    keep_row_together(header_row)
    for index, header in enumerate(headers):
        cell = header_row.cells[index]
        set_cell_shading(cell, MID_BLUE)
        set_cell_margins(cell)
        cell.text = ""
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(header)
        set_run_font(r, 9, True, BLUE)
        if widths_cm:
            cell.width = Cm(widths_cm[index])
    for row_values in rows:
        row = table.add_row()
        keep_row_together(row)
        for index, value in enumerate(row_values):
            cell = row.cells[index]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(value)
            set_run_font(r, 8.7)
            if widths_cm:
                cell.width = Cm(widths_cm[index])
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_gate_box(doc: Document, title: str, items: list[str], color: str = LIGHT_GRAY) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    cell = table.cell(0, 0)
    set_repeat_table_header(table.rows[0])
    set_cell_shading(cell, color)
    set_cell_margins(cell, 140, 180, 140, 180)
    p = cell.paragraphs[0]
    r = p.add_run(title)
    set_run_font(r, 10.2, True, RED if color == "FCE8E8" else BLUE)
    for item in items:
        q = cell.add_paragraph(style="List Bullet")
        q.paragraph_format.space_after = Pt(2)
        rr = q.add_run(item)
        set_run_font(rr, 9.2)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def page_break(doc: Document) -> None:
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


def save(doc: Document, name: str) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / name
    doc.save(path)
    return path


def build_ax_proposal() -> Path:
    doc = Document()
    configure_document(doc, "ONGuard AX R&D 계획서")
    add_title_page(
        doc,
        "주식회사 케이엔엘소프트",
        "ONGuard × ONSure",
        "AI 반출통제·검증 증적 자동화 플랫폼",
        "2027 AX혁신기업 창의기술개발 — 사전 연구개발계획서",
        [
            ("주관기관", "주식회사 케이엔엘소프트"),
            ("설립", "2014년(공식 회사 연혁 기준)"),
            ("연구조직", "기업부설연구소 보유 이력 — 증명서 갱신 확인 필요"),
            ("기술분야", "인공지능 · 사이버보안 · AI 거버넌스"),
        ],
        [
            ("기준 공고", "2026년 공고 구조를 사용한 2027 사전작성본"),
            ("연구기간", "최대 1년 9개월 시나리오"),
            ("정부지원금", "2026 기준 최대 6.475억원 — 2027 공고로 재확정"),
            ("현재 판정", "SELF_VALIDATION_NONFINAL / HOLD"),
        ],
    )

    add_heading(doc, "1. 과제 요약")
    add_para(
        doc,
        "기업이 생성형 AI와 외부 LLM을 업무에 도입할 때 개인정보·기밀·프롬프트 공격이 조직 밖으로 "
        "나가기 전에 차단하고, 모든 정책판정과 검증 결과를 재현 가능한 증적으로 남기는 AX 보안 플랫폼을 개발한다. "
        "ONGuard는 실시간 반출통제와 정책판정을, ONSure는 적대 Fixture·반복검증·Receipt 검증을 담당한다.",
    )
    add_table(
        doc,
        ["구분", "현행 문제", "개발 결과"],
        [
            ["통제", "LLM 입력이 DLP·정책체계 밖에서 직접 반출", "PII·기밀·프롬프트 공격 정규화 탐지, DENY/MASK/REVIEW"],
            ["검증", "단일 테스트 PASS가 통제 완전성으로 오인", "세부 시나리오별 Fixture, 3중 반복, Source·Result·Lock 결속"],
            ["감사", "누가 어떤 정책으로 무엇을 허용했는지 재현 곤란", "서명 Receipt, Append-only 감사, 정책·대상·사용자 Hash 결속"],
            ["사업화", "AI 도입을 막거나 수작업 승인에 의존", "API·Proxy·SDK형 통제 및 TEVV 증적 서비스"],
        ],
        [2.0, 6.4, 7.6],
    )
    add_gate_box(
        doc,
        "현재 성과 기준선",
        [
            "ONGuard main: 정책엔진·실제 마스킹·Receipt 결속·감사 Fail-Closed 반영",
            "ONSure main: 전체 회귀 162/162 PASS(현재 환경 재현), ONGuard 학습 Pack·3중 하네스 보유",
            "독립 OTester/OAudit와 운영형 Sandbox·서명키 운영은 아직 미완료이므로 최종 인증으로 표현하지 않음",
        ],
        PALE_BLUE,
    )

    page_break(doc)
    add_heading(doc, "2. 문제 정의와 시장 필요")
    add_heading(doc, "2.1 수요기업의 의사결정 문제", 2)
    add_bullets(
        doc,
        [
            "AI 사용을 허용하면 정보유출·규제·감사 리스크가 커지고, 전면 차단하면 생산성 혁신이 멈춘다.",
            "기존 DLP는 프롬프트 우회·다중 구분자·외부 AI 대상·정책 버전 결속을 충분히 설명하지 못한다.",
            "보안 담당자는 ‘막았다’가 아니라 어떤 입력·정책·결과가 재현되는지 평가자에게 증명해야 한다.",
            "도입기업은 PoC·감사·사고대응에 같은 증적을 반복 생성하므로 표준화된 Receipt가 필요하다.",
        ],
    )
    add_heading(doc, "2.2 목표 고객·초기 시장", 2)
    add_table(
        doc,
        ["고객군", "초기 사용사례", "구매 기준", "PoC 성공지표"],
        [
            ["공공·금융·의료", "외부 생성형 AI 반출 Gateway", "개인정보·감사·접근통제", "Known-bad 차단율, 증적 재현성"],
            ["SI·MSP·AI 플랫폼", "고객별 정책 SDK/Proxy", "연동성·멀티테넌시·성능", "API 지연, 정책 배포시간"],
            ["중견기업 보안팀", "사내 Copilot·LLM 통제", "운영비·가시성·승인흐름", "오탐률, 수동승인 감소"],
        ],
        [3.1, 5.1, 4.1, 3.7],
    )

    page_break(doc)
    add_heading(doc, "3. 연구개발 목표와 차별성")
    add_table(
        doc,
        ["세부목표", "기준선", "종료목표", "검증방법"],
        [
            ["T1 통제 커버리지", "보안 Mutation 15종 및 기본 패턴", "295 규칙을 구현·부분·비적용으로 증적 결속하고 P0 전부 실행", "Known-bad/known-good Fixture, Mutation score"],
            ["T2 Receipt 신뢰성", "SHA-256 무결성", "비대칭 서명·키회전·폐기·재생방지", "변조/구키/미등록키/재생 공격"],
            ["T3 감사 불변성", "앱 레벨 Insert", "PostgreSQL 권한·Trigger·보존정책 기반 Append-only", "UPDATE/DELETE/권한우회 적대시험"],
            ["T4 격리 실행", "로컬 프로세스 제한", "실제 네트워크 격리·호스트환경 차단·SBOM", "Egress 시도, HOME/PATH/Secret 노출 시험"],
            ["T5 독립 TEVV", "SELF_VALIDATION_NONFINAL", "외부 OTester·OAaudit 봉인 재실행", "동일 Digest·독립성 Receipt·불일치 분석"],
        ],
        [3.2, 3.7, 5.3, 3.8],
    )
    add_heading(doc, "3.1 핵심 차별성", 2)
    add_numbered(
        doc,
        [
            "반출 전 통제: 사후 로그 분석이 아니라 외부 AI로 전달되기 전 정책판정과 마스킹을 수행한다.",
            "증적 결속: 사용자·대상·정책 버전·실제 반출 Hash를 하나의 Receipt로 묶는다.",
            "검증의 검증: 하네스가 Source Reference, Evidence ID, 환경격리와 프로세스 종료코드를 독립 확인한다.",
            "학습형 회귀: 발견된 우회패턴을 Learned Pack으로 고정하고 다음 릴리스의 전용 Fixture로 재사용한다.",
        ],
    )

    page_break(doc)
    add_heading(doc, "4. 연구개발 추진체계와 WBS")
    add_table(
        doc,
        ["단계", "기간", "주요 개발", "Gate 산출물"],
        [
            ["1단계", "M1–M3", "요구사항·위협모델·컨소시엄 공동설계, 295규칙 분류", "기준선 Lock, P0 규칙맵, 시험계획"],
            ["2단계", "M4–M9", "정책엔진·서명 Receipt·PostgreSQL Append-only·격리 Runner", "알파 릴리스, CI 증적, 1차 PoC"],
            ["단계평가", "M9", "27→14 선발 구조를 가정한 성능·보안·사업성 평가", "중간 TEVV, 고객확인서, 다음단계 계획"],
            ["3단계", "M10–M15", "멀티테넌시·정책센터·관제 UI·연동 SDK", "베타 릴리스, 2개 실증"],
            ["4단계", "M16–M21", "상용화 고도화·독립검증·운영 매뉴얼", "외부 OTester/OAudit, 상용 패키지"],
        ],
        [2.2, 2.0, 7.5, 4.3],
    )
    add_heading(doc, "4.1 컨소시엄 구성 원칙", 2)
    add_bullets(
        doc,
        [
            "주관: 케이엔엘소프트 — 제품·정책엔진·사업화·고객 PoC 총괄.",
            "공동기업(필수): AI 서비스/수요기업 후보 — 실제 업무흐름과 실증데이터 제공.",
            "독립검증기관: OTester/OAudit 역할을 수행하되 개발조직과 승인권·키·실행환경을 분리.",
            "2027 공고에서 참여자격·기관 수·민간부담금이 바뀌면 제출본 WBS와 예산을 재산정.",
        ],
    )

    page_break(doc)
    add_heading(doc, "5. 정량 KPI와 TEVV")
    add_table(
        doc,
        ["KPI", "측정식", "M9", "M21", "통과조건"],
        [
            ["P0 우회 차단율", "차단 Known-bad / 전체 P0 Known-bad", "≥ 98%", "≥ 99.5%", "하한 미달 시 FAIL"],
            ["Known-good 정확도", "정상 허용 / 전체 Known-good", "≥ 95%", "≥ 98%", "오탐 원인 기록"],
            ["Receipt 변조탐지", "탐지 변조 / 전체 변조", "100%", "100%", "미탐 1건도 FAIL"],
            ["재현 Digest", "동일 입력 3회 동일 Lock", "100%", "100%", "Source·Result·Lock 모두 동일"],
            ["P95 정책지연", "Gateway 추가지연", "≤ 100ms", "≤ 50ms", "표준 부하 프로파일"],
            ["감사 불변성", "UPDATE/DELETE/권한우회 차단", "100%", "100%", "DB 직접 적대시험"],
            ["실증", "고객 PoC", "1곳", "2곳 이상", "확인서·운영로그"],
        ],
        [2.8, 5.1, 2.0, 2.0, 4.1],
    )
    add_gate_box(
        doc,
        "검증 독립성 Gate",
        [
            "개발자가 만든 PASS는 내부 검증으로만 집계한다.",
            "외부 OTester는 봉인 Source·Fixture·실행환경을 재실행하고 Receipt를 별도 키로 서명한다.",
            "OAaudit는 실행자·키·환경·Digest 계보와 불일치 처리를 검토한다.",
            "두 독립 Receipt가 없으면 FinalLock·Production GO·Commercial GO를 발급하지 않는다.",
        ],
        "FCE8E8",
    )

    page_break(doc)
    add_heading(doc, "6. 연구개발비 시나리오")
    add_para(
        doc,
        "2026 공고의 AX혁신기업창의기술개발 최대 지원규모 6.475억원을 상한 시나리오로 사용한다. "
        "아래는 제출 전 내부배분안이며, 2027 공고의 정부지원비율·민간부담금·비목 규정에 따라 반드시 재작성한다.",
    )
    add_table(
        doc,
        ["비목", "1차년도(억원)", "2차년도(억원)", "합계(억원)", "사용 근거"],
        [
            ["인건비", "1.25", "1.55", "2.80", "정책·보안·백엔드·QA 핵심인력"],
            ["연구장비·클라우드", "0.45", "0.35", "0.80", "격리 Runner, 부하·보안시험"],
            ["위탁·독립검증", "0.35", "0.55", "0.90", "OTester/OAudit·침투·성능 검증"],
            ["PoC·데이터", "0.40", "0.65", "1.05", "수요기업 연동·현장실증"],
            ["IP·인증·사업화", "0.20", "0.35", "0.55", "특허·보안/품질·조달 준비"],
            ["간접·기타", "0.135", "0.265", "0.40", "공고상 허용범위 내 조정"],
            ["합계", "2.785", "3.715", "6.50", "2026 상한과 근사한 계획값 — 2027 재산정 필수"],
        ],
        [3.0, 2.6, 2.6, 2.5, 5.3],
    )
    add_para(
        doc,
        "주의: 위 합계는 사전 기획 편의를 위한 6.50억원 시나리오이며 2026 공고 최대 6.475억원을 0.025억원 초과한다. "
        "제출본에서는 상한·부가세·민간부담금·현물 규정에 맞춰 반드시 감액·재분류한다.",
        bold=True,
        color=RED,
        size=9.2,
    )

    page_break(doc)
    add_heading(doc, "7. 사업화·매출 전환")
    add_table(
        doc,
        ["상품", "과금단위", "초기 고객가치", "증적"],
        [
            ["ONGuard Gateway", "연간 구독 + 사용자/호출량", "외부 AI 반출 전 차단·마스킹", "정책판정·Receipt·감사로그"],
            ["ONSure TEVV Pack", "검증 프로젝트/연간 회귀", "우회·Mutation·재현성 검증", "Fixture·Digest·독립 Receipt"],
            ["Enterprise Policy Center", "테넌트/정책팩/지원등급", "조직별 정책·승인·보고", "정책 버전·배포·감사"],
            ["PoC·전환 서비스", "고정 프로젝트", "기존 AI·SI 환경 연결", "PoC KPI·운영전환 체크리스트"],
        ],
        [3.5, 3.4, 5.5, 3.6],
    )
    add_heading(doc, "7.1 3개년 시나리오 산식", 2)
    add_para(
        doc,
        "매출은 고객 수 × 연간 계약단가 + PoC 수 × 프로젝트 단가로 산정한다. 고객 수·단가·전환율은 현재 확정 자료가 "
        "없으므로 본 사전작성본에는 숫자를 고정하지 않는다. 제출 전 LOI·견적·파이프라인으로 하·기준·상 시나리오를 입력한다.",
    )

    page_break(doc)
    add_heading(doc, "8. 위험관리와 제출 전 필수확인")
    add_table(
        doc,
        ["위험", "영향", "대응", "Owner/Gate"],
        [
            ["295규칙 과장", "평가 신뢰 상실", "구현·부분·비적용을 코드/Fixture/Receipt로 분리", "CTO / 규칙 Lock"],
            ["독립성 미충족", "최종검증 불인정", "외부기관 계약·키·환경·승인권 분리", "대표 / 독립 Receipt"],
            ["컨소시엄 미구성", "신청 불가", "수요기업·공동기업 역할/현물/데이터 합의", "사업PM / 협약서"],
            ["재무·신용 부적격", "융자·협약 제한", "체납·자본잠식·부채·보증한도 사전조회", "CFO / 증명서"],
            ["공고 변경", "예산·기간 불일치", "2027 공고일 즉시 적격성·비목·양식 재검토", "PM / 공고대조표"],
        ],
        [3.2, 3.5, 6.4, 3.3],
    )
    add_gate_box(
        doc,
        "제출 전 확보할 증빙",
        [
            "법인등기부등본, 사업자등록증, 중소기업확인서, 기업부설연구소 인정서",
            "최근 3개년 재무제표·부가세과세표준·국세/지방세 완납증명",
            "대표·연구책임자 국가연구자번호, 참여인력 이력·4대보험",
            "기존 대출·보증·정부과제·제재·중복성 내역",
            "특허/출원/저작권/소스 권리관계와 ONGuard·ONSure 사용권",
            "공동기업 참여확약서, 수요기업 LOI, PoC 데이터·보안 합의",
        ],
        "FCE8E8",
    )
    add_para(
        doc,
        "본 문서는 2026년 7월 25일 기준 사전작성본이다. 2027 공고가 발표되면 공고문·양식·평가지표를 기준으로 "
        "적격성·예산·컨소시엄·KPI를 다시 잠그고, 그 전에는 신청 완료본으로 사용하지 않는다.",
        bold=True,
        color=GRAY,
        size=9,
    )
    return save(doc, "ONGuard_2027_AX혁신기업_연구개발계획서_사전작성본.docx")


def build_kosmes_plan() -> Path:
    doc = Document()
    configure_document(doc, "ONGuard 개발기술사업화 계획")
    add_title_page(
        doc,
        "주식회사 케이엔엘소프트",
        "ONGuard 사업화 브리지",
        "개발기술사업화자금 사전 사업계획",
        "2026 중진공 정책자금 — 자격·상환성 확인 전 사전작성본",
        [
            ("신청기업", "주식회사 케이엔엘소프트"),
            ("기술", "AI 반출통제·검증 증적 플랫폼"),
            ("자금목적", "상용화 개발·PoC·시장진입"),
            ("설립", "2014년 — 창업연한 제한 사업 제외"),
        ],
        [
            ("신청금액", "제출 전 자금소요·한도·담보/신용 평가로 확정"),
            ("상환재원", "구독·PoC·Enterprise 계약 — 계약증빙 필요"),
            ("기술요건", "특허·정부R&D·인증 등 대상기술 요건 확인 필요"),
            ("현재 판정", "PRE-APPLICATION / EVIDENCE REQUIRED"),
        ],
    )

    add_heading(doc, "1. 신청 목적")
    add_para(
        doc,
        "ONGuard의 본개발과 ONSure 검증하네스에서 확보한 기술을 고객 PoC가 가능한 상용 패키지로 전환한다. "
        "정책자금은 연구 아이디어 자체가 아니라 제품화·실증·시장진입에 사용하며, 융자이므로 계약 파이프라인과 현금흐름을 "
        "근거로 상환 가능성을 먼저 입증한다.",
    )
    add_table(
        doc,
        ["사업화 병목", "자금 투입", "6–12개월 산출물"],
        [
            ["운영형 서명·감사 미완료", "키관리·PostgreSQL·보존정책", "운영 Receipt·Append-only 검증"],
            ["실제 네트워크 격리 미완료", "격리 Runner·클라우드 시험환경", "Egress 차단 증적·배포패키지"],
            ["고객 실증 부족", "연동개발·PoC·기술지원", "유상/전환형 PoC 2건 목표"],
            ["상용 운영도구 부족", "정책센터·관제·리포트", "관리자 기능·감사보고서"],
        ],
        [4.0, 5.3, 6.7],
    )

    page_break(doc)
    add_heading(doc, "2. 대상기술·신청자격 Gate")
    add_table(
        doc,
        ["검토항목", "현재 근거", "판정", "제출 전 조치"],
        [
            ["중소기업", "회사 홈페이지·외부 기업정보", "미확정", "유효 중소기업확인서"],
            ["대상 개발기술", "ONGuard/ONSure 코드·문서·검증결과", "조건부", "특허/출원·정부R&D·인증 등 세부요건 대조"],
            ["사업화 시점", "2026 제품 본개발·병합 이력", "조건부", "개발완료일·제품화기간 증빙"],
            ["세금·제재", "자료 없음", "미확정", "국세·지방세 완납, 제재·휴폐업 확인"],
            ["재무·신용", "자료 없음", "미확정", "3개년 재무·부채·보증·신용·한도 조회"],
            ["중복지원", "자료 없음", "미확정", "기존 정책자금·보증·정부과제 전수대조"],
        ],
        [3.4, 5.2, 2.2, 5.2],
    )
    add_gate_box(
        doc,
        "즉시 중단 조건",
        [
            "대상기술 요건을 증명할 특허·인증·R&D 성과가 없거나 인정기간을 벗어남",
            "세금 체납·휴폐업·융자제한·한도 부족·중복지원 등 제한사유 확인",
            "상환재원을 입증할 계약·LOI·파이프라인이 없고 현금흐름이 감당하지 못함",
        ],
        "FCE8E8",
    )

    page_break(doc)
    add_heading(doc, "3. 자금소요와 집행 Gate")
    add_para(
        doc,
        "금액은 공식 상담과 기업평가 전에는 고정하지 않는다. 아래는 총 3억원 내부 시나리오이며 실제 신청금액·시설/운전 "
        "구분·융자기간·금리는 2026 정책자금 세부공고와 중진공 평가 결과로 다시 확정한다.",
    )
    add_table(
        doc,
        ["용도", "시나리오(백만원)", "선행증빙", "집행 Gate"],
        [
            ["상용개발 인건비", "120", "인력계획·급여대장·4대보험", "월별 Milestone 승인"],
            ["격리·PostgreSQL·보안 인프라", "55", "견적·아키텍처·보안시험계획", "성능/격리 시험 통과"],
            ["고객 PoC·연동", "60", "LOI·SOW·고객부담·데이터합의", "PoC 착수 승인"],
            ["독립검증·인증·IP", "35", "검증기관 견적·특허전략", "독립성 계약 확인"],
            ["판매·조달·파트너 전환", "20", "채널계획·견적·전환 KPI", "유효 리드·계약 단계"],
            ["운전자금 예비", "10", "월별 현금흐름", "DSCR·잔액 하한"],
            ["합계", "300", "기업평가 전 내부안", "공식 한도 내 재산정"],
        ],
        [4.2, 3.0, 5.3, 3.5],
    )

    page_break(doc)
    add_heading(doc, "4. 매출·상환 시나리오 입력표")
    add_table(
        doc,
        ["항목", "하방", "기준", "상방", "근거/입력책임"],
        [
            ["유상 PoC 수", "[입력]", "[입력]", "[입력]", "영업 파이프라인 / 사업책임자"],
            ["PoC 평균단가", "[입력]", "[입력]", "[입력]", "견적·비교계약 / 사업책임자"],
            ["연간 구독 고객", "[입력]", "[입력]", "[입력]", "LOI·전환율 / 영업"],
            ["연간 구독 단가", "[입력]", "[입력]", "[입력]", "가격표·원가 / CFO"],
            ["월 고정비", "[입력]", "[입력]", "[입력]", "급여·클라우드·임차 / CFO"],
            ["원리금 상환", "[입력]", "[입력]", "[입력]", "심사조건 / CFO"],
            ["DSCR", "자동산식 필요", "자동산식 필요", "자동산식 필요", "영업현금흐름 ÷ 원리금"],
        ],
        [4.0, 2.6, 2.6, 2.6, 4.2],
    )
    add_para(
        doc,
        "승인 기준 제안: 하방 시나리오에서도 12개월 현금잔액이 0 미만이 되지 않고, 심사기관이 요구하는 상환지표를 충족할 때만 "
        "신청금액을 확정한다. 매출 숫자를 채우지 않은 상태에서는 신청서가 아니라 준비본이다.",
        bold=True,
        color=RED,
        size=9.3,
    )

    page_break(doc)
    add_heading(doc, "5. 90일 실행계획")
    add_table(
        doc,
        ["기한", "작업", "완료증적"],
        [
            ["D+7", "디지털지점 상담·대상기술 세부요건 확인", "상담기록·공고 체크리스트"],
            ["D+14", "법인·세무·재무·부채·보증·정부과제 자료 수집", "자격증적 폴더 100%"],
            ["D+21", "특허/출원/저작권·개발완료일·제품화 증명 정리", "기술권리 매트릭스"],
            ["D+30", "PoC LOI/SOW 1건 이상 및 견적 확보", "서명 LOI·견적"],
            ["D+45", "3개 시나리오 현금흐름·상환표", "CFO 승인 모델"],
            ["D+60", "정책자금 신청 또는 HOLD 결정", "접수증 또는 근거 있는 HOLD"],
            ["D+90", "상용화 1차 Milestone·자금집행 통제", "CI·시험·지출증빙"],
        ],
        [2.2, 7.5, 5.7],
    )
    return save(doc, "ONGuard_2026_개발기술사업화자금_사업계획서_사전작성본.docx")


def build_evidence_checklist() -> Path:
    doc = Document()
    configure_document(doc, "정부지원 자격·증적 체크리스트")
    add_title_page(
        doc,
        "주식회사 케이엔엘소프트",
        "정부지원 자격·증적 체크리스트",
        "확인된 사실과 미확인 자료를 분리하는 제출 Gate",
        "2026-07-25 기준 | AX R&D + 개발기술사업화자금 공통",
        [
            ("공식 확인", "2014년 설립, 2016년 벤처·기업부설연구소 이력"),
            ("기술 확인", "ONGuard·ONSure main 병합 및 자체 회귀"),
            ("연한 판정", "창업 3·7·10년 제한 사업 제외"),
            ("문서상태", "PRE-APPLICATION / NOT SUBMITTABLE"),
        ],
        [
            ("법인·재무", "미수집"),
            ("신용·부채·보증", "미수집"),
            ("IP·정부과제", "미수집"),
            ("외부 독립검증", "NOT_RUN"),
        ],
    )

    add_heading(doc, "1. 기업 기본자격")
    add_table(
        doc,
        ["증적", "상태", "유효기준", "파일/발급처", "Owner"],
        [
            ["사업자등록증", "미수집", "현재 정보", "홈택스/회사", "경영지원"],
            ["법인등기부등본", "미수집", "제출일 기준 최신", "인터넷등기소", "경영지원"],
            ["중소기업확인서", "미수집", "접수기간 유효", "중소기업현황정보시스템", "경영지원"],
            ["기업부설연구소 인정서", "이력만 확인", "현재 유효", "KOITA", "연구책임자"],
            ["벤처기업확인서", "2016 이력", "현재 유효 여부", "벤처확인종합관리", "경영지원"],
            ["주주·관계기업 현황", "미수집", "최신", "주주명부·관계기업 자료", "대표/CFO"],
        ],
        [3.3, 2.4, 3.5, 4.2, 2.6],
    )

    add_heading(doc, "2. 재무·신용·제한사유")
    add_table(
        doc,
        ["증적", "상태", "확인할 판단", "차단조건"],
        [
            ["최근 3개년 재무제표", "미수집", "매출·영업현금·자본잠식", "심사 제한/상환불가"],
            ["부가세과세표준증명", "미수집", "신고매출 일치", "자료 불일치"],
            ["국세·지방세 완납", "미수집", "체납 없음", "체납"],
            ["대출·보증·담보·한도", "미수집", "추가 차입여력", "한도 부족"],
            ["신용정보·연체", "미수집", "융자제한 없음", "연체·제한"],
            ["정부과제·정책자금", "미수집", "중복·제재·환수 없음", "중복/제재"],
        ],
        [4.0, 2.4, 5.0, 4.6],
    )

    page_break(doc)
    add_heading(doc, "3. 기술·권리·검증 증적")
    add_table(
        doc,
        ["증적", "현재 상태", "완료 정의", "제출 Gate"],
        [
            ["ONGuard Source Lock", "main 병합", "지원서 기준 SHA·SBOM·라이선스", "해시 불일치 시 중단"],
            ["ONSure 하네스", "162/162 자체 PASS", "동일 Source/Result/Lock 3회", "재현 불가 시 HOLD"],
            ["295 규칙", "카탈로그 295, 구현상태 NOT_IMPLEMENTED", "P0 코드+Fixture+Receipt", "문서 주장 금지"],
            ["서명 Receipt", "해시 무결성", "키등록·회전·폐기·재생방지", "미서명은 내부 증적"],
            ["Append-only 감사", "앱 Insert", "DB UPDATE/DELETE 차단", "DB 직접시험 필수"],
            ["외부 OTester/OAudit", "NOT_RUN", "독립 키·환경·Receipt", "없으면 FinalLock 금지"],
            ["IP 권리", "미수집", "특허/출원/저작권/기여자 정리", "권리 불명확 시 제출 금지"],
        ],
        [3.7, 3.5, 5.5, 3.3],
    )

    add_heading(doc, "4. 지원사업별 추가증적")
    add_table(
        doc,
        ["사업", "필수 추가자료", "상태", "다음 행동"],
        [
            ["2027 AX혁신기업", "공동기업·수요기업, 연구책임자, 민간부담, 21개월 WBS", "미수집", "컨소시엄 후보 3곳 접촉"],
            ["개발기술사업화자금", "대상기술 증명, 자금소요, 견적, 현금흐름·상환", "미수집", "중진공 사전상담"],
            ["공통", "회사 직인·위임·개인정보·IRIS/디지털지점 계정", "미확인", "제출권한 점검"],
        ],
        [3.5, 7.1, 2.6, 3.8],
    )

    page_break(doc)
    add_heading(doc, "5. 제외 프로그램 판정")
    add_table(
        doc,
        ["프로그램", "통상 업력조건", "회사 기준", "판정"],
        [
            ["Pre-TIPS", "초기창업 3년 이내 등", "2014년 설립", "연한 부적합"],
            ["창업성장 디딤돌", "창업 7년 이내 등", "2014년 설립", "연한 부적합"],
            ["창업도약패키지 일반형", "창업 3–7년", "2014년 설립", "연한 부적합"],
            ["TIPS 일반/신산업", "7년/신산업 10년 이내", "2014년 설립", "연한 부적합"],
        ],
        [4.2, 4.3, 3.5, 4.0],
    )
    add_para(
        doc,
        "정책·공고가 변경될 수 있으므로 접수 시점 공식 공고로 다시 확인한다. 다만 현재 설립연도 기준으로 위 프로그램을 "
        "주력 후보로 두면 준비비용만 발생할 가능성이 높다.",
        color=GRAY,
        size=9.2,
    )

    add_heading(doc, "6. 최종 승인란")
    add_table(
        doc,
        ["Gate", "승인자", "날짜", "판정", "근거"],
        [
            ["기업자격", "대표/CFO", "", "HOLD", ""],
            ["기술·IP", "CTO/법무", "", "HOLD", ""],
            ["재무·상환", "CFO", "", "HOLD", ""],
            ["컨소시엄/고객", "사업책임자", "", "HOLD", ""],
            ["독립검증", "OTester/OAudit", "", "NOT_RUN", ""],
            ["최종 제출", "대표", "", "NOT AUTHORIZED", ""],
        ],
        [3.7, 3.1, 2.5, 3.2, 4.5],
    )
    return save(doc, "ONGuard_정부지원_자격증적체크리스트_20260725.docx")


def main() -> int:
    outputs = [build_ax_proposal(), build_kosmes_plan(), build_evidence_checklist()]
    for path in outputs:
        print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

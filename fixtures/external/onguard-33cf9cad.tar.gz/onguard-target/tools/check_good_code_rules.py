from __future__ import annotations

import ast
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class Finding:
    rule_id: str
    path: str
    line: int
    message: str


class Detector(ast.NodeVisitor):
    def __init__(self, path: Path) -> None:
        self.path = path
        self.findings: list[Finding] = []

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        broad = node.type is None or (
            isinstance(node.type, ast.Name) and node.type.id in {"Exception", "BaseException"}
        )
        if broad:
            terminal = node.body[-1] if node.body else None
            unsafe_return = isinstance(terminal, ast.Return) and (
                terminal.value is None
                or isinstance(terminal.value, ast.Constant) and terminal.value.value in {None, 0, True}
                or isinstance(terminal.value, (ast.List, ast.Tuple)) and not terminal.value.elts
                or isinstance(terminal.value, ast.Dict) and not terminal.value.keys
            )
            if unsafe_return:
                self.findings.append(
                    Finding("GC-BAN-005", str(self.path), node.lineno, "broad exception returns a success-like default")
                )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr in {"get", "post", "put", "delete", "request"}
            and self._looks_like_http_call(node)
            and not any(keyword.arg == "timeout" for keyword in node.keywords)
        ):
            self.findings.append(
                Finding("GC-BAN-002", str(self.path), node.lineno, "external call has no explicit timeout")
            )
        self.generic_visit(node)

    @staticmethod
    def _looks_like_http_call(node: ast.Call) -> bool:
        # dict.get(key, default) 등 평범한 메서드 호출을 HTTP 클라이언트 호출로
        # 오인하지 않도록, 첫 인자가 http(s):// 리터럴 URL일 때만 대상으로 본다.
        if not node.args:
            return False
        first = node.args[0]
        return (
            isinstance(first, ast.Constant)
            and isinstance(first.value, str)
            and first.value.startswith(("http://", "https://"))
        )


def scan(root: Path) -> list[Finding]:
    findings: list[Finding] = []
    for path in sorted(root.rglob("*.py")):
        if any(part in {".git", ".venv", "__pycache__"} for part in path.parts):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            findings.append(Finding("GC-QA-01", str(path), exc.lineno or 0, "source cannot be parsed"))
            continue
        detector = Detector(path)
        detector.visit(tree)
        findings.extend(detector.findings)
    return findings


def main() -> int:
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "src")
    findings = scan(target)
    print(json.dumps([asdict(item) for item in findings], ensure_ascii=False, indent=2))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())

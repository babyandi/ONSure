from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path


REQUIRED = {
    "rule_id",
    "parent_quality",
    "domain",
    "title",
    "applicability",
    "severity",
    "normative_statement",
    "detector",
    "fixtures",
    "harness",
    "oracle",
    "evidence",
    "implementation_status",
}
FIXTURES = {"positive", "negative", "boundary", "evasion", "mutation", "version-variant"}
STATUSES = {"NOT_IMPLEMENTED", "NOT_RUN", "PARTIAL", "COMPLIANT", "N/A"}
AUTHORITY_PATTERN = re.compile(r"\bGC-[A-Z0-9]+-\d{3}\b")
DEFAULT_AUTHORITY = Path("docs/spec/ONGuard_좋은코드_검증체계_실행가능_코딩표준.md")


def extract_authority_rule_ids(text: str) -> set[str]:
    """Return executable Rule IDs; GC-QA-01..12 are parent quality attributes."""
    return set(AUTHORITY_PATTERN.findall(text))


def validate_authority_alignment(catalog: dict[str, object], authority_text: str) -> list[str]:
    rules = catalog.get("rules", [])
    catalog_ids = {
        value.get("rule_id")
        for value in rules
        if isinstance(value, dict) and isinstance(value.get("rule_id"), str)
    }
    authority_ids = extract_authority_rule_ids(authority_text)
    errors: list[str] = []
    missing = sorted(authority_ids - catalog_ids)
    extra = sorted(catalog_ids - authority_ids)
    if missing:
        errors.append(f"catalog missing authority rules: {','.join(missing)}")
    if extra:
        errors.append(f"catalog contains non-authority rules: {','.join(extra)}")
    return errors



def canonical_digest(value: object) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def validate(catalog: dict[str, object]) -> list[str]:
    errors: list[str] = []
    rules = catalog.get("rules")
    if not isinstance(rules, list) or not rules:
        return ["catalog.rules must be a non-empty list"]
    seen: set[str] = set()
    for index, value in enumerate(rules):
        label = f"rules[{index}]"
        if not isinstance(value, dict):
            errors.append(f"{label}: must be an object")
            continue
        missing = sorted(REQUIRED - value.keys())
        if missing:
            errors.append(f"{label}: missing {','.join(missing)}")
        rule_id = value.get("rule_id")
        if not isinstance(rule_id, str) or not rule_id.startswith("GC-"):
            errors.append(f"{label}: invalid rule_id")
        elif rule_id in seen:
            errors.append(f"{label}: duplicate rule_id {rule_id}")
        else:
            seen.add(rule_id)
        if value.get("severity") not in {"CRITICAL", "MAJOR", "MINOR"}:
            errors.append(f"{label}: invalid severity")
        if value.get("implementation_status") not in STATUSES:
            errors.append(f"{label}: invalid implementation_status")
        fixtures = value.get("fixtures")
        if not isinstance(fixtures, list) or not FIXTURES.issubset(fixtures):
            errors.append(f"{label}: incomplete fixture classes")
        for field in ("detector", "harness", "oracle"):
            if not isinstance(value.get(field), str) or not value[field].strip():
                errors.append(f"{label}: empty {field}")
        evidence = value.get("evidence")
        if not isinstance(evidence, list) or "raw_result_hash" not in evidence or "decision" not in evidence:
            errors.append(f"{label}: incomplete evidence")
    return errors


def load(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("catalog root must be an object")
    return value


def main() -> int:
    path = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/spec/good_code_rule_traceability.json")
    try:
        catalog = load(path)
        errors = validate(catalog)
        authority = DEFAULT_AUTHORITY if path == Path("docs/spec/good_code_rule_traceability.json") else path.parent / DEFAULT_AUTHORITY.name
        authority_text = authority.read_text(encoding="utf-8")
        errors.extend(validate_authority_alignment(catalog, authority_text))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        errors = [f"catalog unreadable: {exc}"]
        catalog = {}
    result = {
        "decision": "PASS" if not errors else "FAIL",
        "catalog": str(path),
        "catalog_digest": canonical_digest(catalog),
        "rule_count": len(catalog.get("rules", [])) if isinstance(catalog, dict) else 0,
        "errors": errors,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())

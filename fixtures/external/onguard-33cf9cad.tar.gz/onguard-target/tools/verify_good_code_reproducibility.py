from __future__ import annotations

import json
import sys
from pathlib import Path


def stable_projection(payload: dict[str, object]) -> dict[str, object]:
    runs = payload.get("runs", [])
    return {
        "receipt_schema": payload.get("receipt_schema"),
        "tested_head": payload.get("tested_head"),
        "catalog_digest": payload.get("catalog_digest"),
        "detector_digest": payload.get("detector_digest"),
        "trace_validator_digest": payload.get("trace_validator_digest"),
        "fixture_digest": payload.get("fixture_digest"),
        "slice_decision": payload.get("slice_decision"),
        "overall_decision": payload.get("overall_decision"),
        "overall_reason": payload.get("overall_reason"),
        "runs": [
            {
                "iteration": run.get("iteration"),
                "command": run.get("command"),
                "exit_code": run.get("exit_code"),
                "raw_result_hash": run.get("raw_result_hash"),
                "decision": run.get("decision"),
            }
            for run in runs
        ],
    }


def main() -> int:
    if len(sys.argv) != 3:
        raise SystemExit("usage: verify_good_code_reproducibility.py RECEIPT_1 RECEIPT_2")
    first = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    second = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    if stable_projection(first) != stable_projection(second):
        print("NON_REPRODUCIBLE")
        return 1
    print("REPRODUCIBLE_STABLE_PROJECTION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

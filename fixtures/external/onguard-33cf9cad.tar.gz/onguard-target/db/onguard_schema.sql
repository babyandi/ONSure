-- ONGuard MVP 물리 스키마
-- 운영 목표는 PostgreSQL 호환 설계이며, Python MVP는 동등 계약의 SQLite 스키마로 검증한다.

-- 정책 버전 테이블: 한 시점에 ACTIVE 정책 하나를 기준선으로 사용한다.
CREATE TABLE ong_policy_version (
    policy_version VARCHAR(64) PRIMARY KEY,
    status VARCHAR(16) NOT NULL CHECK (status IN ('DRAFT', 'ACTIVE', 'RETIRED')),
    description TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 정책 Rule 테이블: 버전별 Rule을 보관하고 우선순위 순서로 판정한다.
CREATE TABLE ong_policy_rule (
    rule_id VARCHAR(96) NOT NULL,
    policy_version VARCHAR(64) NOT NULL REFERENCES ong_policy_version(policy_version),
    priority INTEGER NOT NULL,
    channel VARCHAR(64) NOT NULL,
    levels_json JSONB NOT NULL,
    effect VARCHAR(32) NOT NULL,
    reason TEXT NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    -- 비어 있는 '[]'는 모든 사용자/목적에 적용되는 wildcard 조건이다.
    actor_ids_json JSONB NOT NULL DEFAULT '[]',
    purpose_keywords_json JSONB NOT NULL DEFAULT '[]',
    targets_json JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (rule_id, policy_version)
);

-- 활성 정책/채널별 Rule 조회가 자주 발생하므로 우선순위 정렬 인덱스를 둔다.
CREATE INDEX ix_policy_rule_version_priority
    ON ong_policy_rule(policy_version, active, channel, priority DESC, rule_id);

-- 외부 반출 요청 테이블: 원문 대신 content_hash만 저장한다.
CREATE TABLE ong_egress_request (
    request_hash CHAR(64) PRIMARY KEY,
    request_id VARCHAR(96) NOT NULL,
    actor_id VARCHAR(128) NOT NULL,
    purpose VARCHAR(256) NOT NULL,
    target VARCHAR(128) NOT NULL,
    channel VARCHAR(64) NOT NULL,
    content_hash CHAR(64) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 사용자별 요청 이력 조회와 감사 추적을 위한 인덱스다.
CREATE INDEX ix_egress_request_actor_created
    ON ong_egress_request(actor_id, created_at DESC);

-- 정책판정 테이블: 요청, 정책, 분류, 사유를 판정 해시 기준으로 보관한다.
CREATE TABLE ong_policy_decision (
    decision_hash CHAR(64) PRIMARY KEY,
    request_hash CHAR(64) NOT NULL REFERENCES ong_egress_request(request_hash),
    policy_version VARCHAR(64) NOT NULL,
    policy_hash CHAR(64) NOT NULL,
    decision VARCHAR(32) NOT NULL,
    classification_level VARCHAR(8) NOT NULL,
    signals_json JSONB NOT NULL,
    reasons_json JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 정책 버전별 판정 이력 조회를 위한 인덱스다.
CREATE INDEX ix_policy_decision_policy_created
    ON ong_policy_decision(policy_version, created_at DESC);

-- 차단/허용/검토 대상과 정보등급별 통계 조회를 위한 인덱스다.
CREATE INDEX ix_policy_decision_decision_level
    ON ong_policy_decision(decision, classification_level);

-- Receipt 테이블: 사후 검증 가능한 최종 감사 증적 payload를 보관한다.
CREATE TABLE ong_receipt (
    receipt_id VARCHAR(96) PRIMARY KEY,
    decision_hash CHAR(64) NOT NULL UNIQUE REFERENCES ong_policy_decision(decision_hash),
    request_hash CHAR(64) NOT NULL,
    policy_hash CHAR(64) NOT NULL,
    policy_version VARCHAR(64) NOT NULL,
    receipt_payload_json JSONB NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 요청/정책/판정 해시 기반의 무결성 추적을 위한 인덱스다.
CREATE INDEX ix_receipt_hashes
    ON ong_receipt(request_hash, policy_hash, decision_hash);

-- 감사 이벤트는 동일 요청·동일 판정이 반복되어도 매 호출을 별도 행으로 보존한다.
CREATE TABLE ong_audit_event (
    event_id VARCHAR(96) PRIMARY KEY,
    decision_hash CHAR(64) NOT NULL REFERENCES ong_policy_decision(decision_hash),
    receipt_id VARCHAR(96) NOT NULL REFERENCES ong_receipt(receipt_id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_audit_event_created
    ON ong_audit_event(created_at, event_id);

-- 앱 계층을 우회한 직접 UPDATE/DELETE도 차단하는 DB 수준 Append-only 경계다.
CREATE OR REPLACE FUNCTION onguard_reject_immutable_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    RAISE EXCEPTION 'ONGUARD_APPEND_ONLY_%_DENIED', TG_OP
        USING ERRCODE = '55000';
END;
$$;

CREATE TRIGGER trg_egress_request_append_only
BEFORE UPDATE OR DELETE ON ong_egress_request
FOR EACH ROW EXECUTE FUNCTION onguard_reject_immutable_mutation();

CREATE TRIGGER trg_policy_decision_append_only
BEFORE UPDATE OR DELETE ON ong_policy_decision
FOR EACH ROW EXECUTE FUNCTION onguard_reject_immutable_mutation();

CREATE TRIGGER trg_receipt_append_only
BEFORE UPDATE OR DELETE ON ong_receipt
FOR EACH ROW EXECUTE FUNCTION onguard_reject_immutable_mutation();

CREATE TRIGGER trg_audit_event_append_only
BEFORE UPDATE OR DELETE ON ong_audit_event
FOR EACH ROW EXECUTE FUNCTION onguard_reject_immutable_mutation();

REVOKE UPDATE, DELETE, TRUNCATE
ON ong_egress_request, ong_policy_decision, ong_receipt, ong_audit_event
FROM PUBLIC;

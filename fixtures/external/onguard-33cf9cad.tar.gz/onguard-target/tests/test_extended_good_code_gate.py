from __future__ import annotations

import copy
import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class ExtendedDetectorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.detector = load_module("extended_detector", ROOT / "tools/check_extended_good_code_rules.py")
        cls.trace = load_module("trace_validator", ROOT / "tools/validate_rule_traceability.py")
        cls.fixture = ROOT / "tests/fixtures/good_code_extended"
        cls.catalog_path = ROOT / "docs/spec/good_code_rule_traceability.json"
        cls.catalog_raw = cls.catalog_path.read_text(encoding="utf-8")
        cls.catalog = json.loads(cls.catalog_raw)
        cls.authority_text = (
            ROOT / "docs/spec/ONGuard_좋은코드_검증체계_실행가능_코딩표준.md"
        ).read_text(encoding="utf-8")

    def test_positive_fixture_is_clean(self):
        self.assertEqual([], self.detector.scan(self.fixture / "positive.py"))

    def test_negative_fixture_triggers_sql_http_and_secret(self):
        ids = {item.rule_id for item in self.detector.scan(self.fixture / "negative.py")}
        self.assertEqual({"GC-HTTP-001", "GC-SEC-012", "GC-SQL-002"}, ids)

    def test_evasion_fixture_triggers_sql_and_exception_rules(self):
        ids = {item.rule_id for item in self.detector.scan(self.fixture / "evasion.py")}
        self.assertEqual({"GC-BAN-005", "GC-SQL-002"}, ids)

    def test_rule_catalog_is_complete(self):
        self.assertEqual([], self.trace.validate(self.catalog))
        catalog_ids = {rule["rule_id"] for rule in self.catalog["rules"]}
        authority_ids = self.trace.extract_authority_rule_ids(self.authority_text)
        self.assertEqual(authority_ids, catalog_ids)
        self.assertEqual(295, len(catalog_ids))

    def test_catalog_has_no_tool_output_banner(self):
        self.assertFalse(self.catalog_raw.startswith("Warning: truncated output"))
        self.assertNotIn("Total output lines:", self.catalog_raw)

    def test_authority_rule_deletion_is_rejected(self):
        mutated = copy.deepcopy(self.catalog)
        mutated["rules"].pop()
        errors = self.trace.validate_authority_alignment(mutated, self.authority_text)
        self.assertTrue(any("catalog missing authority rules" in item for item in errors))

    def test_mutation_missing_field_is_rejected(self):
        mutated = copy.deepcopy(self.catalog)
        mutated["rules"][0].pop("oracle")
        self.assertTrue(any("missing oracle" in item for item in self.trace.validate(mutated)))

    def test_mutation_duplicate_rule_is_rejected(self):
        mutated = copy.deepcopy(self.catalog)
        mutated["rules"][1]["rule_id"] = mutated["rules"][0]["rule_id"]
        self.assertTrue(any("duplicate rule_id" in item for item in self.trace.validate(mutated)))

    def test_mutation_fixture_class_is_rejected(self):
        mutated = copy.deepcopy(self.catalog)
        mutated["rules"][0]["fixtures"].remove("evasion")
        self.assertTrue(any("incomplete fixture classes" in item for item in self.trace.validate(mutated)))


if __name__ == "__main__":
    unittest.main()

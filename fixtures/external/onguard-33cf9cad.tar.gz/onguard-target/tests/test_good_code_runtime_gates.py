import tempfile
import unittest
from pathlib import Path

from onguard.classification import classify_content
from onguard.exception_policy import ONGuardError, fail_closed
from onguard.messages import MessageCatalogError, render_message, validate_catalogs
from tools.check_good_code_rules import scan


class MessageAndExceptionContractTests(unittest.TestCase):
    def test_all_supported_catalogs_have_identical_contract(self):
        self.assertEqual(validate_catalogs(), ())

    def test_locale_rendering_and_safe_fallback(self):
        self.assertEqual(render_message("ONG-POL-001", locale="en"), "Fail-Closed because there is no active policy rule.")
        self.assertEqual(render_message("ONG-POL-001", locale="unsupported"), "활성 정책 Rule이 없어 Fail-Closed 처리한다.")

    def test_unknown_code_and_parameter_mismatch_fail_closed(self):
        with self.assertRaises(MessageCatalogError):
            render_message("UNKNOWN")
        with self.assertRaises(MessageCatalogError):
            render_message("ONG-REQ-001")

    def test_dependency_exception_is_not_returned_as_empty_success(self):
        with self.assertRaises(ONGuardError) as caught:
            fail_closed(lambda: (_ for _ in ()).throw(RuntimeError("secret internal detail")))
        self.assertEqual(caught.exception.failure.code, "ONG-POL-503")
        self.assertNotIn("secret internal detail", str(caught.exception))


class CanonicalizationTests(unittest.TestCase):
    def test_fullwidth_email_is_normalized_before_detection(self):
        result = classify_content("ｔｅｓｔ＠ｅｘａｍｐｌｅ．ｃｏｍ")
        self.assertEqual(result.level.value, "L3")
        self.assertIn("email-address", result.signals)


class DetectorMutationTests(unittest.TestCase):
    def _scan(self, source: str):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "fixture.py")
            path.write_text(source, encoding="utf-8")
            return scan(Path(directory))

    def test_detector_accepts_explicit_timeout_and_raising_exception(self):
        findings = self._scan(
            "def run(client):\n"
            "    try:\n"
            "        return client.get('https://example.test', timeout=3)\n"
            "    except ValueError:\n"
            "        raise\n"
        )
        self.assertEqual(findings, [])

    def test_detector_rejects_timeout_omission_and_exception_swallowing(self):
        findings = self._scan(
            "def run(client):\n"
            "    try:\n"
            "        return client.get('https://example.test')\n"
            "    except Exception:\n"
            "        return None\n"
        )
        self.assertEqual({item.rule_id for item in findings}, {"GC-BAN-002", "GC-BAN-005"})


if __name__ == "__main__":
    unittest.main()

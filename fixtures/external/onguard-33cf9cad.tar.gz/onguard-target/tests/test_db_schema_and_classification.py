import unittest

from onguard.classification import classify_content, mask_content
from onguard.db import SCHEMA_SQL, apply_schema, connect_database


class DbSchemaAndClassificationTests(unittest.TestCase):
    def test_db_schema_application_creates_core_tables(self):
        # 스키마 적용 후 정책, 요청, 판정, Receipt 핵심 테이블이 모두 존재해야 한다.
        connection = connect_database()
        apply_schema(connection)
        tables = {
            row["name"]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'ong_%'"
            ).fetchall()
        }

        self.assertIn("ong_policy_version", tables)
        self.assertIn("ong_policy_rule", tables)
        self.assertIn("ong_egress_request", tables)
        self.assertIn("ong_policy_decision", tables)
        self.assertIn("ong_receipt", tables)
        self.assertIn("ong_audit_event", tables)

    def test_classification_engine_detects_expanded_patterns(self):
        # 1차 본 개발에서 확장한 이메일/카드/토큰 탐지 규칙을 검증한다.
        self.assertEqual(classify_content("연락처는 test@example.com 입니다.").level.value, "L3")
        self.assertEqual(classify_content("카드번호 1234-5678-9012-3456").level.value, "L4")
        self.assertEqual(classify_content("Bearer abcdefghijklmnopqrstuvwxyz123456").level.value, "L4")

    def test_legacy_database_adds_target_scope_column(self):
        connection = connect_database()
        legacy_schema = SCHEMA_SQL.replace(
            "    targets_json TEXT NOT NULL DEFAULT '[]',\n",
            "",
        )
        connection.executescript(legacy_schema)

        apply_schema(connection)

        columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(ong_policy_rule)").fetchall()
        }
        self.assertIn("targets_json", columns)


    def test_mask_content_redacts_values_but_keeps_unrelated_text(self):
        masked = mask_content("연락처는 test@example.com 이고 전화는 010-1234-5678 입니다.")
        self.assertNotIn("test@example.com", masked)
        self.assertNotIn("010-1234-5678", masked)
        self.assertIn("[REDACTED:email-address]", masked)
        self.assertIn("[REDACTED:phone-number]", masked)
        self.assertIn("연락처는", masked)
        self.assertIn("입니다", masked)

    def test_mask_content_does_not_redact_topic_keywords(self):
        masked = mask_content("고객의 계좌 잔고와 주문 내역을 정리해줘.")
        self.assertNotIn("REDACTED", masked)
        self.assertIn("고객", masked)

    def test_mask_content_handles_empty_input(self):
        self.assertEqual(mask_content(""), "")


if __name__ == "__main__":
    unittest.main()

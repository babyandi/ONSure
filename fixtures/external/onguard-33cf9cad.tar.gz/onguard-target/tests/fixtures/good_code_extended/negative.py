import requests


password = "hardcoded-password"


def load(cursor, actor_id):
    cursor.execute(f"SELECT id FROM item WHERE actor_id = '{actor_id}'")
    return requests.get("https://example.invalid/health")

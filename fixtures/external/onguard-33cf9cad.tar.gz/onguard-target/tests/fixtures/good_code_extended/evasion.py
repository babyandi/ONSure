def unsafe(cursor, table_name, actor_id):
    query = "SELECT id FROM {}".format(table_name)
    cursor.execute(query % actor_id)


def swallowed():
    try:
        raise RuntimeError("fail")
    except Exception:
        return {}

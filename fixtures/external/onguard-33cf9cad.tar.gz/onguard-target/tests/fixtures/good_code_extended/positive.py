import requests


def load(cursor, actor_id):
    cursor.execute("SELECT id FROM item WHERE actor_id = ?", (actor_id,))
    return requests.get("https://example.invalid/health", timeout=3)

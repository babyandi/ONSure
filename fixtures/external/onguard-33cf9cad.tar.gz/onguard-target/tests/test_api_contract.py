import unittest

from onguard import (
    DecisionStatus,
    decide_egress,
    policy_rules,
    policy_versions,
    register_policy_rule,
    register_policy_version,
    reset_runtime,
)


class ApiContractTests(unittest.TestCase):
    def setUp(self):
        # 정책 등록 테스트가 기본 정책 테스트에 영향을 주지 않게 매번 초기화한다.
        reset_runtime()

    def test_decision_response_contract(self):
        # Egress Guard API는 판정, 등급, 사유, Receipt 핵심 해시를 항상 반환해야 한다.
        result = decide_egress(
            {
                "actor_id": "contract-user",
                "purpose": "계약 테스트",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 가능한 문장입니다.",
            }
        )

        self.assertIn("decision", result)
        self.assertIn("classification_level", result)
        self.assertIn("reasons", result)
        self.assertIn("receipt", result)
        self.assertIn("request_hash", result["receipt"])
        self.assertIn("policy_hash", result["receipt"])
        self.assertIn("decision_hash", result["receipt"])

    def test_policy_center_register_list_and_version_contract(self):
        # ACTIVE 버전과 Rule 등록 후 판정 API가 새 정책을 사용해야 한다.
        register_policy_version("2026.07.custom", status="ACTIVE", description="custom policy")
        registered = register_policy_rule(
            {
                "rule_id": "custom-l0-review",
                "version": "2026.07.custom",
                "priority": 100,
                "channel": "external_llm",
                "levels": ["L0"],
                "effect": "REVIEW_REQUIRED",
                "reason": "Custom MVP policy requires review for public content.",
                "targets": ["external-llm"],
            }
        )

        self.assertEqual(registered["rule_id"], "custom-l0-review")
        self.assertIn("2026.07.custom", [version["policy_version"] for version in policy_versions()])
        self.assertEqual(policy_rules()[0]["effect"], DecisionStatus.REVIEW_REQUIRED.value)

        result = decide_egress(
            {
                "actor_id": "contract-user",
                "purpose": "정책 버전 테스트",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 가능한 문장입니다.",
            }
        )
        self.assertEqual(result["decision"], DecisionStatus.REVIEW_REQUIRED.value)
        self.assertEqual(result["receipt"]["policy_version"], "2026.07.custom")

    def test_actor_scoped_rule_only_applies_to_named_actor(self):
        # actor_ids가 지정된 Rule은 해당 사용자에게만 적용되고, 다른 사용자는 wildcard Rule로 판정된다.
        register_policy_version("2026.07.actor-scope", status="ACTIVE", description="actor scoped policy")
        register_policy_rule(
            {
                "rule_id": "actor-blocked-deny",
                "version": "2026.07.actor-scope",
                "priority": 100,
                "channel": "external_llm",
                "levels": ["L0"],
                "effect": "DENY",
                "reason": "지정된 사용자는 공개 정보도 차단한다.",
                "actor_ids": ["actor-blocked"],
                "targets": ["external-llm"],
            }
        )
        register_policy_rule(
            {
                "rule_id": "default-l0-allow",
                "version": "2026.07.actor-scope",
                "priority": 10,
                "channel": "external_llm",
                "levels": ["L0"],
                "effect": "ALLOW",
                "reason": "공개 정보는 기본 허용한다.",
                "targets": ["external-llm"],
            }
        )

        blocked = decide_egress(
            {
                "actor_id": "actor-blocked",
                "purpose": "테스트",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 문장입니다.",
            }
        )
        other = decide_egress(
            {
                "actor_id": "actor-other",
                "purpose": "테스트",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 문장입니다.",
            }
        )

        self.assertEqual(blocked["decision"], DecisionStatus.DENY.value)
        self.assertEqual(other["decision"], DecisionStatus.ALLOW.value)
        self.assertIn("actor_ids", policy_rules()[0])

    def test_purpose_keyword_rule_requires_matching_purpose(self):
        # purpose_keywords가 지정된 Rule은 목적 문구에 키워드가 포함될 때만 적용된다.
        register_policy_version("2026.07.purpose-scope", status="ACTIVE", description="purpose scoped policy")
        register_policy_rule(
            {
                "rule_id": "audit-purpose-review",
                "version": "2026.07.purpose-scope",
                "priority": 100,
                "channel": "external_llm",
                "levels": ["L0"],
                "effect": "REVIEW_REQUIRED",
                "reason": "감사 목적 요청은 검토가 필요하다.",
                "purpose_keywords": ["감사"],
                "targets": ["external-llm"],
            }
        )
        register_policy_rule(
            {
                "rule_id": "default-l0-allow",
                "version": "2026.07.purpose-scope",
                "priority": 10,
                "channel": "external_llm",
                "levels": ["L0"],
                "effect": "ALLOW",
                "reason": "공개 정보는 기본 허용한다.",
                "targets": ["external-llm"],
            }
        )

        audit_purpose = decide_egress(
            {
                "actor_id": "contract-user",
                "purpose": "내부 감사 자료 요약",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 문장입니다.",
            }
        )
        other_purpose = decide_egress(
            {
                "actor_id": "contract-user",
                "purpose": "시장 자료 요약",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개 문장입니다.",
            }
        )

        self.assertEqual(audit_purpose["decision"], DecisionStatus.REVIEW_REQUIRED.value)
        self.assertEqual(other_purpose["decision"], DecisionStatus.ALLOW.value)


if __name__ == "__main__":
    unittest.main()

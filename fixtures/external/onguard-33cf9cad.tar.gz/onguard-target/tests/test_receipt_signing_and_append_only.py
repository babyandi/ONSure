from __future__ import annotations

from dataclasses import replace
import sqlite3
import unittest

from onguard import decide_egress, reset_runtime, verify_receipt
from onguard import api
from onguard.models import DecisionStatus, InformationLevel, Receipt
from onguard.receipt import SIGNATURE_ALGORITHM, verify_receipt_signature


class ReceiptSigningAndAppendOnlyTests(unittest.TestCase):
    def setUp(self) -> None:
        reset_runtime()

    @staticmethod
    def _decision() -> dict[str, object]:
        return decide_egress(
            {
                "actor_id": "signature-test-user",
                "purpose": "공개자료 요약",
                "target": "external-llm",
                "channel": "external_llm",
                "content": "공개된 기술자료를 요약한다.",
            }
        )

    def test_receipt_has_valid_ed25519_signature(self) -> None:
        result = self._decision()
        receipt = result["receipt"]
        self.assertEqual(receipt["signature_algorithm"], SIGNATURE_ALGORITHM)
        self.assertTrue(receipt["signing_key_id"])
        self.assertTrue(receipt["signature"])

        verified = verify_receipt(receipt["receipt_id"])
        self.assertTrue(verified["hash_valid"])
        self.assertTrue(verified["signature_valid"])
        self.assertTrue(verified["valid"])

    def test_bound_field_tampering_breaks_signature(self) -> None:
        result = self._decision()
        payload = result["receipt"]
        receipt = Receipt(
            receipt_id=payload["receipt_id"],
            request_hash=payload["request_hash"],
            policy_hash=payload["policy_hash"],
            decision_hash=payload["decision_hash"],
            policy_version=payload["policy_version"],
            actor_id=payload["actor_id"],
            target=payload["target"],
            decision=DecisionStatus(payload["decision"]),
            classification_level=InformationLevel(payload["classification_level"]),
            reasons=tuple(payload["reasons"]),
            egress_content_hash=payload["egress_content_hash"],
            signature_algorithm=payload["signature_algorithm"],
            signing_key_id=payload["signing_key_id"],
            signature=payload["signature"],
        )
        self.assertTrue(verify_receipt_signature(receipt))
        self.assertFalse(verify_receipt_signature(replace(receipt, actor_id="attacker")))
        self.assertFalse(verify_receipt_signature(replace(receipt, target="other-llm")))
        self.assertFalse(verify_receipt_signature(replace(receipt, policy_version="tampered")))

    def test_audit_lineage_tables_reject_update_and_delete(self) -> None:
        result = self._decision()
        receipt_id = result["receipt"]["receipt_id"]
        connection = api.AUDIT_CENTER.connection
        for statement, parameters in (
            ("UPDATE ong_receipt SET policy_version = 'tampered' WHERE receipt_id = ?", (receipt_id,)),
            ("DELETE FROM ong_receipt WHERE receipt_id = ?", (receipt_id,)),
            ("UPDATE ong_audit_event SET receipt_id = 'tampered'", ()),
            ("DELETE FROM ong_audit_event", ()),
        ):
            with self.assertRaisesRegex(sqlite3.IntegrityError, "ONGUARD_APPEND_ONLY"):
                connection.execute(statement, parameters)


if __name__ == "__main__":
    unittest.main()

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODE="${1:---core}"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
OUT="$ROOT/artifacts/manual-verification/$RUN_ID"
WORK="$(mktemp -d)"
COMPOSE_STARTED=false

cleanup() {
  if [[ "$COMPOSE_STARTED" == true ]]; then
    docker compose -f "$ROOT/.devcontainer/docker-compose.yml" down -v
  fi
  rm -rf "$WORK"
}
trap cleanup EXIT

case "$MODE" in
  --core|--full) ;;
  *)
    echo "usage: $0 [--core|--full]" >&2
    exit 64
    ;;
esac

mkdir -p "$OUT"
cd "$ROOT"
export PYTHONPATH=src

python -m unittest discover -s tests -v | tee "$OUT/core-tests.log"
python tools/validate_rule_traceability.py | tee "$OUT/rule-traceability.log"
python tools/check_extended_good_code_rules.py | tee "$OUT/extended-rules.log"
python tools/run_good_code_campaign.py
cp artifacts/good-code-campaign-receipt.json "$WORK/good-code-campaign-run-1.json"
python tools/run_good_code_campaign.py
python tools/verify_good_code_reproducibility.py \
  "$WORK/good-code-campaign-run-1.json" \
  artifacts/good-code-campaign-receipt.json
python tools/verify_good_code_receipt.py artifacts/good-code-campaign-receipt.json
python tools/rule_execution_engine.py | tee "$OUT/rule-execution.log"
python tools/run_internal_separated_e2e.py | tee "$OUT/internal-e2e.log"
cp artifacts/good-code-campaign-receipt.json "$OUT/"
cp artifacts/good-code-295-campaign-receipt.json "$OUT/"
cp artifacts/internal-separated-e2e-receipt.json "$OUT/"

POSTGRES_STATUS=NOT_RUN
NETWORK_STATUS=NOT_RUN

if [[ "$MODE" == "--full" ]]; then
  for command in docker pg_isready; do
    command -v "$command" >/dev/null || {
      echo "ONGUARD_MANUAL_VERIFICATION_HOLD missing_command=$command" >&2
      exit 69
    }
  done
  : "${ONGUARD_PG_HOST:?ONGUARD_PG_HOST is required}"
  : "${ONGUARD_PG_PORT:?ONGUARD_PG_PORT is required}"
  : "${ONGUARD_PG_DB:?ONGUARD_PG_DB is required}"
  : "${ONGUARD_PG_USER:?ONGUARD_PG_USER is required}"
  : "${ONGUARD_PG_PASSWORD:?ONGUARD_PG_PASSWORD is required}"

  python - <<'PY'
import os
import psycopg2

connection = psycopg2.connect(
    host=os.environ["ONGUARD_PG_HOST"],
    port=os.environ["ONGUARD_PG_PORT"],
    dbname=os.environ["ONGUARD_PG_DB"],
    user=os.environ["ONGUARD_PG_USER"],
    password=os.environ["ONGUARD_PG_PASSWORD"],
)
with connection:
    with connection.cursor() as cursor:
        cursor.execute(open("db/onguard_schema.sql", encoding="utf-8").read())
connection.close()
PY
  python -m unittest discover -s tests_postgres -v | tee "$OUT/postgres.log"
  POSTGRES_STATUS=PASS

  docker compose -f .devcontainer/docker-compose.yml up -d --wait sandbox-probe
  COMPOSE_STARTED=true
  if docker compose -f .devcontainer/docker-compose.yml \
    exec -T sandbox-probe \
    python -c 'import socket; socket.create_connection(("1.1.1.1", 53), 3)'; then
    echo "ONGUARD_MANUAL_VERIFICATION_FAIL external_egress_unexpectedly_succeeded" >&2
    exit 1
  fi
  docker network inspect onguard-net --format '{{json .Internal}}' | grep -qx true
  NETWORK_STATUS=PASS
fi

cat > "$OUT/result.txt" <<EOF
contract=ONGUARD_MANUAL_VERIFICATION_V1
execution_mode=$MODE
core_and_rule_harness=PASS
postgres_append_only=$POSTGRES_STATUS
network_egress_isolation=$NETWORK_STATUS
domain_detector_implemented=0
domain_detector_pending=295
independent_otester=NOT_RUN
independent_oaudit=NOT_RUN
assurance_class=SELF_VALIDATION_NONFINAL
final_lock_allowed=false
EOF

(
  cd "$OUT"
  find . -maxdepth 1 -type f ! -name evidence.sha256 -print0 \
    | sort -z \
    | xargs -0 sha256sum > evidence.sha256
)

if [[ "$MODE" == "--full" ]]; then
  printf 'ONGUARD_MANUAL_VERIFICATION_FULL_PASS_SELF_VALIDATION_NONFINAL %s\n' "$OUT"
else
  printf 'ONGUARD_MANUAL_VERIFICATION_CORE_PASS_INFRA_NOT_RUN_HOLD %s\n' "$OUT"
fi

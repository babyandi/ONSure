import copy
import unittest

from tools.run_internal_separated_e2e import build_receipt, verify_e2e_receipt


class InternalSeparatedE2ETests(unittest.TestCase):
    def test_actual_pipeline_is_stable_twice_with_zero_material_findings(self) -> None:
        receipt = build_receipt()

        self.assertEqual([], verify_e2e_receipt(receipt))
        self.assertTrue(receipt["two_run_stable"])
        self.assertEqual(0, receipt["critical_findings"])
        self.assertEqual(0, receipt["major_findings"])
        self.assertEqual("PASS_NONFINAL", receipt["internal_decision"])
        self.assertEqual("SELF_VALIDATION_NONFINAL", receipt["overall_decision"])
        self.assertEqual("NOT_RUN", receipt["external_otester"])
        self.assertEqual("NOT_RUN", receipt["external_oaudit"])
        self.assertEqual("HOLD", receipt["oasset_final_lock"])

    def test_receipt_mutation_invalidates_evidence(self) -> None:
        receipt = build_receipt()
        tampered = copy.deepcopy(receipt)
        tampered["runs"][0]["results"][0]["decision"] = "DENY"

        self.assertIn("RECEIPT_DIGEST_INVALID", verify_e2e_receipt(tampered))
        self.assertIn("RUN_RESULT_HASH_INVALID", verify_e2e_receipt(tampered))


if __name__ == "__main__":
    unittest.main()

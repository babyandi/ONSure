from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from tools.rule_execution_engine import (
    CATALOG_PATH,
    FIXTURE_PATH,
    build_all_fixtures,
    evaluate,
    load_catalog,
    materialize,
    rule_digest,
    verify_receipt,
)


ROOT = Path(__file__).resolve().parents[1]


class All295RuleExecutionTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog = load_catalog()
        cls.rules = {
            rule["rule_id"]: rule
            for rule in cls.catalog["rules"]
        }
        cls.fixtures = [
            json.loads(line)
            for line in FIXTURE_PATH.read_text(encoding="utf-8").splitlines()
            if line
        ]

    def test_all_295_rules_have_harness_but_do_not_claim_domain_detectors(self) -> None:
        self.assertEqual(295, len(self.rules))
        self.assertEqual(
            {"HARNESS_IMPLEMENTED_DETECTOR_PENDING"},
            {rule["implementation_status"] for rule in self.rules.values()},
        )
        self.assertTrue(
            all(rule["implementation"]["engine_path"] == "tools/rule_execution_engine.py"
                for rule in self.rules.values())
        )
        self.assertTrue(
            all(rule["implementation"]["detector_implementation_status"] == "NOT_IMPLEMENTED"
                for rule in self.rules.values())
        )

    def test_every_rule_has_positive_negative_and_mutation_fixture(self) -> None:
        self.assertEqual(885, len(self.fixtures))
        by_rule: dict[str, set[str]] = {}
        for fixture in self.fixtures:
            by_rule.setdefault(fixture["rule_id"], set()).add(fixture["fixture_kind"])
        self.assertEqual(set(self.rules), set(by_rule))
        self.assertTrue(
            all(kinds == {"positive", "negative", "mutation"} for kinds in by_rule.values())
        )

    def test_every_fixture_is_bound_to_rule_and_expected_policy_decision(self) -> None:
        counts = {"ALLOW": 0, "BLOCK": 0}
        for fixture in self.fixtures:
            rule = self.rules[fixture["rule_id"]]
            self.assertEqual(rule_digest(rule), fixture["catalog_rule_digest"])
            result = evaluate(rule, fixture)
            self.assertEqual(fixture["expected_decision"], result.decision)
            counts[result.decision] += 1
        self.assertEqual({"ALLOW": 295, "BLOCK": 590}, counts)

    def test_one_byte_fixture_mutation_is_rejected(self) -> None:
        fixture = copy.deepcopy(self.fixtures[0])
        rule = self.rules[fixture["rule_id"]]
        fixture["evidence"]["raw_result_hash"] = (
            ("1" if fixture["evidence"]["raw_result_hash"][0] != "1" else "2")
            + fixture["evidence"]["raw_result_hash"][1:]
        )
        result = evaluate(rule, fixture)
        self.assertEqual("BLOCK", result.decision)
        self.assertIn("EVIDENCE_MANIFEST_TAMPERED", result.reasons)

    def test_campaign_receipt_is_two_run_stable_and_hash_chained(self) -> None:
        # A clean checkout has no pre-generated artifact. Rebuild the complete
        # catalog→fixture→campaign→receipt lineage before checking the seal.
        receipt = materialize()
        self.assertEqual([], verify_receipt(receipt))
        self.assertTrue(receipt["two_run_stable"])
        self.assertEqual(
            "HARNESS_PASS_DETECTORS_PENDING",
            receipt["self_validation_decision"],
        )
        self.assertEqual("SELF_VALIDATION_NONFINAL", receipt["overall_decision"])
        self.assertEqual("HOLD", receipt["final_lock"])

    def test_committed_fixtures_match_deterministic_materializer(self) -> None:
        self.assertEqual(build_all_fixtures(self.catalog), self.fixtures)
        self.assertTrue(CATALOG_PATH.is_file())


if __name__ == "__main__":
    unittest.main()

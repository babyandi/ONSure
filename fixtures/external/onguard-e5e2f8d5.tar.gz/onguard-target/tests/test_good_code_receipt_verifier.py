from __future__ import annotations

import unittest


class GoodCodeReceiptVerifierContractTests(unittest.TestCase):
    def test_only_fail_closed_overall_decisions_are_accepted(self) -> None:
        accepted = {"FINAL_HOLD", "SELF_VALIDATION_NONFINAL"}
        self.assertIn("FINAL_HOLD", accepted)
        self.assertIn("SELF_VALIDATION_NONFINAL", accepted)
        self.assertNotIn("PASS", accepted)
        self.assertNotIn("FINAL", accepted)


if __name__ == "__main__":
    unittest.main()

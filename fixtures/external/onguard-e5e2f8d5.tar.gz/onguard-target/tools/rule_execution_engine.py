from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "docs/spec/good_code_rule_traceability.json"
FIXTURE_PATH = ROOT / "fixtures/good_code_rules/all_rules_fixtures.v1.jsonl"
RECEIPT_PATH = ROOT / "artifacts/good-code-295-campaign-receipt.json"
ENGINE_ID = "ONGUARD_295_RULE_EXECUTION_ENGINE_V1"
GENESIS = "0" * 64
REQUIRED_EVIDENCE = (
    "source_tree_hash",
    "rule_set_digest",
    "detector_version",
    "fixture_digest",
    "harness_digest",
    "environment_digest",
    "raw_result_hash",
)


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256(value: object) -> str:
    if isinstance(value, bytes):
        material = value
    elif isinstance(value, str):
        material = value.encode("utf-8")
    else:
        material = canonical_bytes(value)
    return hashlib.sha256(material).hexdigest()


def load_catalog(path: Path = CATALOG_PATH) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("rules"), list):
        raise ValueError("RULE_CATALOG_INVALID")
    return value


def rule_digest(rule: dict[str, object]) -> str:
    authority_projection = {
        key: value
        for key, value in rule.items()
        if key not in {"implementation_status", "implementation"}
    }
    return sha256(authority_projection)


def expected_evidence(rule_id: str, fixture_kind: str) -> dict[str, str]:
    return {
        key: sha256(f"{ENGINE_ID}|{rule_id}|{fixture_kind}|{key}")
        for key in REQUIRED_EVIDENCE
    }


def build_fixture(rule: dict[str, object], fixture_kind: str) -> dict[str, object]:
    if fixture_kind not in {"positive", "negative", "mutation"}:
        raise ValueError("FIXTURE_KIND_INVALID")
    rule_id = str(rule["rule_id"])
    evidence = expected_evidence(rule_id, fixture_kind)
    fixture = {
        "fixture_schema": "onguard-rule-fixture/v1",
        "fixture_id": f"{rule_id}:{fixture_kind}",
        "rule_id": rule_id,
        "fixture_kind": fixture_kind,
        "catalog_rule_digest": rule_digest(rule),
        "detector": {
            "executed": True,
            "passed": fixture_kind != "negative",
            "finding_count": 1 if fixture_kind == "negative" else 0,
        },
        "harness": {"executed": True, "passed": True},
        "oracle": {"executed": True, "passed": True},
        "policy": {
            "on_violation": "BLOCK",
            "on_missing_evidence": "HOLD",
            "on_clean": "ALLOW",
        },
        "evidence": evidence,
        "evidence_manifest_hash": sha256(evidence),
        "expected_decision": "ALLOW" if fixture_kind == "positive" else "BLOCK",
    }
    if fixture_kind == "mutation":
        fixture["evidence"]["raw_result_hash"] = "0" * 64
    return fixture


@dataclass(frozen=True)
class Evaluation:
    fixture_id: str
    rule_id: str
    decision: str
    reasons: tuple[str, ...]
    result_hash: str

    def as_dict(self) -> dict[str, object]:
        return {
            "fixture_id": self.fixture_id,
            "rule_id": self.rule_id,
            "decision": self.decision,
            "reasons": list(self.reasons),
            "result_hash": self.result_hash,
        }


def evaluate(rule: dict[str, object], fixture: dict[str, object]) -> Evaluation:
    reasons: list[str] = []
    rule_id = str(rule["rule_id"])
    fixture_id = str(fixture.get("fixture_id", "MISSING"))
    if fixture.get("rule_id") != rule_id:
        reasons.append("RULE_ID_BINDING_MISMATCH")
    if fixture.get("catalog_rule_digest") != rule_digest(rule):
        reasons.append("CATALOG_RULE_DIGEST_MISMATCH")
    kind = fixture.get("fixture_kind")
    if kind not in {"positive", "negative", "mutation"}:
        reasons.append("FIXTURE_KIND_INVALID")

    detector = fixture.get("detector")
    harness = fixture.get("harness")
    oracle = fixture.get("oracle")
    if not isinstance(detector, dict) or not detector.get("executed"):
        reasons.append("DETECTOR_NOT_EXECUTED")
    if not isinstance(harness, dict) or not harness.get("executed"):
        reasons.append("HARNESS_NOT_EXECUTED")
    if not isinstance(oracle, dict) or not oracle.get("executed"):
        reasons.append("ORACLE_NOT_EXECUTED")

    evidence = fixture.get("evidence")
    if not isinstance(evidence, dict):
        reasons.append("EVIDENCE_MISSING")
    else:
        for field in REQUIRED_EVIDENCE:
            value = evidence.get(field)
            if not isinstance(value, str) or not _is_digest(value):
                reasons.append(f"EVIDENCE_DIGEST_INVALID:{field}")
        if fixture.get("evidence_manifest_hash") != sha256(evidence):
            reasons.append("EVIDENCE_MANIFEST_TAMPERED")

    if isinstance(detector, dict) and not detector.get("passed"):
        reasons.append("RULE_VIOLATION_DETECTED")
    if isinstance(harness, dict) and not harness.get("passed"):
        reasons.append("HARNESS_FAILED")
    if isinstance(oracle, dict) and not oracle.get("passed"):
        reasons.append("ORACLE_FAILED")

    blocking = any(
        reason == "RULE_VIOLATION_DETECTED"
        or reason.endswith("_MISMATCH")
        or reason.endswith("_TAMPERED")
        or reason.endswith("_FAILED")
        or reason.endswith("_INVALID")
        or reason.endswith("_MISSING")
        or reason.endswith("_NOT_EXECUTED")
        or reason.startswith("EVIDENCE_DIGEST_INVALID:")
        for reason in reasons
    )
    decision = "BLOCK" if blocking else "ALLOW"
    result_projection = {
        "fixture_id": fixture_id,
        "rule_id": rule_id,
        "decision": decision,
        "reasons": sorted(reasons),
    }
    return Evaluation(
        fixture_id=fixture_id,
        rule_id=rule_id,
        decision=decision,
        reasons=tuple(sorted(reasons)),
        result_hash=sha256(result_projection),
    )


def validate_fixture_expectation(
    rule: dict[str, object], fixture: dict[str, object]
) -> Evaluation:
    result = evaluate(rule, fixture)
    if result.decision != fixture.get("expected_decision"):
        raise AssertionError(
            f"{result.fixture_id}: expected {fixture.get('expected_decision')}, "
            f"observed {result.decision}"
        )
    return result


def build_all_fixtures(catalog: dict[str, object]) -> list[dict[str, object]]:
    rules = catalog["rules"]
    fixtures: list[dict[str, object]] = []
    for rule in rules:
        if not isinstance(rule, dict):
            raise ValueError("RULE_CATALOG_ENTRY_INVALID")
        for kind in ("positive", "negative", "mutation"):
            fixtures.append(build_fixture(rule, kind))
    return fixtures


def materialize_catalog(catalog: dict[str, object]) -> dict[str, object]:
    materialized = json.loads(json.dumps(catalog, ensure_ascii=False))
    for rule in materialized["rules"]:
        rule["implementation_status"] = "HARNESS_IMPLEMENTED_DETECTOR_PENDING"
        rule["implementation"] = {
            "engine_id": ENGINE_ID,
            "engine_path": "tools/rule_execution_engine.py",
            "fixture_contract": "positive+negative+mutation",
            "decision_contract": "ALLOW_OR_BLOCK_FAIL_CLOSED",
            "receipt_contract": "onguard-rule-campaign-receipt/v1",
            "full_domain_runtime_detector_required_for_final": True,
            "detector_implementation_status": "NOT_IMPLEMENTED",
        }
    materialized["implementation_summary"] = {
        "engine_id": ENGINE_ID,
        "harness_implemented_rule_count": len(materialized["rules"]),
        "domain_detector_implemented_rule_count": 0,
        "domain_detector_pending_rule_count": len(materialized["rules"]),
        "fixture_count": len(materialized["rules"]) * 3,
        "campaign_runs_required": 2,
        "assurance_ceiling": "SELF_VALIDATION_NONFINAL",
    }
    return materialized


def execute_campaign(
    catalog: dict[str, object], fixtures: Iterable[dict[str, object]], iteration: int
) -> dict[str, object]:
    rules_by_id = {
        str(rule["rule_id"]): rule
        for rule in catalog["rules"]
        if isinstance(rule, dict)
    }
    results: list[dict[str, object]] = []
    previous_hash = GENESIS
    for fixture in fixtures:
        rule_id = str(fixture["rule_id"])
        if rule_id not in rules_by_id:
            raise AssertionError(f"FIXTURE_RULE_UNKNOWN:{rule_id}")
        result = validate_fixture_expectation(rules_by_id[rule_id], fixture)
        entry = {
            "fixture_id": result.fixture_id,
            "rule_id": rule_id,
            "decision": result.decision,
            "reasons": list(result.reasons),
            "result_hash": result.result_hash,
            "previous_hash": previous_hash,
        }
        entry_hash = sha256(entry)
        entry["entry_hash"] = entry_hash
        previous_hash = entry_hash
        results.append(entry)
    projection = {
        "rule_count": len(rules_by_id),
        "fixture_count": len(results),
        "allow_count": sum(item["decision"] == "ALLOW" for item in results),
        "block_count": sum(item["decision"] == "BLOCK" for item in results),
        "result_chain_head": previous_hash,
        "result_hashes": [item["result_hash"] for item in results],
    }
    return {
        "iteration": iteration,
        "decision": "PASS",
        "projection": projection,
        "projection_hash": sha256(projection),
        "results": results,
    }


def build_receipt(
    catalog: dict[str, object],
    fixtures: list[dict[str, object]],
    runs: list[dict[str, object]],
) -> dict[str, object]:
    projections = {str(run["projection_hash"]) for run in runs}
    stable = len(runs) == 2 and len(projections) == 1
    return {
        "receipt_schema": "onguard-rule-campaign-receipt/v1",
        "engine_id": ENGINE_ID,
        "catalog_digest": sha256(catalog),
        "fixture_manifest_digest": sha256(fixtures),
        "rule_count": len(catalog["rules"]),
        "fixture_count": len(fixtures),
        "runs": runs,
        "two_run_stable": stable,
        "self_validation_decision": "HARNESS_PASS_DETECTORS_PENDING" if stable else "FAIL",
        "overall_decision": "SELF_VALIDATION_NONFINAL",
        "final_lock": "HOLD",
        "external_otester": "NOT_RUN",
        "external_oaudit": "NOT_RUN",
    }


def verify_receipt(receipt: dict[str, object]) -> list[str]:
    errors: list[str] = []
    if receipt.get("rule_count") != 295:
        errors.append("RULE_COUNT_NOT_295")
    if receipt.get("fixture_count") != 885:
        errors.append("FIXTURE_COUNT_NOT_885")
    runs = receipt.get("runs")
    if not isinstance(runs, list) or len(runs) != 2:
        errors.append("TWO_RUNS_REQUIRED")
        return errors
    if len({run.get("projection_hash") for run in runs if isinstance(run, dict)}) != 1:
        errors.append("RUN_PROJECTION_UNSTABLE")
    for run in runs:
        if not isinstance(run, dict):
            errors.append("RUN_INVALID")
            continue
        previous = GENESIS
        results = run.get("results")
        if not isinstance(results, list) or len(results) != 885:
            errors.append("RUN_RESULT_COUNT_INVALID")
            continue
        for entry in results:
            if entry.get("previous_hash") != previous:
                errors.append("RESULT_CHAIN_PREVIOUS_HASH_BROKEN")
                break
            body = {key: value for key, value in entry.items() if key != "entry_hash"}
            calculated = sha256(body)
            if calculated != entry.get("entry_hash"):
                errors.append("RESULT_CHAIN_ENTRY_TAMPERED")
                break
            previous = calculated
        projection = run.get("projection")
        if not isinstance(projection, dict) or projection.get("result_chain_head") != previous:
            errors.append("RESULT_CHAIN_HEAD_MISMATCH")
    return errors


def materialize() -> dict[str, object]:
    catalog = materialize_catalog(load_catalog())
    fixtures = build_all_fixtures(catalog)
    runs = [execute_campaign(catalog, fixtures, 1), execute_campaign(catalog, fixtures, 2)]
    receipt = build_receipt(catalog, fixtures, runs)
    errors = verify_receipt(receipt)
    if errors:
        raise AssertionError(",".join(errors))
    CATALOG_PATH.write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    FIXTURE_PATH.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE_PATH.write_text(
        "".join(
            json.dumps(fixture, ensure_ascii=False, sort_keys=True) + "\n"
            for fixture in fixtures
        ),
        encoding="utf-8",
    )
    RECEIPT_PATH.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT_PATH.write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return receipt


def _is_digest(value: str) -> bool:
    return len(value) == 64 and all(character in "0123456789abcdef" for character in value)


def main() -> int:
    receipt = materialize()
    print(
        json.dumps(
            {
                "engine_id": receipt["engine_id"],
                "rule_count": receipt["rule_count"],
                "fixture_count": receipt["fixture_count"],
                "two_run_stable": receipt["two_run_stable"],
                "self_validation_decision": receipt["self_validation_decision"],
                "overall_decision": receipt["overall_decision"],
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

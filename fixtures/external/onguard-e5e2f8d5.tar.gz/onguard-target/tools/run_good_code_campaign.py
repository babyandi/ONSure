from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_once(iteration: int) -> dict[str, object]:
    command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_extended_good_code_gate.py", "-v"]
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
    raw = result.stdout + result.stderr
    normalized = re.sub(r"Ran (\d+) tests? in [0-9.]+s", r"Ran \1 tests in <elapsed>", raw)
    return {
        "iteration": iteration,
        "command": command,
        "exit_code": result.returncode,
        "raw_result_hash": hashlib.sha256(normalized.encode()).hexdigest(),
        "decision": "CLEAN" if result.returncode == 0 else "FAIL",
        "raw_result": raw,
    }


def main() -> int:
    runs = [run_once(1), run_once(2)]
    catalog = ROOT / "docs/spec/good_code_rule_traceability.json"
    receipt = {
        "receipt_schema": "onguard-good-code-campaign/v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "tested_head": os.environ.get("ONGUARD_TESTED_HEAD", "LOCAL_UNCOMMITTED"),
        "catalog_digest": digest(catalog),
        "detector_digest": digest(ROOT / "tools/check_extended_good_code_rules.py"),
        "trace_validator_digest": digest(ROOT / "tools/validate_rule_traceability.py"),
        "fixture_digest": hashlib.sha256(
            b"".join(path.read_bytes() for path in sorted((ROOT / "tests/fixtures/good_code_extended").glob("*.py")))
        ).hexdigest(),
        "runs": runs,
        "slice_decision": "CLEAN_2" if all(run["decision"] == "CLEAN" for run in runs) else "FAIL",
        "overall_decision": "SELF_VALIDATION_NONFINAL",
        "overall_reason": (
            "The 295-rule executable evidence gates are implemented, but external independent "
            "OTester/OAudit and full domain runtime integrations remain required for FinalLock."
        ),
    }
    output = ROOT / "artifacts/good-code-campaign-receipt.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(output)
    print(receipt["slice_decision"])
    return 0 if receipt["slice_decision"] == "CLEAN_2" else 1


if __name__ == "__main__":
    raise SystemExit(main())
